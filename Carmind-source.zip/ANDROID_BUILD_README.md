# Carmind AI Android build

This repository contains both the Carmind web interface and a native Android host. The Android layer supplies microphone recognition, Android text-to-speech, hands-free foreground notification, phone contacts/calling, music volume control, file importing, external media links, and Android-approved Wi-Fi/Bluetooth connection panels.

## CodeMagic: build the test APK

1. Extract the delivery ZIP before uploading it. `codemagic.yaml` must be visible at the top level of the GitHub repository, beside `package.json` and the `android` folder.
2. Commit and push all files to the `main` branch.
3. In CodeMagic, press **Check for configuration file** or refresh the application.
4. Select **Carmind AI - Installable Debug APK**.
5. Start the build. Download `app-debug.apk` from **Artifacts** when it finishes.

The debug APK is signed automatically with the Android debug certificate and can be installed for testing. It is not a Play Store release.

## GitHub Actions alternative

Open **Actions**, select **Build Carmind Android APK**, then choose **Run workflow**. The downloadable artifact is named `Carmind-AI-debug-APK`.

## Release signing

The release workflow creates an unsigned Android App Bundle. Before Play Store publishing, create and securely store the owner's release keystore, add it to CodeMagic's Android code-signing identities, and connect that signing identity to the release workflow. Never commit the keystore or its passwords to GitHub.

## Android restrictions that remain visible to the driver

- Modern Android requires a user confirmation panel for Wi-Fi changes and Bluetooth pairing/connection.
- Contact calling requires Contacts and Phone permission.
- Voice recognition quality and offline support depend on the speech services and offline language packs installed on the Android device.
- Google routing, YouTube search, Spotify search, payment verification, and connected AI answers require their server-side API configuration and internet access.
- A true locked-car launcher/kiosk requires device-owner provisioning by the vehicle/tablet administrator; an ordinary APK cannot silently make itself device owner.
