package ai.carmind.car;

import android.webkit.JavascriptInterface;

public final class CarmindBridge {
    private final MainActivity activity;

    CarmindBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface public void startListening(String languageCode) {
        activity.runOnUiThread(() -> activity.startHandsFreeListening(languageCode));
    }

    @JavascriptInterface public void stopListening() {
        activity.runOnUiThread(activity::stopHandsFreeListening);
    }

    @JavascriptInterface public void speak(String text, String languageCode) {
        activity.runOnUiThread(() -> activity.speak(text, languageCode));
    }

    @JavascriptInterface public int changeVolume(String action) {
        return activity.changeVolume(action);
    }

    @JavascriptInterface public void callContact(String contact) {
        activity.runOnUiThread(() -> activity.callContact(contact));
    }

    @JavascriptInterface public void setWifiEnabled(boolean enabled) {
        activity.runOnUiThread(() -> activity.requestWifiState(enabled));
    }

    @JavascriptInterface public void connectWifi(String network) {
        activity.runOnUiThread(() -> activity.openWifiConnectionPanel(network));
    }

    @JavascriptInterface public void setBluetoothEnabled(boolean enabled) {
        activity.runOnUiThread(() -> activity.requestBluetoothState(enabled));
    }

    @JavascriptInterface public void connectBluetooth(String device) {
        activity.runOnUiThread(() -> activity.openBluetoothSettings(device));
    }
}
