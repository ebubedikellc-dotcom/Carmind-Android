package ai.carmind.car;

import android.Manifest;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.PendingIntent;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioManager;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.Settings;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public final class MainActivity extends Activity implements RecognitionListener, TextToSpeech.OnInitListener {
    private static final int PERMISSION_REQUEST = 210;
    private static final int FILE_REQUEST = 211;
    private WebView webView;
    private SpeechRecognizer recognizer;
    private Intent recognizerIntent;
    private TextToSpeech tts;
    private boolean listeningRequested;
    private boolean speaking;
    private boolean pageLoaded;
    private String recognitionLanguage = "en-NG";
    private ValueCallback<Uri[]> fileCallback;

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        enterDriverMode();

        webView = new WebView(this);
        setContentView(webView);
        configureWebView();
        tts = new TextToSpeech(this, this);
        webView.loadUrl("file:///android_asset/www/index.html");
        requestCorePermissions();
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " CarmindAndroid/1.0");
        webView.addJavascriptInterface(new CarmindBridge(this), "CarmindAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    webView.postDelayed(() -> startHandsFreeListening("en-NG"), 1200);
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame() || "file".equals(request.getUrl().getScheme())) return false;
                openExternal(request.getUrl());
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED, false);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
                startActivityForResult(intent, FILE_REQUEST);
                return true;
            }
        });
    }

    private void requestCorePermissions() {
        List<String> missing = new ArrayList<>();
        for (String permission : new String[]{Manifest.permission.RECORD_AUDIO, Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ACCESS_FINE_LOCATION}) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) missing.add(permission);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (!missing.isEmpty()) requestPermissions(missing.toArray(new String[0]), PERMISSION_REQUEST);
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == PERMISSION_REQUEST && pageLoaded && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            webView.postDelayed(() -> startHandsFreeListening("en-NG"), 400);
        }
    }

    public void startHandsFreeListening(String languageCode) {
        recognitionLanguage = languageCode == null || languageCode.isBlank() ? "en-NG" : languageCode;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST);
            return;
        }
        listeningRequested = true;
        Intent service = new Intent(this, ListeningService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        if (recognizer == null) {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                toast("Android speech recognition is not available on this device.");
                return;
            }
            recognizer = SpeechRecognizer.createSpeechRecognizer(this);
            recognizer.setRecognitionListener(this);
        }
        recognizerIntent = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE, recognitionLanguage)
            .putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, recognitionLanguage)
            .putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 5)
            .putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false);
        startRecognizerSafely();
    }

    private void startRecognizerSafely() {
        if (!listeningRequested || speaking || recognizer == null) return;
        try {
            recognizer.cancel();
            recognizer.startListening(recognizerIntent);
            callJs("window.carmindNativeListeningState && window.carmindNativeListeningState(true)");
        } catch (RuntimeException ignored) {
            webView.postDelayed(this::startRecognizerSafely, 700);
        }
    }

    public void stopHandsFreeListening() {
        listeningRequested = false;
        if (recognizer != null) recognizer.cancel();
        stopService(new Intent(this, ListeningService.class));
        callJs("window.carmindNativeListeningState && window.carmindNativeListeningState(false)");
    }

    public void speak(String text, String languageCode) {
        if (text == null || text.isBlank() || tts == null) return;
        speaking = true;
        if (recognizer != null) recognizer.cancel();
        Locale locale = Locale.forLanguageTag(languageCode == null ? "en-NG" : languageCode);
        int available = tts.isLanguageAvailable(locale);
        if (available >= TextToSpeech.LANG_AVAILABLE) tts.setLanguage(locale);
        tts.setSpeechRate(0.96f);
        tts.setPitch(1.02f);
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "carmind-utterance");
    }

    @Override public void onInit(int status) {
        if (status != TextToSpeech.SUCCESS) toast("Android text-to-speech could not start.");
        if (tts != null) tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { speaking = true; }
            @Override public void onDone(String id) { finishSpeaking(); }
            @Override public void onError(String id) { finishSpeaking(); }
        });
    }

    private void finishSpeaking() {
        speaking = false;
        runOnUiThread(() -> {
            callJs("window.carmindNativeSpeechDone && window.carmindNativeSpeechDone()");
            webView.postDelayed(this::startRecognizerSafely, 350);
        });
    }

    public int changeVolume(String action) {
        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int current = audio.getStreamVolume(AudioManager.STREAM_MUSIC);
        if ("up".equals(action)) current = Math.min(max, current + Math.max(1, max / 10));
        else if ("down".equals(action)) current = Math.max(0, current - Math.max(1, max / 10));
        else if ("mute".equals(action)) current = 0;
        else if ("unmute".equals(action) && current == 0) current = Math.max(1, max / 2);
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, current, 0);
        return Math.round(current * 100f / max);
    }

    public void callContact(String requestedName) {
        if (requestedName == null || requestedName.isBlank()) return;
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE}, PERMISSION_REQUEST);
            toast("Allow Contacts and Phone, then say the call command again.");
            return;
        }
        List<ContactNumber> matches = new ArrayList<>();
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] columns = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
        try (Cursor cursor = getContentResolver().query(uri, columns, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", new String[]{"%" + requestedName + "%"}, null)) {
            while (cursor != null && cursor.moveToNext()) matches.add(new ContactNumber(cursor.getString(0), cursor.getString(1)));
        }
        if (matches.isEmpty()) {
            toast("I could not find " + requestedName + " in Contacts.");
            return;
        }
        ContactNumber selected = matches.stream().filter(x -> x.name.equalsIgnoreCase(requestedName)).findFirst().orElse(matches.get(0));
        if (matches.size() > 1 && matches.stream().noneMatch(x -> x.name.equalsIgnoreCase(requestedName))) {
            new AlertDialog.Builder(this).setTitle("Choose the contact to call")
                .setItems(matches.stream().map(x -> x.name + " — " + x.number).toArray(String[]::new), (dialog, index) -> placeCall(matches.get(index)))
                .setNegativeButton("Cancel", null).show();
        } else placeCall(selected);
    }

    private void placeCall(ContactNumber contact) {
        Uri number = Uri.parse("tel:" + Uri.encode(contact.number));
        Intent intent = new Intent(checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED ? Intent.ACTION_CALL : Intent.ACTION_DIAL, number);
        try { startActivity(intent); } catch (ActivityNotFoundException e) { toast("No phone app is available."); }
    }

    public void requestWifiState(boolean enabled) {
        if (Build.VERSION.SDK_INT < 29) {
            WifiManager manager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            manager.setWifiEnabled(enabled);
        } else {
            toast("Android requires your confirmation to change Wi-Fi.");
            startActivity(new Intent(Settings.Panel.ACTION_WIFI));
        }
    }

    public void openWifiConnectionPanel(String network) {
        toast("Choose " + network + " in the Android Wi-Fi panel.");
        startActivity(new Intent(Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_WIFI : Settings.ACTION_WIFI_SETTINGS));
    }

    public void requestBluetoothState(boolean enabled) {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) { toast("This device has no Bluetooth adapter."); return; }
        if (enabled) startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
        else {
            toast("Android requires confirmation in Bluetooth settings.");
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        }
    }

    public void openBluetoothSettings(String device) {
        toast("Select " + device + " to pair or connect.");
        startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
    }

    private void openExternal(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (ActivityNotFoundException e) { toast("No app can open this link."); }
    }

    private void enterDriverMode() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private void callJs(String script) {
        if (webView != null) webView.evaluateJavascript(script, null);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override public void onResults(Bundle results) {
        ArrayList<String> values = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
        if (values != null && !values.isEmpty()) {
            String primary = JSONObject.quote(values.get(0));
            String alternatives = JSONObject.quote(new JSONArray(values.subList(1, values.size())).toString());
            callJs("window.carmindReceiveNativeSpeech && window.carmindReceiveNativeSpeech(" + primary + "," + alternatives + ")");
        }
        webView.postDelayed(this::startRecognizerSafely, 450);
    }
    @Override public void onError(int error) { if (listeningRequested && !speaking) webView.postDelayed(this::startRecognizerSafely, error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY ? 900 : 450); }
    @Override public void onReadyForSpeech(Bundle params) {}
    @Override public void onBeginningOfSpeech() {}
    @Override public void onRmsChanged(float rmsdB) {}
    @Override public void onBufferReceived(byte[] buffer) {}
    @Override public void onEndOfSpeech() {}
    @Override public void onPartialResults(Bundle partialResults) {}
    @Override public void onEvent(int eventType, Bundle params) {}

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onResume() { super.onResume(); enterDriverMode(); }

    @Override protected void onDestroy() {
        stopHandsFreeListening();
        if (recognizer != null) recognizer.destroy();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private static final class ContactNumber {
        final String name;
        final String number;
        ContactNumber(String name, String number) { this.name = name; this.number = number; }
    }
}
