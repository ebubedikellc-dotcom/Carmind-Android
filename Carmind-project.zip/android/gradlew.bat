@echo off
where gradle >nul 2>nul
if %ERRORLEVEL% EQU 0 (
  gradle %*
  exit /b %ERRORLEVEL%
)
echo Gradle is not installed. Use Android Studio, or build with the included Codemagic/GitHub workflow.
exit /b 1
