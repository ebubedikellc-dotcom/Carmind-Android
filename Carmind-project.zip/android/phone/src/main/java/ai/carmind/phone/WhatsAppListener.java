package ai.carmind.phone;

import android.app.Notification;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.content.Intent;
import android.os.Bundle;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import org.json.JSONObject;

public final class WhatsAppListener extends NotificationListenerService {
    private static volatile StatusBarNotification latest;
    @Override public void onNotificationPosted(StatusBarNotification sbn){if(!sbn.getPackageName().startsWith("com.whatsapp"))return;latest=sbn;Bundle e=sbn.getNotification().extras;String sender=String.valueOf(e.getCharSequence(Notification.EXTRA_TITLE,"WhatsApp"));String text=String.valueOf(e.getCharSequence(Notification.EXTRA_TEXT,"New message"));String combined=(sender+" "+text).toLowerCase();String type=combined.contains("incoming")&&combined.contains("call")?"whatsapp_call":"whatsapp";JSONObject j=PhoneLinkService.event(type,text);try{j.put("sender",sender);j.put("canReply",findReply(sbn.getNotification())!=null);}catch(Exception ignored){}if(PhoneLinkService.active!=null)PhoneLinkService.active.send(j);}
    private static Notification.Action findReply(Notification n){if(n.actions==null)return null;for(Notification.Action a:n.actions)if(a.getRemoteInputs()!=null&&a.getRemoteInputs().length>0)return a;return null;}
    static void reply(String text){StatusBarNotification sbn=latest;if(sbn==null||text==null||text.isBlank())return;Notification.Action a=findReply(sbn.getNotification());if(a==null)return;try{Intent i=new Intent();Bundle b=new Bundle();for(RemoteInput input:a.getRemoteInputs())b.putCharSequence(input.getResultKey(),text);RemoteInput.addResultsToIntent(a.getRemoteInputs(),i,b);a.actionIntent.send(PhoneLinkService.active,0,i);}catch(PendingIntent.CanceledException ignored){}}
}
