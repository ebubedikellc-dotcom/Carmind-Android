package ai.carmind.phone;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.provider.MediaStore;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public final class PhoneLinkService extends Service {
    static final UUID SERVICE_UUID=UUID.fromString("83f8a8c2-93ea-4bf0-94bd-6da352ef31b7");
    static volatile PhoneLinkService active;
    private final ExecutorService executor=Executors.newCachedThreadPool();
    private BluetoothServerSocket server; private BluetoothSocket socket; private OutputStreamWriter writer; private MediaPlayer player;
    public static boolean handleLocal(String json){try{if(active==null)return false;active.handle(new JSONObject(json));return true;}catch(Exception ignored){return false;}}
    @Override public void onCreate(){super.onCreate();active=this;NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("phone-link","Connected apps",NotificationManager.IMPORTANCE_LOW));Notification n=new Notification.Builder(this,"phone-link").setSmallIcon(ai.carmind.car.R.drawable.ic_phone).setContentTitle("Carmind Mobile").setContentText("Ready to connect to Carmind Car").setOngoing(true).build();startForeground(41,n);startServer();}
    @Override public int onStartCommand(Intent i,int f,int id){if(server==null)startServer();return START_STICKY;}
    @Override public IBinder onBind(Intent i){return null;}
    private void startServer(){executor.execute(()->{try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null||!a.isEnabled()||(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED))return;server=a.listenUsingRfcommWithServiceRecord("Carmind Mobile",SERVICE_UUID);while(true){BluetoothSocket accepted=server.accept();closeSocket();socket=accepted;writer=new OutputStreamWriter(socket.getOutputStream());send(event("connected","Carmind Mobile connected"));readLoop();}}catch(Exception ignored){}});}
    private void readLoop(){try{BufferedReader r=new BufferedReader(new InputStreamReader(socket.getInputStream()));String line;while((line=r.readLine())!=null)handle(new JSONObject(line));}catch(Exception ignored){}closeSocket();}
    private void handle(JSONObject c){String type=c.optString("type");switch(type){case "call"->call(c.optString("contact"));case "play_music"->playMusic(c.optString("query"));case "pause"->{if(player!=null&&player.isPlaying())player.pause();}case "resume"->{if(player!=null)player.start();}case "stop"->{if(player!=null){player.stop();player.release();player=null;}}case "whatsapp_reply"->WhatsAppListener.reply(c.optString("text"));default->send(event("error","Unsupported phone command"));}}
    private void call(String name){if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){send(event("permission","Allow Contacts on the phone"));return;}String number=null,display=null;Uri u=ContactsContract.CommonDataKinds.Phone.CONTENT_URI;try(Cursor c=getContentResolver().query(u,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" LIKE ?",new String[]{"%"+name+"%"},null)){if(c!=null&&c.moveToFirst()){display=c.getString(0);number=c.getString(1);}}if(number==null){send(event("not_found","Contact not found: "+name));return;}Intent i=new Intent(checkSelfPermission(Manifest.permission.CALL_PHONE)==PackageManager.PERMISSION_GRANTED?Intent.ACTION_CALL:Intent.ACTION_DIAL,Uri.parse("tel:"+Uri.encode(number)));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);send(event("calling",display));}
    private void playMusic(String query){String selection=MediaStore.Audio.Media.IS_MUSIC+"!=0";String[] args=null;if(query!=null&&!query.isBlank()){selection+=" AND ("+MediaStore.Audio.Media.TITLE+" LIKE ? OR "+MediaStore.Audio.Media.ARTIST+" LIKE ?)";args=new String[]{"%"+query+"%","%"+query+"%"};}try(Cursor c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST},selection,args,MediaStore.Audio.Media.TITLE+" ASC")){if(c==null||!c.moveToFirst()){send(event("not_found","No matching phone music"));return;}long id=c.getLong(0);String title=c.getString(1);if(player!=null)player.release();player=MediaPlayer.create(this,Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,String.valueOf(id)));if(player==null){send(event("error","That phone song could not be opened"));return;}player.start();send(event("playing",title));}catch(Exception e){send(event("permission","Allow Music and audio on the phone"));}}
    static JSONObject event(String type,String message){JSONObject j=new JSONObject();try{j.put("type",type);j.put("message",message);}catch(Exception ignored){}return j;}
    synchronized void send(JSONObject j){try{if(writer!=null){writer.write(j.toString()+"\n");writer.flush();}}catch(Exception ignored){}}
    private void closeSocket(){try{if(socket!=null)socket.close();}catch(Exception ignored){}socket=null;writer=null;}
    @Override public void onDestroy(){active=null;try{if(server!=null)server.close();}catch(Exception ignored){}closeSocket();if(player!=null)player.release();executor.shutdownNow();super.onDestroy();}
}
