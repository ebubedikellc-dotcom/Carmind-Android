package ai.carmind.phone;

import android.Manifest;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.Service;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothServerSocket;
import android.bluetooth.BluetoothSocket;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Build;
import android.os.IBinder;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.telecom.TelecomManager;
import android.telephony.TelephonyManager;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.UUID;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicBoolean;

public final class PhoneLinkService extends Service {
    static final UUID SERVICE_UUID=UUID.fromString("83f8a8c2-93ea-4bf0-94bd-6da352ef31b7");
    static volatile PhoneLinkService active;
    private final ExecutorService executor=Executors.newCachedThreadPool();
    private BluetoothServerSocket server; private BluetoothSocket socket; private OutputStreamWriter writer; private MediaPlayer player;
    private final List<Uri> mediaQueue=new ArrayList<>(); private final List<String> mediaTitles=new ArrayList<>(); private int mediaIndex=-1;
    private final AtomicBoolean serverStarting=new AtomicBoolean(false);
    private boolean callReceiverRegistered;
    private final BroadcastReceiver callReceiver=new BroadcastReceiver(){@Override public void onReceive(Context context,Intent intent){if(!TelephonyManager.ACTION_PHONE_STATE_CHANGED.equals(intent.getAction()))return;String state=intent.getStringExtra(TelephonyManager.EXTRA_STATE);String number=intent.getStringExtra(TelephonyManager.EXTRA_INCOMING_NUMBER);if(TelephonyManager.EXTRA_STATE_RINGING.equals(state))send(event("incoming_call","Incoming call"+(number==null||number.isBlank()?"":" from "+contactName(number))));else if(TelephonyManager.EXTRA_STATE_OFFHOOK.equals(state))send(event("call_answered","Call connected"));else if(TelephonyManager.EXTRA_STATE_IDLE.equals(state))send(event("call_ended","Call ended"));}};
    public static boolean handleLocal(String json){try{if(active==null)return false;active.handle(new JSONObject(json));return true;}catch(Exception ignored){return false;}}
    public static void setDucked(boolean ducked){if(active!=null&&active.player!=null)active.player.setVolume(ducked?0.22f:1f,ducked?0.22f:1f);}
    @Override public void onCreate(){super.onCreate();active=this;NotificationManager nm=getSystemService(NotificationManager.class);nm.createNotificationChannel(new NotificationChannel("phone-link","Connected apps",NotificationManager.IMPORTANCE_LOW));Notification n=new Notification.Builder(this,"phone-link").setSmallIcon(ai.carmind.car.R.drawable.ic_phone).setContentTitle("Carmind Mobile").setContentText("Voice, calls and phone media service active").setOngoing(true).build();startForeground(41,n);IntentFilter filter=new IntentFilter(TelephonyManager.ACTION_PHONE_STATE_CHANGED);if(Build.VERSION.SDK_INT>=33)registerReceiver(callReceiver,filter,Context.RECEIVER_NOT_EXPORTED);else registerReceiver(callReceiver,filter);callReceiverRegistered=true;}
    @Override public int onStartCommand(Intent i,int f,int id){if(i!=null&&i.getBooleanExtra("accept_car_connection",false)&&server==null)startServer();return START_STICKY;}
    @Override public IBinder onBind(Intent i){return null;}
    private void startServer(){if(!serverStarting.compareAndSet(false,true))return;executor.execute(()->{try{BluetoothAdapter a=BluetoothAdapter.getDefaultAdapter();if(a==null||!a.isEnabled()||(Build.VERSION.SDK_INT>=31&&checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED))return;server=a.listenUsingRfcommWithServiceRecord("Carmind Mobile",SERVICE_UUID);while(true){BluetoothSocket accepted=server.accept();closeSocket();socket=accepted;writer=new OutputStreamWriter(socket.getOutputStream());send(event("connected","Carmind Mobile connected"));readLoop();}}catch(Exception ignored){}finally{serverStarting.set(false);}});}
    private void readLoop(){try{BufferedReader r=new BufferedReader(new InputStreamReader(socket.getInputStream()));String line;while((line=r.readLine())!=null)handle(new JSONObject(line));}catch(Exception ignored){}closeSocket();}
    private void handle(JSONObject c){String type=c.optString("type");switch(type){case "call"->call(c.optString("contact"));case "call_number"->placeNumber(c.optString("label","contact"),c.optString("number"));case "answer_call"->answerCall();case "reject_call"->rejectCall();case "play_music"->playMusic(c.optString("query"));case "pause"->{if(player!=null&&player.isPlaying())player.pause();}case "resume"->{if(player!=null)player.start();}case "duck"->setDucked(true);case "unduck"->setDucked(false);case "next"->moveQueue(1);case "previous"->moveQueue(-1);case "restart"->{if(player!=null){player.seekTo(0);player.start();}}case "forward"->{if(player!=null)player.seekTo(Math.min(player.getDuration(),player.getCurrentPosition()+10000));}case "rewind"->{if(player!=null)player.seekTo(Math.max(0,player.getCurrentPosition()-10000));}case "stop"->{if(player!=null){player.stop();player.release();player=null;}mediaQueue.clear();mediaTitles.clear();mediaIndex=-1;}case "whatsapp_reply"->WhatsAppListener.reply(c.optString("text"));default->send(event("error","Unsupported phone command"));}}
    private String contactName(String number){if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED)return number;Uri uri=Uri.withAppendedPath(ContactsContract.PhoneLookup.CONTENT_FILTER_URI,Uri.encode(number));try(Cursor c=getContentResolver().query(uri,new String[]{ContactsContract.PhoneLookup.DISPLAY_NAME},null,null,null)){return c!=null&&c.moveToFirst()?c.getString(0):number;}catch(Exception ignored){return number;}}
    @SuppressWarnings("deprecation") private void answerCall(){if(checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS)!=PackageManager.PERMISSION_GRANTED){send(event("permission","Allow Answer phone calls in Carmind Mobile settings."));return;}try{TelecomManager telecom=(TelecomManager)getSystemService(TELECOM_SERVICE);telecom.acceptRingingCall();send(event("call_answered","Answering the call"));}catch(Exception error){send(event("error","Android did not allow Carmind to answer this call"));}}
    @SuppressWarnings("deprecation") private void rejectCall(){if(checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS)!=PackageManager.PERMISSION_GRANTED){send(event("permission","Allow Answer phone calls in Carmind Mobile settings."));return;}try{TelecomManager telecom=(TelecomManager)getSystemService(TELECOM_SERVICE);boolean ended=Build.VERSION.SDK_INT>=28&&telecom.endCall();send(event(ended?"call_ended":"error",ended?"Call ended":"Android did not allow Carmind to end this call"));}catch(Exception error){send(event("error","Android did not allow Carmind to end this call"));}}
    private void call(String name){if(checkSelfPermission(Manifest.permission.READ_CONTACTS)!=PackageManager.PERMISSION_GRANTED){send(event("permission","Allow Contacts on the phone"));return;}name=name.replaceFirst("(?i)^(?:please\\s+)?(?:my\\s+|me\\s+)+","").trim();String number=null,display=null;Uri u=ContactsContract.CommonDataKinds.Phone.CONTENT_URI;try(Cursor c=getContentResolver().query(u,new String[]{ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,ContactsContract.CommonDataKinds.Phone.NUMBER},ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME+" LIKE ?",new String[]{"%"+name+"%"},null)){if(c!=null&&c.moveToFirst()){display=c.getString(0);number=c.getString(1);}}if(number==null){send(event("not_found","I could not find "+name+" in the phone contacts."));return;}placeNumber(display,number);}
    private void placeNumber(String label,String number){if(number==null||number.isBlank()){send(event("not_found","No phone number was provided."));return;}if(checkSelfPermission(Manifest.permission.CALL_PHONE)!=PackageManager.PERMISSION_GRANTED){send(event("permission","Allow Phone calls in Carmind Mobile settings, then try again."));return;}try{Intent i=new Intent(Intent.ACTION_CALL,Uri.parse("tel:"+Uri.encode(number)));i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);startActivity(i);send(event("calling","Calling "+label+"."));}catch(SecurityException e){send(event("permission","Android blocked the call. Check Carmind Mobile Phone permission."));}catch(Exception e){send(event("error","No calling app is available on the phone."));}}
    private void playMusic(String query){String selection=MediaStore.Audio.Media.IS_MUSIC+"!=0";String[] args=null;if(query!=null&&!query.isBlank()){selection+=" AND ("+MediaStore.Audio.Media.TITLE+" LIKE ? OR "+MediaStore.Audio.Media.ARTIST+" LIKE ?)";args=new String[]{"%"+query+"%","%"+query+"%"};}try(Cursor c=getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,new String[]{MediaStore.Audio.Media._ID,MediaStore.Audio.Media.TITLE,MediaStore.Audio.Media.ARTIST},selection,args,MediaStore.Audio.Media.TITLE+" ASC")){mediaQueue.clear();mediaTitles.clear();while(c!=null&&c.moveToNext()){mediaQueue.add(Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,String.valueOf(c.getLong(0))));String artist=c.getString(2);mediaTitles.add(c.getString(1)+(artist==null||artist.isBlank()?"":" · "+artist));}if(mediaQueue.isEmpty()){send(event("not_found","No matching phone music"));return;}mediaIndex=0;playQueueItem();}catch(Exception e){send(event("permission","Allow Music and audio on the phone"));}}
    private void moveQueue(int direction){if(mediaQueue.isEmpty())return;mediaIndex=(mediaIndex+direction+mediaQueue.size())%mediaQueue.size();playQueueItem();}
    private void playQueueItem(){if(mediaIndex<0||mediaIndex>=mediaQueue.size())return;if(player!=null)player.release();player=MediaPlayer.create(this,mediaQueue.get(mediaIndex));if(player==null){send(event("error","That phone song could not be opened"));return;}player.setOnCompletionListener(done->moveQueue(1));player.start();send(event("playing",mediaTitles.get(mediaIndex)));}
    static JSONObject event(String type,String message){JSONObject j=new JSONObject();try{j.put("type",type);j.put("message",message);}catch(Exception ignored){}return j;}
    synchronized void send(JSONObject j){try{if(writer!=null){writer.write(j.toString()+"\n");writer.flush();}}catch(Exception ignored){}}
    private void closeSocket(){try{if(socket!=null)socket.close();}catch(Exception ignored){}socket=null;writer=null;}
    @Override public void onDestroy(){active=null;if(callReceiverRegistered){try{unregisterReceiver(callReceiver);}catch(Exception ignored){}callReceiverRegistered=false;}try{if(server!=null)server.close();}catch(Exception ignored){}closeSocket();if(player!=null)player.release();executor.shutdownNow();super.onDestroy();}
}
