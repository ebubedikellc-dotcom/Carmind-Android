#include <jni.h>
#include <algorithm>
#include <string>
#include <thread>
#include <vector>
#include "whisper.h"

extern "C" JNIEXPORT jlong JNICALL
Java_ai_carmind_car_WhisperListeningEngine_nativeInit(JNIEnv *env, jclass, jstring path) {
    const char *value = env->GetStringUTFChars(path, nullptr);
    whisper_context_params parameters = whisper_context_default_params();
    parameters.use_gpu = false;
    whisper_context *context = whisper_init_from_file_with_params(value, parameters);
    env->ReleaseStringUTFChars(path, value);
    return reinterpret_cast<jlong>(context);
}

extern "C" JNIEXPORT jstring JNICALL
Java_ai_carmind_car_WhisperListeningEngine_nativeTranscribe(
    JNIEnv *env, jclass, jlong pointer, jshortArray input, jstring prompt) {
    auto *context = reinterpret_cast<whisper_context *>(pointer);
    if (!context || !input) return env->NewStringUTF("");
    const jsize length = env->GetArrayLength(input);
    std::vector<jshort> pcm(length);
    env->GetShortArrayRegion(input, 0, length, pcm.data());
    std::vector<float> samples(length);
    std::transform(pcm.begin(), pcm.end(), samples.begin(),
        [](jshort sample) { return static_cast<float>(sample) / 32768.0f; });

    const char *promptText = prompt ? env->GetStringUTFChars(prompt, nullptr) : nullptr;
    whisper_full_params parameters = whisper_full_default_params(WHISPER_SAMPLING_GREEDY);
    parameters.language = "en";
    parameters.translate = false;
    parameters.no_timestamps = true;
    parameters.single_segment = false;
    parameters.suppress_blank = true;
    parameters.suppress_nst = true;
    parameters.print_progress = false;
    parameters.print_realtime = false;
    parameters.print_timestamps = false;
    parameters.initial_prompt = promptText;
    const unsigned int available = std::thread::hardware_concurrency();
    parameters.n_threads = static_cast<int>(std::max(2u, std::min(4u, available)));

    const int result = whisper_full(context, parameters, samples.data(), static_cast<int>(samples.size()));
    std::string text;
    if (result == 0) {
        const int segments = whisper_full_n_segments(context);
        for (int i = 0; i < segments; ++i) text += whisper_full_get_segment_text(context, i);
    }
    if (promptText) env->ReleaseStringUTFChars(prompt, promptText);
    return env->NewStringUTF(text.c_str());
}

extern "C" JNIEXPORT void JNICALL
Java_ai_carmind_car_WhisperListeningEngine_nativeFree(JNIEnv *, jclass, jlong pointer) {
    auto *context = reinterpret_cast<whisper_context *>(pointer);
    if (context) whisper_free(context);
}
