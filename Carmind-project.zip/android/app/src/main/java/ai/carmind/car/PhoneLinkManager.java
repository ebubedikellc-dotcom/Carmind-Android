package ai.carmind.car;

import android.Manifest;
import android.bluetooth.BluetoothAdapter;
import android.bluetooth.BluetoothDevice;
import android.bluetooth.BluetoothSocket;
import android.content.pm.PackageManager;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

final class PhoneLinkManager {
    static final UUID SERVICE_UUID = UUID.fromString("83f8a8c2-93ea-4bf0-94bd-6da352ef31b7");
    private final MainActivity activity;
    private final ExecutorService executor = Executors.newCachedThreadPool();
    private BluetoothSocket socket;
    private OutputStreamWriter writer;
    private volatile boolean connecting;

    PhoneLinkManager(MainActivity activity) { this.activity = activity; }

    boolean isConnected() { return socket != null && socket.isConnected(); }

    void connect() {
        if (connecting || isConnected()) return;
        connecting = true;
        executor.execute(() -> {
            close();
            BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
            if (adapter == null || !adapter.isEnabled()) { connecting=false; activity.phonePairingState("error", "Turn on Bluetooth on both Android devices first."); return; }
            if (android.os.Build.VERSION.SDK_INT >= 31 && activity.checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) { connecting=false; activity.phonePairingState("error", "Allow Nearby devices, then try again."); return; }
            Set<BluetoothDevice> bonded = adapter.getBondedDevices();
            if (bonded.isEmpty()) { connecting=false; activity.phonePairingState("error", "Pair the phone in Android Bluetooth settings first, then try again."); return; }
            for (BluetoothDevice device : bonded) {
                try {
                    activity.phonePairingState("searching", "Checking " + device.getName() + "…");
                    BluetoothSocket candidate = device.createRfcommSocketToServiceRecord(SERVICE_UUID);
                    candidate.connect(); socket = candidate; writer = new OutputStreamWriter(socket.getOutputStream());
                    connecting=false; activity.phonePairingState("connected", "Connected to " + device.getName());
                    readLoop(); return;
                } catch (Exception ignored) { close(); }
            }
            connecting=false; activity.phonePairingState("error", "Carmind Mobile was not found. Open it on the paired phone and try again.");
        });
    }

    boolean send(String json) {
        if (!isConnected() || writer == null) return false;
        executor.execute(() -> { try { writer.write(json.replace("\n", "") + "\n"); writer.flush(); } catch (Exception error) { close(); activity.phonePairingState("disconnected", "Phone connection was lost."); } });
        return true;
    }

    private void readLoop() {
        try {
            BufferedReader reader = new BufferedReader(new InputStreamReader(socket.getInputStream()));
            String line; while ((line = reader.readLine()) != null) activity.phoneMessage(line);
        } catch (Exception ignored) { }
        close(); activity.phonePairingState("disconnected", "Phone disconnected.");
    }

    void close() { try { if (socket != null) socket.close(); } catch (Exception ignored) {} socket = null; writer = null; }
}
