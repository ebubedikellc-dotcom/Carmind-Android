package ai.carmind.car;

import android.webkit.JavascriptInterface;

public final class CarmindBridge {
    private final MainActivity activity;

    CarmindBridge(MainActivity activity) {
        this.activity = activity;
    }

    @JavascriptInterface public String getDeviceRole() {
        return activity.getDeviceRole();
    }

    @JavascriptInterface public void setVehicleMode(String mode) {
        activity.runOnUiThread(() -> activity.setVehicleMode(mode));
    }

    @JavascriptInterface public void openHotspotSettings() {
        activity.runOnUiThread(activity::openHotspotSettings);
    }

    @JavascriptInterface public void startNavigation(String destination) {
        activity.runOnUiThread(() -> activity.startGoogleNavigation(destination));
    }

    @JavascriptInterface public void startListening(String languageCode) {
        activity.runOnUiThread(() -> activity.startHandsFreeListening(languageCode));
    }

    @JavascriptInterface public void stopListening() {
        activity.runOnUiThread(activity::stopHandsFreeListening);
    }

    @JavascriptInterface public void listenOnce(String languageCode) {
        activity.runOnUiThread(() -> activity.listenOnceForCalibration(languageCode));
    }

    @JavascriptInterface public void finishCalibration() {
        activity.runOnUiThread(activity::finishCalibration);
    }

    @JavascriptInterface public void setMediaActive(boolean active) {
        activity.runOnUiThread(() -> activity.setMediaActive(active));
    }

    @JavascriptInterface public void speak(String text, String languageCode) {
        activity.runOnUiThread(() -> activity.speak(text, languageCode));
    }

    @JavascriptInterface public int changeVolume(String action) {
        return activity.changeVolume(action);
    }

    @JavascriptInterface public void callContact(String contact) {
        activity.runOnUiThread(() -> activity.callContact(contact));
    }

    @JavascriptInterface public void setWifiEnabled(boolean enabled) {
        activity.runOnUiThread(() -> activity.requestWifiState(enabled));
    }

    @JavascriptInterface public void connectWifi(String network) {
        activity.runOnUiThread(() -> activity.openWifiConnectionPanel(network));
    }

    @JavascriptInterface public void setBluetoothEnabled(boolean enabled) {
        activity.runOnUiThread(() -> activity.requestBluetoothState(enabled));
    }

    @JavascriptInterface public void connectBluetooth(String device) {
        activity.runOnUiThread(() -> activity.openBluetoothSettings(device));
    }

    @JavascriptInterface public void startPhonePairing() {
        activity.startPhonePairing();
    }

    @JavascriptInterface public boolean sendPhoneCommand(String json) {
        return activity.sendPhoneCommand(json);
    }

    @JavascriptInterface public void disconnectPhone() {
        activity.disconnectPhone();
    }

    @JavascriptInterface public void reconnectPhoneIfKnown() {
        activity.reconnectPhoneIfKnown();
    }

    @JavascriptInterface public void openExternal(String url) {
        activity.runOnUiThread(() -> activity.openExternalUrl(url));
    }
}
