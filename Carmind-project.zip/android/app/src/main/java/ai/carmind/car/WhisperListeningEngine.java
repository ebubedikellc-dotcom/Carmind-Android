// Copyright 2026 Ebubedike LLC.
// Native transcription is provided by whisper.cpp (MIT licence).
package ai.carmind.car;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.AudioFormat;
import android.media.AudioRecord;
import android.media.MediaRecorder;
import android.media.audiofx.AcousticEchoCanceler;
import android.media.audiofx.AutomaticGainControl;
import android.media.audiofx.NoiseSuppressor;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

/**
 * Silent, continuous microphone capture backed by whisper.cpp.
 *
 * Audio is divided on natural pauses and only complete phrases are sent to
 * Whisper.  There are no SpeechRecognizer start/stop tones and the microphone
 * is owned by exactly one engine at a time.
 */
final class WhisperListeningEngine {
    interface Callback {
        void onReady();
        void onText(String text);
        void onFailure(String message);
    }

    private static final int SAMPLE_RATE = 16000;
    private static final int FRAME_SAMPLES = 1600; // 100 ms
    private static final int MAX_SAMPLES = SAMPLE_RATE * 15;
    private static final int END_SILENCE_FRAMES = 10;
    private static final int PRE_ROLL_FRAMES = 4;

    static {
        System.loadLibrary("carmind-whisper");
    }

    private final Activity activity;
    private final Callback callback;
    private final ExecutorService worker = Executors.newSingleThreadExecutor();
    private volatile boolean requested;
    private volatile boolean paused;
    private volatile boolean prepared;
    private volatile boolean running;
    private AudioRecord recorder;
    private long nativeContext;

    WhisperListeningEngine(Activity activity, Callback callback) {
        this.activity = activity;
        this.callback = callback;
    }

    synchronized void start() {
        requested = true;
        paused = false;
        if (prepared) {
            if (!running && nativeContext != 0) worker.execute(this::captureLoop);
            callback.onReady();
            return;
        }
        prepared = true;
        worker.execute(() -> {
            try {
                File model = installModel();
                nativeContext = nativeInit(model.getAbsolutePath());
                if (nativeContext == 0) throw new IllegalStateException("Whisper model could not be loaded");
                callback.onReady();
                captureLoop();
            } catch (Throwable error) {
                prepared = false;
                callback.onFailure("Accurate offline listening could not start: " + error.getMessage());
            }
        });
    }

    synchronized void setPaused(boolean value) {
        paused = value;
    }

    synchronized void stop() {
        requested = false;
        releaseRecorder();
    }

    synchronized void shutdown() {
        stop();
        worker.shutdownNow();
        try { worker.awaitTermination(2, TimeUnit.SECONDS); }
        catch (InterruptedException ignored) { Thread.currentThread().interrupt(); }
        if (nativeContext != 0) {
            nativeFree(nativeContext);
            nativeContext = 0;
        }
    }

    private File installModel() throws Exception {
        File destination = new File(activity.getFilesDir(), "carmind-whisper-small-en-q5.bin");
        if (destination.isFile() && destination.length() > 100_000_000L) return destination;
        File temporary = new File(activity.getFilesDir(), destination.getName() + ".part");
        try (InputStream input = activity.getAssets().open("model-whisper.bin");
             FileOutputStream output = new FileOutputStream(temporary)) {
            byte[] buffer = new byte[1024 * 1024];
            int count;
            while ((count = input.read(buffer)) != -1) output.write(buffer, 0, count);
            output.getFD().sync();
        }
        if (destination.exists() && !destination.delete()) throw new IllegalStateException("Could not replace speech model");
        if (!temporary.renameTo(destination)) throw new IllegalStateException("Could not install speech model");
        return destination;
    }

    private void captureLoop() {
        running = true;
        try {
        if (activity.checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            throw new SecurityException("Microphone permission is required");
        }
        int minimum = AudioRecord.getMinBufferSize(SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT);
        // VOICE_COMMUNICATION improves echo cancellation and follows a
        // connected car/Bluetooth microphone more reliably on many devices.
        recorder = new AudioRecord(MediaRecorder.AudioSource.VOICE_COMMUNICATION, SAMPLE_RATE,
            AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
            Math.max(minimum * 2, FRAME_SAMPLES * 4));
        if (recorder.getState() != AudioRecord.STATE_INITIALIZED) {
            recorder.release();
            recorder = new AudioRecord(MediaRecorder.AudioSource.MIC, SAMPLE_RATE,
                AudioFormat.CHANNEL_IN_MONO, AudioFormat.ENCODING_PCM_16BIT,
                Math.max(minimum * 2, FRAME_SAMPLES * 4));
        }
        enableAudioCleanup(recorder.getAudioSessionId());
        recorder.startRecording();

        short[] frame = new short[FRAME_SAMPLES];
        short[] phrase = new short[MAX_SAMPLES];
        short[][] preRoll = new short[PRE_ROLL_FRAMES][FRAME_SAMPLES];
        int preRollIndex = 0;
        int preRollCount = 0;
        int phraseLength = 0;
        int silenceFrames = 0;
        double noiseFloor = 90.0;
        boolean inSpeech = false;

        while (requested && !Thread.currentThread().isInterrupted()) {
            int read = recorder.read(frame, 0, frame.length, AudioRecord.READ_BLOCKING);
            if (read <= 0) continue;
            if (paused) {
                phraseLength = 0;
                silenceFrames = 0;
                inSpeech = false;
                continue;
            }
            double level = rms(frame, read);
            if (!inSpeech) noiseFloor = noiseFloor * 0.96 + Math.min(level, 700.0) * 0.04;
            double startThreshold = Math.max(105.0, noiseFloor * 1.55);
            double keepThreshold = Math.max(85.0, noiseFloor * 1.18);

            if (!inSpeech && level >= startThreshold) {
                inSpeech = true;
                int first = (preRollIndex - preRollCount + PRE_ROLL_FRAMES) % PRE_ROLL_FRAMES;
                for (int i = 0; i < preRollCount; i++) {
                    short[] earlier = preRoll[(first + i) % PRE_ROLL_FRAMES];
                    int preCopy = Math.min(earlier.length, phrase.length - phraseLength);
                    System.arraycopy(earlier, 0, phrase, phraseLength, preCopy);
                    phraseLength += preCopy;
                }
                preRollCount = 0;
            }
            if (!inSpeech) {
                System.arraycopy(frame, 0, preRoll[preRollIndex], 0, read);
                preRollIndex = (preRollIndex + 1) % PRE_ROLL_FRAMES;
                preRollCount = Math.min(PRE_ROLL_FRAMES, preRollCount + 1);
                continue;
            }

            int copy = Math.min(read, phrase.length - phraseLength);
            System.arraycopy(frame, 0, phrase, phraseLength, copy);
            phraseLength += copy;
            silenceFrames = level < keepThreshold ? silenceFrames + 1 : 0;

            boolean complete = silenceFrames >= END_SILENCE_FRAMES && phraseLength >= SAMPLE_RATE / 2;
            if (complete || phraseLength >= phrase.length) {
                short[] audio = Arrays.copyOf(phrase, Math.max(0, phraseLength - silenceFrames * FRAME_SAMPLES));
                phraseLength = 0;
                silenceFrames = 0;
                inSpeech = false;
                if (audio.length >= SAMPLE_RATE / 3) {
                    String text = nativeTranscribe(nativeContext, audio,
                        "Carmind smart-car command. Mercedes. Hello Mercedes. " +
                        "Play Carmind demo audio. Play Carmind demo beat. Play Carmind demo video. " +
                        "Open Train My Carmind. Open settings. Open Drive. Open Media. Go back. " +
                        "Increase volume. Decrease volume. Call my wife. Drive me home.");
                    if (text != null && !text.isBlank() && requested && !paused) callback.onText(text.trim());
                }
            }
        }
        releaseRecorder();
        } finally {
            running = false;
            releaseRecorder();
        }
    }

    private void enableAudioCleanup(int sessionId) {
        try {
            if (NoiseSuppressor.isAvailable()) NoiseSuppressor.create(sessionId).setEnabled(true);
        } catch (Throwable ignored) { }
        try {
            if (AcousticEchoCanceler.isAvailable()) AcousticEchoCanceler.create(sessionId).setEnabled(true);
        } catch (Throwable ignored) { }
        try {
            if (AutomaticGainControl.isAvailable()) AutomaticGainControl.create(sessionId).setEnabled(true);
        } catch (Throwable ignored) { }
    }

    private static double rms(short[] data, int length) {
        double sum = 0;
        for (int i = 0; i < length; i++) {
            double sample = data[i];
            sum += sample * sample;
        }
        return Math.sqrt(sum / Math.max(1, length));
    }

    private synchronized void releaseRecorder() {
        if (recorder == null) return;
        try { recorder.stop(); } catch (Throwable ignored) { }
        recorder.release();
        recorder = null;
    }

    private static native long nativeInit(String modelPath);
    private static native String nativeTranscribe(long context, short[] audio, String prompt);
    private static native void nativeFree(long context);
}
