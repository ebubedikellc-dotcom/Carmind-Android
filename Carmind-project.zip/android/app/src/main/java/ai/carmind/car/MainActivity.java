package ai.carmind.car;

import android.Manifest;
import android.app.Activity;
import android.bluetooth.BluetoothAdapter;
import android.content.ActivityNotFoundException;
import android.content.Context;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.media.AudioAttributes;
import android.media.AudioFocusRequest;
import android.media.AudioManager;
import android.media.MediaMetadataRetriever;
import android.net.Uri;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.ContactsContract;
import android.provider.MediaStore;
import android.provider.Settings;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.view.View;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.PermissionRequest;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MainActivity extends Activity implements TextToSpeech.OnInitListener {
    private static final int PERMISSION_REQUEST = 210;
    private static final int FILE_REQUEST = 211;
    private WebView webView;
    private TextToSpeech tts;
    private boolean ttsReady;
    private String pendingSpeechText;
    private String pendingSpeechLanguage;
    private long pendingSpeechToken;
    private boolean listeningRequested;
    private boolean speaking;
    private long speechSequence;
    private String currentSpeechId;
    private boolean pageLoaded;
    private boolean calibrationListening;
    private boolean resumeAfterCalibration;
    private int calibrationAttempt;
    private boolean mediaActive;
    private long wakeWindowUntil;
    private boolean optionalPermissionsRequested;
    private String recognitionLanguage = "en-NG";
    private ValueCallback<Uri[]> fileCallback;
    private PhoneLinkManager phoneLink;
    private VoskListeningEngine voskListening;
    private String pendingCallName;
    private String pendingCallNumber;
    private String pendingCallLabel;
    private AudioManager audioManager;
    private AudioFocusRequest speechFocusRequest;
    private final AudioManager.OnAudioFocusChangeListener speechFocusListener = change -> { };
    private String carAudioMode = "android-auto-compatible";

    public String getDeviceRole() {
        return "ai.carmind.phone".equals(getPackageName()) ? "mobile" : "car";
    }

    public void setVehicleMode(String mode) {
        getPreferences(MODE_PRIVATE).edit().putString("vehicle_mode", mode == null ? "" : mode).apply();
        if (!"mobile".equals(getDeviceRole())) return;
        Intent link = new Intent().setComponent(new ComponentName(getPackageName(), "ai.carmind.phone.PhoneLinkService"));
        link.putExtra("accept_car_connection", "with-android".equals(mode));
        try {
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(link); else startService(link);
        } catch (SecurityException error) {
            toast("Allow Nearby devices, Music and notifications, then choose the car setup again.");
            requestCorePermissions();
            return;
        }
        if ("with-android".equals(mode)) {
            toast("Carmind Mobile is ready for Carmind Car. Turn on Bluetooth and your hotspot.");
        } else {
            toast("Phone mode is active. Connect this phone to the car Bluetooth audio system.");
        }
    }

    public void openHotspotSettings() {
        try { startActivity(new Intent(Settings.ACTION_WIRELESS_SETTINGS)); }
        catch (Exception ignored) { startActivity(new Intent(Settings.ACTION_SETTINGS)); }
    }

    public void startGoogleNavigation(String destination) {
        if (destination == null || destination.isBlank()) return;
        try {
            Intent navigation = new Intent(Intent.ACTION_VIEW, Uri.parse("google.navigation:q=" + Uri.encode(destination) + "&mode=d"));
            navigation.setPackage("com.google.android.apps.maps");
            startActivity(navigation);
        } catch (ActivityNotFoundException error) {
            openExternal(Uri.parse("https://www.google.com/maps/dir/?api=1&destination=" + Uri.encode(destination) + "&travelmode=driving"));
        }
    }

    @Override protected void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        if ("car".equals(getDeviceRole())) enterDriverMode();

        webView = new WebView(this);
        phoneLink = new PhoneLinkManager(this);
        voskListening = new VoskListeningEngine(this, new VoskListeningEngine.Callback() {
            @Override public void onReady() {
                runOnUiThread(MainActivity.this::recognitionReady);
            }
            @Override public void onText(String text) {
                runOnUiThread(() -> receiveOfflineSpeech(text));
            }
            @Override public void onFailure(String message) {
                runOnUiThread(() -> {
                    callJs("window.carmindNativeListeningState && window.carmindNativeListeningState(false)");
                    callJs("window.carmindNativeListeningError && window.carmindNativeListeningError(" +
                        JSONObject.quote(message) + ")");
                    toast(message);
                });
            }
        });
        setContentView(webView);
        configureWebView();
        audioManager = (AudioManager) getSystemService(AUDIO_SERVICE);
        carAudioMode = getPreferences(MODE_PRIVATE).getString("car_audio_mode", "android-auto-compatible");
        tts = new TextToSpeech(this, this);
        webView.loadUrl("file:///android_asset/www/index.html");
        requestCorePermissions();
    }

    private void configureWebView() {
        WebSettings settings = webView.getSettings();
        settings.setJavaScriptEnabled(true);
        settings.setDomStorageEnabled(true);
        settings.setDatabaseEnabled(true);
        settings.setAllowFileAccess(true);
        settings.setAllowContentAccess(true);
        settings.setMediaPlaybackRequiresUserGesture(false);
        settings.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        settings.setUserAgentString(settings.getUserAgentString() + " CarmindAndroid/1.0");
        webView.addJavascriptInterface(new CarmindBridge(this), "CarmindAndroid");
        webView.setWebViewClient(new WebViewClient() {
            @Override public void onPageFinished(WebView view, String url) {
                pageLoaded = true;
                if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                    webView.postDelayed(() -> startHandsFreeListening("en-NG"), 1200);
                }
            }
            @Override public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                if (!request.isForMainFrame() || "file".equals(request.getUrl().getScheme())) return false;
                openExternal(request.getUrl());
                return true;
            }
        });
        webView.setWebChromeClient(new WebChromeClient() {
            @Override public void onPermissionRequest(PermissionRequest request) {
                runOnUiThread(() -> request.grant(request.getResources()));
            }
            @Override public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                callback.invoke(origin, checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED, false);
            }
            @Override public boolean onShowFileChooser(WebView view, ValueCallback<Uri[]> callback, FileChooserParams params) {
                if (fileCallback != null) fileCallback.onReceiveValue(null);
                fileCallback = callback;
                Intent intent = params.createIntent();
                intent.setType("*/*");
                intent.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
                startActivityForResult(intent, FILE_REQUEST);
                return true;
            }
        });
    }

    private void requestCorePermissions() {
        // Request the essential microphone permission by itself. A denied
        // optional permission must never prevent hands-free listening.
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST);
            return;
        }
        List<String> missing = new ArrayList<>();
        for (String permission : new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE, Manifest.permission.ACCESS_FINE_LOCATION}) {
            if (checkSelfPermission(permission) != PackageManager.PERMISSION_GRANTED) missing.add(permission);
        }
        if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.POST_NOTIFICATIONS);
        if (Build.VERSION.SDK_INT >= 33) {
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.READ_MEDIA_AUDIO);
            if (checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.READ_MEDIA_VIDEO);
        } else if (checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            missing.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if ("mobile".equals(getDeviceRole())) {
            if (checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.READ_PHONE_STATE);
            if (checkSelfPermission(Manifest.permission.ANSWER_PHONE_CALLS) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.ANSWER_PHONE_CALLS);
        }
        if (Build.VERSION.SDK_INT >= 31) {
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_SCAN) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.BLUETOOTH_SCAN);
            if (checkSelfPermission(Manifest.permission.BLUETOOTH_CONNECT) != PackageManager.PERMISSION_GRANTED) missing.add(Manifest.permission.BLUETOOTH_CONNECT);
        }
        if (!missing.isEmpty() && !optionalPermissionsRequested) {
            optionalPermissionsRequested = true;
            requestPermissions(missing.toArray(new String[0]), PERMISSION_REQUEST);
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] results) {
        super.onRequestPermissionsResult(requestCode, permissions, results);
        if (requestCode == PERMISSION_REQUEST && pageLoaded && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            webView.postDelayed(() -> startHandsFreeListening("en-NG"), 400);
            // Microphone is deliberately requested alone so an optional denial
            // cannot disable voice. Continue the remaining Android permission
            // groups during the same first launch instead of waiting for the
            // customer to close and reopen Carmind.
            webView.postDelayed(this::requestCorePermissions, 900);
        } else if (requestCode == PERMISSION_REQUEST && checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            callJs("window.carmindNativeListeningState && window.carmindNativeListeningState(false)");
            toast("Microphone permission is off. Open Android Settings, Apps, Carmind, Permissions, then allow Microphone.");
        }
        if (requestCode == PERMISSION_REQUEST && "mobile".equals(getDeviceRole())) {
            String savedMode = getPreferences(MODE_PRIVATE).getString("vehicle_mode", "");
            if (!savedMode.isBlank()) webView.postDelayed(() -> setVehicleMode(savedMode), 700);
        }
        if (requestCode == PERMISSION_REQUEST && pageLoaded) {
            webView.postDelayed(() -> callJs("window.carmindRefreshDeviceLibrary && window.carmindRefreshDeviceLibrary()"), 500);
        }
        if (requestCode == PERMISSION_REQUEST) {
            if (pendingCallNumber != null && checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED) {
                String number = pendingCallNumber, label = pendingCallLabel;
                pendingCallNumber = null; pendingCallLabel = null;
                webView.postDelayed(() -> placeCall(label, number), 300);
            } else if (pendingCallName != null && checkSelfPermission(Manifest.permission.READ_CONTACTS) == PackageManager.PERMISSION_GRANTED) {
                String name = pendingCallName; pendingCallName = null;
                webView.postDelayed(() -> callContact(name), 300);
            }
        }
    }

    public void startHandsFreeListening(String languageCode) {
        recognitionLanguage = languageCode == null || languageCode.isBlank() ? "en-NG" : languageCode;
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST);
            return;
        }
        listeningRequested = true;
        callJs("window.carmindNativeListeningPreparing && window.carmindNativeListeningPreparing()");
        Intent service = new Intent(this, ListeningService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
        voskListening.start();
    }

    private void receiveOfflineSpeech(String text) {
        if (!listeningRequested || speaking || text == null || text.isBlank()) return;
        if (calibrationListening) {
            calibrationListening = false;
            calibrationAttempt++;
            pauseRecognition(true);
            callJs("window.carmindNativeCalibrationResult && window.carmindNativeCalibrationResult(" + JSONObject.quote(text) + ",\"[]\")");
            if (!resumeAfterCalibration) stopHandsFreeListening();
            resumeAfterCalibration = false;
            return;
        }
        String command = text.trim();
        if (mediaActive) {
            String lower = command.toLowerCase(Locale.ROOT);
            String[] wakeNames = {"hello mercedes", "hey mercedes", "hello carmind", "hey carmind"};
            boolean woke = false;
            for (String wake : wakeNames) {
                int at = lower.indexOf(wake);
                if (at >= 0) {
                    command = (command.substring(0, at) + " " + command.substring(at + wake.length())).trim();
                    wakeWindowUntil = System.currentTimeMillis() + 10_000L;
                    woke = true;
                    break;
                }
            }
            if (!woke && System.currentTimeMillis() > wakeWindowUntil) return;
            if (command.isBlank()) {
                speak("Yes, I am listening.", recognitionLanguage);
                return;
            }
            wakeWindowUntil = System.currentTimeMillis() + 10_000L;
        }
        callJs("window.carmindReceiveNativeSpeech && window.carmindReceiveNativeSpeech(" + JSONObject.quote(command) + ",\"[]\")");
    }

    public void listenOnceForCalibration(String languageCode) {
        if (checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, PERMISSION_REQUEST);
            return;
        }
        resumeAfterCalibration = listeningRequested || resumeAfterCalibration;
        calibrationListening = true;
        calibrationAttempt++;
        recognitionLanguage = languageCode == null || languageCode.isBlank() ? "en-NG" : languageCode;
        listeningRequested = true;
        pauseRecognition(false);
        voskListening.start();
    }

    public void finishCalibration() {
        calibrationListening = false;
        calibrationAttempt++;
        if (resumeAfterCalibration) {
            resumeAfterCalibration = false;
            startHandsFreeListening(recognitionLanguage);
        } else stopHandsFreeListening();
    }

    public void setMediaActive(boolean active) {
        mediaActive = active;
        if (!active) wakeWindowUntil = 0L;
        // While music or video is playing, only the wake name opens a command
        // window. This keeps media and engine sound from issuing commands.
    }

    public void setCarAudioMode(String mode) {
        carAudioMode = "carmind-priority".equals(mode) ? mode : "android-auto-compatible";
        abandonSpeechAudioFocus();
        speechFocusRequest = null;
        getPreferences(MODE_PRIVATE).edit().putString("car_audio_mode", carAudioMode).apply();
    }

    public void openAndroidAutoSettings() {
        try {
            startActivity(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                Uri.parse("package:com.google.android.projection.gearhead")));
        } catch (Exception error) {
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        }
    }

    public void exitToLauncher() {
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
        Intent home = new Intent(Intent.ACTION_MAIN);
        home.addCategory(Intent.CATEGORY_HOME);
        home.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(home);
        finish();
    }

    public void stopHandsFreeListening() {
        listeningRequested = false;
        if (voskListening != null) voskListening.stop();
        stopService(new Intent(this, ListeningService.class));
        callJs("window.carmindNativeListeningState && window.carmindNativeListeningState(false)");
    }

    public void speak(String text, String languageCode) {
        if (text == null || text.isBlank() || tts == null) return;
        if (!ttsReady) {
            // TextToSpeech starts asynchronously. Keep the first welcome or
            // answer until Android's voice engine is ready instead of silently
            // dropping it on a newly installed APK.
            pendingSpeechText = text;
            pendingSpeechLanguage = languageCode;
            // Do not mark native speech active yet. If the phone's TTS engine
            // never completes initialization, that flag would make Carmind
            // reject every microphone result forever.
            callJs("window.carmindNativeSpeechPreparing && window.carmindNativeSpeechPreparing()");
            final long token = ++pendingSpeechToken;
            webView.postDelayed(() -> releaseStalledSpeech(token), 2500L);
            return;
        }
        speakNow(text, languageCode);
    }

    private void speakNow(String text, String languageCode) {
        speaking = true;
        // Recognition may use Android's narrow Bluetooth communication route for the
        // car microphone. Do not leave TTS on that quiet, deep-sounding call
        // channel. Pause recognition and return output to the normal media
        // route before Carmind speaks.
        pauseRecognition(true);
        prepareSpeechOutputRoute();
        requestSpeechAudioFocus();
        duckPhoneMedia(true);
        Locale locale = Locale.forLanguageTag(languageCode == null ? "en-NG" : languageCode);
        int available = tts.isLanguageAvailable(locale);
        if (available >= TextToSpeech.LANG_AVAILABLE) {
            tts.setLanguage(locale);
        } else {
            int british = tts.isLanguageAvailable(Locale.UK);
            tts.setLanguage(british >= TextToSpeech.LANG_AVAILABLE ? Locale.UK : Locale.US);
        }
        tts.setSpeechRate(1.05f);
        tts.setPitch(1.04f);
        String utteranceId = "carmind-utterance-" + (++speechSequence);
        currentSpeechId = utteranceId;
        int result = tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId);
        if (result == TextToSpeech.ERROR) {
            finishSpeaking(utteranceId);
            return;
        }
        // Some Android TTS engines and Bluetooth routes never report onDone.
        // Never allow that missing callback to leave the microphone paused.
        long watchdogMs = Math.max(3500L, Math.min(18000L, 1800L + text.length() * 85L));
        webView.postDelayed(() -> finishSpeaking(utteranceId), watchdogMs);
    }

    @Override public void onInit(int status) {
        pendingSpeechToken++;
        ttsReady = status == TextToSpeech.SUCCESS;
        if (!ttsReady) {
            toast("Android voice could not start. Enable Speech Services by Google in phone settings.");
            String pending = pendingSpeechText;
            pendingSpeechText = null;
            pendingSpeechLanguage = null;
            speaking = false;
            pauseRecognition(false);
            callJs("window.carmindNativeSpeechError && window.carmindNativeSpeechError(" + JSONObject.quote(pending == null ? "" : pending) + ")");
            return;
        }
        if (tts != null && status == TextToSpeech.SUCCESS) {
            tts.setAudioAttributes(new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_MEDIA)
                .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                .build());
        }
        if (tts != null) tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String id) { speaking = true; }
            @Override public void onDone(String id) { finishSpeaking(id); }
            @Override public void onError(String id) { finishSpeaking(id); }
            @Override public void onStop(String id, boolean interrupted) { finishSpeaking(id); }
        });
        String pending = pendingSpeechText;
        String pendingLanguage = pendingSpeechLanguage;
        pendingSpeechText = null;
        pendingSpeechLanguage = null;
        if (pending != null && !pending.isBlank()) runOnUiThread(() -> speakNow(pending, pendingLanguage));
    }

    private void releaseStalledSpeech(long token) {
        if (token != pendingSpeechToken || ttsReady || pendingSpeechText == null) return;
        String pending = pendingSpeechText;
        pendingSpeechText = null;
        pendingSpeechLanguage = null;
        speaking = false;
        pauseRecognition(false);
        if (listeningRequested && voskListening != null && !voskListening.isHealthy()) voskListening.restart();
        callJs("window.carmindNativeSpeechError && window.carmindNativeSpeechError(" + JSONObject.quote(pending) + ")");
    }

    private synchronized void finishSpeaking(String utteranceId) {
        if (utteranceId == null || !utteranceId.equals(currentSpeechId)) return;
        currentSpeechId = null;
        speaking = false;
        duckPhoneMedia(false);
        abandonSpeechAudioFocus();
        if (listeningRequested) {
            pauseRecognition(false);
            // Rebuild AudioRecord so Bluetooth SCO is selected again for the
            // next command after TTS used the loud media/A2DP route.
            webView.postDelayed(() -> voskListening.restart(), 220);
        }
        runOnUiThread(() -> {
            callJs("window.carmindNativeSpeechDone && window.carmindNativeSpeechDone()");
        });
    }

    private void requestSpeechAudioFocus() {
        if (audioManager == null) return;
        if (Build.VERSION.SDK_INT >= 26) {
            if (speechFocusRequest == null) {
                AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_ASSISTANCE_NAVIGATION_GUIDANCE)
                    .setContentType(AudioAttributes.CONTENT_TYPE_SPEECH)
                    .build();
                int focusGain = "carmind-priority".equals(carAudioMode)
                    ? AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                    : AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK;
                speechFocusRequest = new AudioFocusRequest.Builder(focusGain)
                    .setAudioAttributes(attributes)
                    .setAcceptsDelayedFocusGain(false)
                    .setOnAudioFocusChangeListener(speechFocusListener)
                    .setWillPauseWhenDucked(false)
                    .build();
            }
            audioManager.requestAudioFocus(speechFocusRequest);
        } else {
            int focusGain = "carmind-priority".equals(carAudioMode)
                ? AudioManager.AUDIOFOCUS_GAIN_TRANSIENT
                : AudioManager.AUDIOFOCUS_GAIN_TRANSIENT_MAY_DUCK;
            audioManager.requestAudioFocus(speechFocusListener, AudioManager.STREAM_MUSIC, focusGain);
        }
    }

    @SuppressWarnings("deprecation")
    private void prepareSpeechOutputRoute() {
        if (audioManager == null) return;
        if (Build.VERSION.SDK_INT >= 31) {
            audioManager.clearCommunicationDevice();
        } else {
            audioManager.stopBluetoothSco();
            audioManager.setBluetoothScoOn(false);
        }
        audioManager.setMode(AudioManager.MODE_NORMAL);
    }

    private void abandonSpeechAudioFocus() {
        if (audioManager == null) return;
        if (Build.VERSION.SDK_INT >= 26 && speechFocusRequest != null) {
            audioManager.abandonAudioFocusRequest(speechFocusRequest);
        } else {
            audioManager.abandonAudioFocus(speechFocusListener);
        }
    }

    public int changeVolume(String action) {
        AudioManager audio = (AudioManager) getSystemService(AUDIO_SERVICE);
        int max = audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
        int current = audio.getStreamVolume(AudioManager.STREAM_MUSIC);
        if ("up".equals(action)) current = Math.min(max, current + Math.max(1, max / 10));
        else if ("down".equals(action)) current = Math.max(0, current - Math.max(1, max / 10));
        else if (action != null && action.startsWith("set:")) {
            try {
                int percent = Math.max(0, Math.min(100, Integer.parseInt(action.substring(4))));
                current = Math.round(max * percent / 100f);
            } catch (NumberFormatException ignored) {}
        }
        else if ("mute".equals(action)) current = 0;
        else if ("unmute".equals(action) && current == 0) current = Math.max(1, max / 2);
        audio.setStreamVolume(AudioManager.STREAM_MUSIC, current, 0);
        return Math.round(current * 100f / max);
    }

    public String getDeviceMediaLibrary() {
        JSONArray media = new JSONArray();
        boolean modern = Build.VERSION.SDK_INT >= 33;
        boolean canReadAudio = modern
            ? checkSelfPermission(Manifest.permission.READ_MEDIA_AUDIO) == PackageManager.PERMISSION_GRANTED
            : checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        boolean canReadVideo = modern
            ? checkSelfPermission(Manifest.permission.READ_MEDIA_VIDEO) == PackageManager.PERMISSION_GRANTED
            : checkSelfPermission(Manifest.permission.READ_EXTERNAL_STORAGE) == PackageManager.PERMISSION_GRANTED;
        if (canReadAudio) appendDeviceAudio(media);
        if (canReadVideo) appendDeviceVideos(media);
        return media.toString();
    }

    private void appendDeviceAudio(JSONArray output) {
        boolean scoped = Build.VERSION.SDK_INT >= 29;
        String[] columns = {MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE,
            MediaStore.Audio.Media.DISPLAY_NAME, MediaStore.Audio.Media.ARTIST,
            scoped ? MediaStore.MediaColumns.RELATIVE_PATH : MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.MIME_TYPE, MediaStore.Audio.Media.DURATION};
        try (Cursor cursor = getContentResolver().query(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
            columns, MediaStore.Audio.Media.IS_MUSIC + "!=0", null,
            MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC")) {
            while (cursor != null && cursor.moveToNext()) {
                String displayName = cursor.getString(2);
                String path = cursor.getString(4);
                String mime = cursor.getString(5);
                long duration = cursor.getLong(6);
                if (!isAllowedLibraryMedia(path, displayName, mime, true, duration)) continue;
                String title = cursor.getString(1);
                if (title == null || title.isBlank()) title = removeFileExtension(displayName);
                JSONObject item = new JSONObject();
                item.put("name", title == null ? "Phone audio" : title);
                item.put("artist", cursor.getString(3) == null ? "Android music library" : cursor.getString(3));
                item.put("type", "audio");
                Uri mediaUri = Uri.withAppendedPath(MediaStore.Audio.Media.EXTERNAL_CONTENT_URI,
                    String.valueOf(cursor.getLong(0)));
                item.put("url", mediaUri.toString());
                String genre = readMediaGenre(mediaUri);
                if (genre != null && !genre.isBlank()) item.put("genre", genre);
                output.put(item);
            }
        } catch (Exception ignored) { }
    }

    private String readMediaGenre(Uri mediaUri) {
        MediaMetadataRetriever metadata = new MediaMetadataRetriever();
        try {
            metadata.setDataSource(this, mediaUri);
            return metadata.extractMetadata(MediaMetadataRetriever.METADATA_KEY_GENRE);
        } catch (Exception ignored) {
            return null;
        } finally {
            try { metadata.release(); } catch (Exception ignored) { }
        }
    }

    private void appendDeviceVideos(JSONArray output) {
        boolean scoped = Build.VERSION.SDK_INT >= 29;
        String[] columns = {MediaStore.Video.Media._ID, MediaStore.Video.Media.TITLE,
            MediaStore.Video.Media.DISPLAY_NAME,
            scoped ? MediaStore.MediaColumns.RELATIVE_PATH : MediaStore.MediaColumns.DATA,
            MediaStore.MediaColumns.MIME_TYPE, MediaStore.Video.Media.DURATION};
        try (Cursor cursor = getContentResolver().query(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
            columns, null, null, MediaStore.Video.Media.TITLE + " COLLATE NOCASE ASC")) {
            while (cursor != null && cursor.moveToNext()) {
                String displayName = cursor.getString(2);
                String path = cursor.getString(3);
                String mime = cursor.getString(4);
                long duration = cursor.getLong(5);
                if (!isAllowedLibraryMedia(path, displayName, mime, false, duration)) continue;
                String title = cursor.getString(1);
                if (title == null || title.isBlank()) title = removeFileExtension(displayName);
                JSONObject item = new JSONObject();
                item.put("name", title == null ? "Phone video" : title);
                item.put("artist", "Android video library");
                item.put("type", "video");
                item.put("url", Uri.withAppendedPath(MediaStore.Video.Media.EXTERNAL_CONTENT_URI,
                    String.valueOf(cursor.getLong(0))).toString());
                output.put(item);
            }
        } catch (Exception ignored) { }
    }

    private boolean isAllowedLibraryMedia(String pathValue, String nameValue, String mimeValue, boolean audio, long durationMs) {
        String path = pathValue == null ? "" : pathValue.toLowerCase(Locale.ROOT).replace('\\', '/');
        String name = nameValue == null ? "" : nameValue.toLowerCase(Locale.ROOT);
        String mime = mimeValue == null ? "" : mimeValue.toLowerCase(Locale.ROOT);
        String combined = path + "/" + name;

        // Privacy boundary: chat applications and voice-note/recording folders
        // are never exposed to Carmind's playable library, even when Android's
        // broad MediaStore collection includes them.
        String[] blocked = {"whatsapp", "com.whatsapp", "telegram", "messenger", "signal",
            "voice note", "voicenote", "voice_notes", "recording", "call recording",
            "whatsapp audio", "whatsapp video", "ptt-", "/android/media/", "/podcasts/",
            "/ringtones/", "/notifications/", "/alarms/", "/sent/", "/private/",
            "/statuses/", "/status/", "/messages/", "/chats/", "/cache/"};
        for (String word : blocked) if (combined.contains(word)) return false;
        if (audio && (mime.contains("ogg") || mime.contains("opus") || mime.contains("amr") ||
            name.startsWith("aud-") || name.startsWith("ptt-"))) return false;
        if (audio && !mime.isBlank() && !mime.startsWith("audio/")) return false;
        if (!audio && !mime.isBlank() && !mime.startsWith("video/")) return false;
        // Voice notes and status clips are normally short. Real songs, music
        // videos and movies must pass this second boundary even if an OEM
        // incorrectly labels chat media as music.
        if (audio && durationMs > 0 && durationMs < 30_000L) return false;
        if (!audio && durationMs > 0 && durationMs < 15_000L) return false;

        // Unknown folders are private by default. Only explicit public media
        // folders are allowed into Carmind.
        if (path.isBlank()) return false;
        if (audio) return path.startsWith("music/") || path.contains("/music/") ||
            path.startsWith("songs/") || path.contains("/songs/");
        return path.startsWith("music videos/") || path.contains("/music videos/") ||
            path.startsWith("musicvideos/") || path.contains("/musicvideos/") ||
            path.startsWith("movies/") || path.contains("/movies/") ||
            path.startsWith("video/") || path.startsWith("videos/") ||
            path.contains("/video/") || path.contains("/videos/");
    }

    private String removeFileExtension(String value) {
        if (value == null) return null;
        int dot = value.lastIndexOf('.');
        return dot > 0 ? value.substring(0, dot) : value;
    }

    public void callContact(String requestedName) {
        if (requestedName == null || requestedName.isBlank()) return;
        final String contactName = requestedName.replaceFirst("(?i)^(?:please\\s+)?(?:my\\s+|me\\s+)+", "").trim();
        if (phoneLink != null && phoneLink.isConnected()) {
            JSONObject command = new JSONObject();
            try { command.put("type", "call"); command.put("contact", contactName); phoneLink.send(command.toString()); }
            catch (Exception ignored) {}
            return;
        }
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            pendingCallName = contactName;
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE}, PERMISSION_REQUEST);
            reportCallState("permission", "Allow Contacts and Phone. Carmind will continue the call automatically.");
            return;
        }
        List<ContactNumber> matches = new ArrayList<>();
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] columns = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
        try (Cursor cursor = getContentResolver().query(uri, columns, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", new String[]{"%" + contactName + "%"}, null)) {
            while (cursor != null && cursor.moveToNext()) matches.add(new ContactNumber(cursor.getString(0), cursor.getString(1)));
        }
        if (matches.isEmpty()) {
            reportCallState("not_found", "I could not find " + contactName + " in your phone contacts.");
            return;
        }
        ContactNumber selected = matches.stream().filter(x -> x.name.equalsIgnoreCase(contactName)).findFirst().orElse(matches.get(0));
        placeCall(selected.name, selected.number);
    }

    public String getDeviceContacts() {
        JSONArray contacts = new JSONArray();
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            runOnUiThread(() -> requestPermissions(new String[]{Manifest.permission.READ_CONTACTS, Manifest.permission.CALL_PHONE}, PERMISSION_REQUEST));
            return contacts.toString();
        }
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] columns = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
        try (Cursor cursor = getContentResolver().query(uri, columns, null, null, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " ASC")) {
            int count = 0;
            while (cursor != null && cursor.moveToNext() && count < 1000) {
                JSONObject contact = new JSONObject();
                try {
                    contact.put("name", cursor.getString(0));
                    contact.put("number", cursor.getString(1));
                    contacts.put(contact);
                    count++;
                } catch (Exception ignored) {}
            }
        }
        return contacts.toString();
    }

    public void callNumber(String label, String requestedNumber) {
        if (requestedNumber == null || requestedNumber.isBlank()) {
            reportCallState("not_found", "No phone number has been saved for " + label + ".");
            return;
        }
        if (phoneLink != null && phoneLink.isConnected()) {
            JSONObject command = new JSONObject();
            try {
                command.put("type", "call_number"); command.put("number", requestedNumber); command.put("label", label);
                phoneLink.send(command.toString());
            } catch (Exception ignored) {}
            return;
        }
        placeCall(label, requestedNumber);
    }

    public void callWhatsAppContact(String requestedName) {
        if (requestedName == null || requestedName.isBlank()) return;
        final String contactName = requestedName.replaceFirst("(?i)^(?:please\\s+)?(?:my\\s+|me\\s+)+", "").trim();
        if (checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            pendingCallName = contactName;
            requestPermissions(new String[]{Manifest.permission.READ_CONTACTS}, PERMISSION_REQUEST);
            reportCallState("permission", "Allow Contacts, then repeat the WhatsApp call command.");
            return;
        }
        List<ContactNumber> matches = new ArrayList<>();
        Uri uri = ContactsContract.CommonDataKinds.Phone.CONTENT_URI;
        String[] columns = {ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME, ContactsContract.CommonDataKinds.Phone.NUMBER};
        try (Cursor cursor = getContentResolver().query(uri, columns, ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME + " LIKE ?", new String[]{"%" + contactName + "%"}, null)) {
            while (cursor != null && cursor.moveToNext()) matches.add(new ContactNumber(cursor.getString(0), cursor.getString(1)));
        }
        if (matches.isEmpty()) { reportCallState("not_found", "I could not find " + contactName + " in your contacts."); return; }
        ContactNumber selected = matches.stream().filter(x -> x.name.equalsIgnoreCase(contactName)).findFirst().orElse(matches.get(0));
        String digits = selected.number.replaceAll("[^0-9]", "");
        if (digits.startsWith("0") && digits.length() == 11) digits = "234" + digits.substring(1);
        String enabled = Settings.Secure.getString(getContentResolver(), Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES);
        if (enabled == null || !enabled.contains(getPackageName() + "/.WhatsAppAccessibilityService")) {
            reportCallState("permission", "Enable Carmind WhatsApp Calling in Accessibility settings, then repeat the command.");
            startActivity(new Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS));
            return;
        }
        try {
            WhatsAppAccessibilityService.prepareVoiceCall(selected.name);
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse("https://wa.me/" + digits)).setPackage("com.whatsapp");
            startActivity(intent);
            reportCallState("calling", "Starting a WhatsApp call to " + selected.name + ".");
        } catch (ActivityNotFoundException error) {
            reportCallState("unavailable", "WhatsApp is not installed on this Android device.");
        }
    }

    private void placeCall(String label, String requestedNumber) {
        if (checkSelfPermission(Manifest.permission.CALL_PHONE) != PackageManager.PERMISSION_GRANTED) {
            pendingCallNumber = requestedNumber; pendingCallLabel = label;
            requestPermissions(new String[]{Manifest.permission.CALL_PHONE}, PERMISSION_REQUEST);
            reportCallState("permission", "Allow Phone calls. Carmind will continue automatically.");
            return;
        }
        Uri number = Uri.parse("tel:" + Uri.encode(requestedNumber));
        try {
            startActivity(new Intent(Intent.ACTION_CALL, number));
            reportCallState("calling", "Calling " + label + ".");
        } catch (SecurityException error) {
            reportCallState("permission", "Android did not allow Carmind to place this call. Check Phone permission.");
        } catch (ActivityNotFoundException error) {
            reportCallState("unavailable", "No phone calling app is available on this device.");
        }
    }

    private void reportCallState(String state, String message) {
        callJs("window.carmindNativeCallState && window.carmindNativeCallState(" + JSONObject.quote(state) + "," + JSONObject.quote(message) + ")");
    }

    public void requestWifiState(boolean enabled) {
        if (Build.VERSION.SDK_INT < 29) {
            WifiManager manager = (WifiManager) getApplicationContext().getSystemService(Context.WIFI_SERVICE);
            manager.setWifiEnabled(enabled);
        } else {
            toast("Android requires your confirmation to change Wi-Fi.");
            startActivity(new Intent(Settings.Panel.ACTION_WIFI));
        }
    }

    public void openWifiConnectionPanel(String network) {
        toast("Choose " + network + " in the Android Wi-Fi panel.");
        startActivity(new Intent(Build.VERSION.SDK_INT >= 29 ? Settings.Panel.ACTION_WIFI : Settings.ACTION_WIFI_SETTINGS));
    }

    public void requestBluetoothState(boolean enabled) {
        BluetoothAdapter adapter = BluetoothAdapter.getDefaultAdapter();
        if (adapter == null) { toast("This device has no Bluetooth adapter."); return; }
        if (enabled) startActivity(new Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));
        else {
            toast("Android requires confirmation in Bluetooth settings.");
            startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        }
    }

    public void openBluetoothSettings(String device) {
        toast("Select " + device + " to pair or connect.");
        startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
    }

    private void openExternal(Uri uri) {
        try { startActivity(new Intent(Intent.ACTION_VIEW, uri)); }
        catch (ActivityNotFoundException e) { toast("No app can open this link."); }
    }

    public void openExternalUrl(String url) {
        try {
            Uri uri = Uri.parse(url);
            String host = uri.getHost() == null ? "" : uri.getHost();
            String packageName = host.contains("youtube") ? "com.google.android.youtube"
                    : host.contains("spotify") ? "com.spotify.music" : "";
            if (!packageName.isEmpty()) {
                try {
                    Intent appIntent = new Intent(Intent.ACTION_VIEW, uri).setPackage(packageName);
                    startActivity(appIntent);
                    return;
                } catch (ActivityNotFoundException ignored) {
                    // The service app is not installed; use the normal browser.
                }
            }
            openExternal(uri);
        } catch (Exception ignored) { toast("That link could not be opened."); }
    }

    public void startPhonePairing() {
        if ("mobile".equals(getDeviceRole())) {
            setVehicleMode("with-android");
            openBluetoothSettings("Carmind Car");
        } else if (phoneLink != null) phoneLink.connect();
    }

    public boolean sendPhoneCommand(String json) {
        if ("mobile".equals(getDeviceRole())) {
            try {
                Class<?> service = Class.forName("ai.carmind.phone.PhoneLinkService");
                return Boolean.TRUE.equals(service.getMethod("handleLocal", String.class).invoke(null, json));
            } catch (Exception ignored) { return false; }
        }
        return phoneLink != null && phoneLink.send(json);
    }

    private void duckPhoneMedia(boolean ducked) {
        if (phoneLink != null && phoneLink.isConnected()) {
            JSONObject command = new JSONObject();
            try { command.put("type", ducked ? "duck" : "unduck"); phoneLink.send(command.toString()); } catch (Exception ignored) {}
        }
        if ("mobile".equals(getDeviceRole())) {
            try { Class.forName("ai.carmind.phone.PhoneLinkService").getMethod("setDucked", boolean.class).invoke(null, ducked); }
            catch (Exception ignored) {}
        }
    }

    public void disconnectPhone() {
        if (phoneLink != null) phoneLink.close();
        phonePairingState("disconnected", "Phone Connection access is not active.");
    }

    public void reconnectPhoneIfKnown() {
        if (phoneLink != null && !phoneLink.isConnected() && getPreferences(MODE_PRIVATE).getBoolean("phone_link_known", false)) phoneLink.connect();
    }

    void phonePairingState(String state, String detail) {
        if ("connected".equals(state)) getPreferences(MODE_PRIVATE).edit().putBoolean("phone_link_known", true).apply();
        runOnUiThread(() -> callJs("window.carmindPhonePairingState && window.carmindPhonePairingState(" + JSONObject.quote(state) + "," + JSONObject.quote(detail) + ")"));
    }

    void phoneMessage(String json) {
        runOnUiThread(() -> callJs("window.carmindReceivePhoneMessage && window.carmindReceivePhoneMessage(" + JSONObject.quote(json) + ")"));
    }

    private void enterDriverMode() {
        getWindow().getDecorView().setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY | View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION | View.SYSTEM_UI_FLAG_LAYOUT_STABLE
        );
    }

    private void callJs(String script) {
        if (webView != null) webView.evaluateJavascript(script, null);
    }

    private void toast(String message) {
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    @Override protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == FILE_REQUEST && fileCallback != null) {
            fileCallback.onReceiveValue(WebChromeClient.FileChooserParams.parseResult(resultCode, data));
            fileCallback = null;
        }
    }

    @Override public void onBackPressed() {
        if (webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onResume() {
        super.onResume();
        if ("car".equals(getDeviceRole())) enterDriverMode();
        // Calls, media apps, Android Auto, Safari/Chrome handoffs and Bluetooth
        // can release the old AudioRecord route. Never reuse that stale route:
        // rebuild Vosk whenever Carmind becomes visible again.
        if (pageLoaded && checkSelfPermission(Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
            webView.postDelayed(() -> {
                if (listeningRequested) voskListening.restart();
                else startHandsFreeListening(recognitionLanguage);
            }, 650);
            // A second health check covers slower car Bluetooth route changes.
            webView.postDelayed(() -> {
                if (listeningRequested && !voskListening.isHealthy()) voskListening.restart();
            }, 2200);
        }
    }

    @Override protected void onDestroy() {
        stopHandsFreeListening();
        abandonSpeechAudioFocus();
        if (voskListening != null) voskListening.shutdown();
        if (phoneLink != null) phoneLink.close();
        if (tts != null) { tts.stop(); tts.shutdown(); }
        if (webView != null) webView.destroy();
        super.onDestroy();
    }

    private void pauseRecognition(boolean value) {
        if (voskListening != null) voskListening.setPaused(value);
    }

    private void recognitionReady() {
        callJs("window.carmindNativeListeningState && window.carmindNativeListeningState(true)");
        if (!calibrationListening) return;
        callJs("window.carmindNativeCalibrationReady && window.carmindNativeCalibrationReady()");
        final int attempt = calibrationAttempt;
        webView.postDelayed(() -> {
            if (!calibrationListening || attempt != calibrationAttempt) return;
            calibrationListening = false;
            calibrationAttempt++;
            pauseRecognition(true);
            callJs("window.carmindNativeCalibrationError && window.carmindNativeCalibrationError(" +
                JSONObject.quote("I could not hear that phrase. Please try again and check that Microphone permission is allowed.") + ")");
        }, 15000);
    }

    private static final class ContactNumber {
        final String name;
        final String number;
        ContactNumber(String name, String number) { this.name = name; this.number = number; }
    }
}
