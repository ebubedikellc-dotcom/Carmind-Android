package ai.carmind.car;

import android.accessibilityservice.AccessibilityService;
import android.os.SystemClock;
import android.view.accessibility.AccessibilityEvent;
import android.view.accessibility.AccessibilityNodeInfo;

import java.util.ArrayDeque;
import java.util.Locale;

public class WhatsAppAccessibilityService extends AccessibilityService {
    private static volatile WhatsAppAccessibilityService active;
    private static volatile String pendingContact = "";
    private static volatile long pendingUntil = 0;
    private static volatile int stage = 0;

    public static void prepareVoiceCall(String contact) {
        pendingContact = contact == null ? "" : contact;
        pendingUntil = SystemClock.uptimeMillis() + 20_000;
        stage = 0;
    }

    public static void prepareIncomingAction(String action) {
        pendingContact = action;
        pendingUntil = SystemClock.uptimeMillis() + 10_000;
        stage = "answer".equals(action) ? 10 : 20;
        WhatsAppAccessibilityService service = active;
        if (service != null) service.tryCurrentWindow();
    }

    @Override protected void onServiceConnected() { active = this; }

    @Override public void onAccessibilityEvent(AccessibilityEvent event) {
        if (SystemClock.uptimeMillis() > pendingUntil || !"com.whatsapp".contentEquals(event.getPackageName())) return;
        tryCurrentWindow();
    }

    private void tryCurrentWindow() {
        AccessibilityNodeInfo root = getRootInActiveWindow();
        if (root == null) return;
        if (stage == 10 && clickMatching(root, "answer", "accept")) { pendingUntil = 0; stage = 30; return; }
        if (stage == 20 && clickMatching(root, "decline", "reject")) { pendingUntil = 0; stage = 30; return; }
        if (stage == 0 && clickMatching(root, "voice call", "audio call")) {
            stage = 1;
            return;
        }
        if (stage == 1 && clickMatching(root, "call", "start call")) {
            pendingUntil = 0;
            pendingContact = "";
            stage = 2;
        }
    }

    private boolean clickMatching(AccessibilityNodeInfo root, String... labels) {
        ArrayDeque<AccessibilityNodeInfo> nodes = new ArrayDeque<>();
        nodes.add(root);
        while (!nodes.isEmpty()) {
            AccessibilityNodeInfo node = nodes.removeFirst();
            String description = node.getContentDescription() == null ? "" : node.getContentDescription().toString();
            String text = node.getText() == null ? "" : node.getText().toString();
            String value = (description + " " + text).toLowerCase(Locale.ROOT).trim();
            for (String label : labels) {
                if ((value.equals(label) || value.startsWith(label + " ")) && node.isClickable()) {
                    node.performAction(AccessibilityNodeInfo.ACTION_CLICK);
                    return true;
                }
            }
            for (int index = 0; index < node.getChildCount(); index++) {
                AccessibilityNodeInfo child = node.getChild(index);
                if (child != null) nodes.add(child);
            }
        }
        return false;
    }

    @Override public void onInterrupt() {}

    @Override public void onDestroy() { if (active == this) active = null; super.onDestroy(); }
}
