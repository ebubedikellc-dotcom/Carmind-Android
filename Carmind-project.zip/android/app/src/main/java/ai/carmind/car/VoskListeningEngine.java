// Copyright 2026 Ebubedike LLC.
// Uses Vosk, licensed under the Apache License 2.0.
package ai.carmind.car;

import android.app.Activity;

import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;
import org.vosk.android.SpeechService;
import org.vosk.android.StorageService;

import java.io.IOException;

/** Continuous offline recognition without Android SpeechRecognizer start tones. */
final class VoskListeningEngine implements RecognitionListener {
    interface Callback {
        void onReady();
        void onText(String text);
        void onFailure(String message);
    }

    private final Activity activity;
    private final Callback callback;
    private Model model;
    private SpeechService speechService;
    private boolean preparing;
    private boolean requested;
    private boolean paused;

    VoskListeningEngine(Activity activity, Callback callback) {
        this.activity = activity;
        this.callback = callback;
    }

    synchronized void start() {
        requested = true;
        paused = false;
        if (speechService != null) {
            speechService.setPause(false);
            callback.onReady();
            return;
        }
        if (model != null) {
            startService();
            return;
        }
        if (preparing) return;
        preparing = true;
        StorageService.unpack(activity, "model-en-us", "carmind-vosk-model",
            unpacked -> {
                synchronized (VoskListeningEngine.this) {
                    preparing = false;
                    model = unpacked;
                    if (requested) startService();
                }
            },
            error -> {
                synchronized (VoskListeningEngine.this) { preparing = false; }
                callback.onFailure("Offline voice model could not start: " + error.getMessage());
            });
    }

    private synchronized void startService() {
        if (!requested || model == null || speechService != null) return;
        try {
            Recognizer recognizer = new Recognizer(model, 16000.0f);
            speechService = new SpeechService(recognizer, 16000.0f);
            speechService.startListening(this);
            speechService.setPause(paused);
            callback.onReady();
        } catch (IOException error) {
            callback.onFailure("Offline listening could not start: " + error.getMessage());
        }
    }

    synchronized void setPaused(boolean value) {
        paused = value;
        if (speechService != null) speechService.setPause(value);
    }

    synchronized void stop() {
        requested = false;
        if (speechService != null) {
            speechService.stop();
            speechService.shutdown();
            speechService = null;
        }
    }

    synchronized void shutdown() {
        stop();
        if (model != null) {
            model.close();
            model = null;
        }
    }

    private String textFrom(String hypothesis) {
        try { return new JSONObject(hypothesis).optString("text", "").trim(); }
        catch (Exception ignored) { return ""; }
    }

    @Override public void onResult(String hypothesis) {
        String text = textFrom(hypothesis);
        if (!text.isBlank()) callback.onText(text);
    }

    @Override public void onFinalResult(String hypothesis) {
        // SpeechService emits completed phrases through onResult. Ignoring the
        // shutdown result prevents the final phrase being executed twice.
    }

    @Override public void onPartialResult(String hypothesis) {}

    @Override public void onError(Exception error) {
        callback.onFailure("Offline listening stopped: " + error.getMessage());
    }

    @Override public void onTimeout() {
        synchronized (this) {
            if (requested) {
                if (speechService != null) {
                    speechService.shutdown();
                    speechService = null;
                }
                startService();
            }
        }
    }
}
