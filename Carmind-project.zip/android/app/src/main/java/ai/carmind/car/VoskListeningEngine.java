// Copyright 2026 Ebubedike LLC.
// Uses Vosk, licensed under the Apache License 2.0.
package ai.carmind.car;

import android.app.Activity;
import android.os.Handler;
import android.os.Looper;

import org.json.JSONObject;
import org.vosk.Model;
import org.vosk.Recognizer;
import org.vosk.android.RecognitionListener;
import org.vosk.android.SpeechService;
import org.vosk.android.StorageService;

import java.io.IOException;

/** Continuous offline recognition without Android SpeechRecognizer start tones. */
final class VoskListeningEngine implements RecognitionListener {
    interface Callback {
        void onReady();
        void onText(String text);
        void onFailure(String message);
    }

    private final Activity activity;
    private final Callback callback;
    private Model model;
    private SpeechService speechService;
    private boolean preparing;
    private boolean requested;
    private boolean paused;
    private final Handler mainHandler = new Handler(Looper.getMainLooper());
    private String lastDeliveredText = "";
    private long lastDeliveredAt;
    private int restartAttempts;
    private String pendingText = "";
    private String partialText = "";
    private final Runnable pendingDelivery = this::flushPendingText;
    private static final long UTTERANCE_SETTLE_MS = 1500L;

    VoskListeningEngine(Activity activity, Callback callback) {
        this.activity = activity;
        this.callback = callback;
    }

    synchronized void start() {
        requested = true;
        paused = false;
        if (speechService != null) {
            speechService.setPause(false);
            callback.onReady();
            return;
        }
        if (model != null) {
            startService();
            return;
        }
        if (preparing) return;
        preparing = true;
        StorageService.unpack(activity, "model-en-us", "carmind-vosk-model",
            unpacked -> {
                synchronized (VoskListeningEngine.this) {
                    preparing = false;
                    model = unpacked;
                    if (requested) startService();
                }
            },
            error -> {
                synchronized (VoskListeningEngine.this) { preparing = false; }
                callback.onFailure("Offline voice model could not start: " + error.getMessage());
            });
    }

    private synchronized void startService() {
        if (!requested || model == null || speechService != null) return;
        try {
            Recognizer recognizer = new Recognizer(model, 16000.0f);
            speechService = new SpeechService(recognizer, 16000.0f);
            speechService.startListening(this);
            speechService.setPause(paused);
            restartAttempts = 0;
            callback.onReady();
        } catch (IOException error) {
            callback.onFailure("Offline listening could not start: " + error.getMessage());
        }
    }

    synchronized void setPaused(boolean value) {
        paused = value;
        if (speechService != null) speechService.setPause(value);
    }

    synchronized void restart() {
        requested = true;
        paused = false;
        mainHandler.removeCallbacks(pendingDelivery);
        pendingText = "";
        partialText = "";
        if (speechService != null) {
            speechService.stop();
            speechService.shutdown();
            speechService = null;
        }
        start();
    }

    synchronized boolean isHealthy() {
        return requested && (preparing || speechService != null);
    }

    synchronized void stop() {
        requested = false;
        mainHandler.removeCallbacks(pendingDelivery);
        pendingText = "";
        partialText = "";
        if (speechService != null) {
            speechService.stop();
            speechService.shutdown();
            speechService = null;
        }
    }

    synchronized void shutdown() {
        stop();
        if (model != null) {
            model.close();
            model = null;
        }
    }

    private String textFrom(String hypothesis) {
        try { return new JSONObject(hypothesis).optString("text", "").trim(); }
        catch (Exception ignored) { return ""; }
    }

    private String partialFrom(String hypothesis) {
        try { return new JSONObject(hypothesis).optString("partial", "").trim(); }
        catch (Exception ignored) { return ""; }
    }

    private synchronized void queueDelivery(String hypothesis) {
        String text = textFrom(hypothesis);
        if (text.isBlank()) return;
        partialText = "";
        if (pendingText.isBlank()) pendingText = text;
        else if (text.toLowerCase().startsWith(pendingText.toLowerCase())) pendingText = text;
        else if (!pendingText.equalsIgnoreCase(text)) pendingText = pendingText + " " + text;
        mainHandler.removeCallbacks(pendingDelivery);
        // Bluetooth microphones often split “Hello Mercedes” after the first
        // word. Wait for the rest of the utterance instead of executing “Hey”.
        mainHandler.postDelayed(pendingDelivery, UTTERANCE_SETTLE_MS);
    }

    private void flushPendingText() {
        final String text;
        synchronized (this) {
            text = (pendingText.isBlank() ? partialText : pendingText).trim();
            pendingText = "";
            partialText = "";
        }
        if (text.isBlank()) return;
        long now = System.currentTimeMillis();
        if (text.equalsIgnoreCase(lastDeliveredText) && now - lastDeliveredAt < 1800) return;
        lastDeliveredText = text;
        lastDeliveredAt = now;
        callback.onText(text);
    }

    @Override public void onResult(String hypothesis) {
        queueDelivery(hypothesis);
    }

    @Override public void onFinalResult(String hypothesis) {
        // Some Android audio routes only deliver the last phrase here. The
        // duplicate guard prevents a phrase already sent by onResult from
        // running twice.
        queueDelivery(hypothesis);
    }

    @Override public synchronized void onPartialResult(String hypothesis) {
        String next = partialFrom(hypothesis);
        if (next.isBlank()) return;
        // Vosk replaces partial hypotheses as the driver continues speaking.
        // Keep only the newest complete partial instead of joining fragments.
        partialText = next;
        mainHandler.removeCallbacks(pendingDelivery);
        mainHandler.postDelayed(pendingDelivery, UTTERANCE_SETTLE_MS);
    }

    @Override public void onError(Exception error) {
        boolean shouldRestart;
        synchronized (this) {
            shouldRestart = requested;
            if (speechService != null) {
                speechService.shutdown();
                speechService = null;
            }
        }
        callback.onFailure("Offline listening interrupted: " + error.getMessage());
        if (shouldRestart) scheduleRestart();
    }

    @Override public void onTimeout() {
        synchronized (this) {
            if (requested) {
                if (speechService != null) {
                    speechService.shutdown();
                    speechService = null;
                }
                startService();
            }
        }
    }

    private void scheduleRestart() {
        final int attempt;
        synchronized (this) {
            if (!requested) return;
            attempt = Math.min(++restartAttempts, 5);
        }
        mainHandler.postDelayed(() -> {
            synchronized (VoskListeningEngine.this) {
                if (requested && speechService == null) startService();
            }
        }, 500L * attempt);
    }
}
