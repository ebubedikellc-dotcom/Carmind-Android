-keepclassmembers class ai.carmind.car.CarmindBridge {
    @android.webkit.JavascriptInterface <methods>;
}
