# Third-party notices

## Vosk Android

Carmind AI uses `com.alphacephei:vosk-android:0.3.75` and the Vosk small
US-English model for continuous offline speech recognition.

- Project: https://github.com/alphacep/vosk-api
- Android demo: https://github.com/alphacep/vosk-android-demo
- Licence: Apache License 2.0
- Copyright: Alpha Cephei Inc.

The Vosk component is used only for recognising microphone input. Carmind's
selected Android text-to-speech voice remains responsible for spoken replies.
