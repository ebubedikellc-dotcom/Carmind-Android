# Third-party notices

## whisper.cpp

Carmind AI uses whisper.cpp as its primary on-device speech recognizer.

- Project: https://github.com/ggml-org/whisper.cpp
- Licence: MIT
- Model: Whisper small.en in Q5_1 quantized format

## Vosk Android

Carmind AI uses `com.alphacephei:vosk-android:0.3.75` and the Vosk small
US-English model as a compatibility fallback for devices that cannot load Whisper.

- Project: https://github.com/alphacep/vosk-api
- Android demo: https://github.com/alphacep/vosk-android-demo
- Licence: Apache License 2.0
- Copyright: Alpha Cephei Inc.

The Vosk component is used only for recognising microphone input. Carmind's
selected Android text-to-speech voice remains responsible for spoken replies.
