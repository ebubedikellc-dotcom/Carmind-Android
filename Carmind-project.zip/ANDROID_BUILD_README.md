# Carmind AI Android production build

Version 1.6.5 builds two real native Android applications. Both use the bundled
Vosk `en-us-0.22-lgraph` model for continuous offline listening without the
repeating Android SpeechRecognizer start tone. The model is downloaded during
the cloud build and packaged inside both APKs, so the primary command listener
continues to work without internet after installation.

Both applications use the shared Carmind server at `https://carmindai.online`
for configured online services. Carmind's local command engine remains the
controller for Android actions; the server cannot silently execute device
commands.

This repository contains one Carmind interface and two native Android applications: **Carmind Car** for an Android car screen and **Carmind Mobile** for a normal Android phone. Carmind Mobile asks whether the vehicle has an Android screen. With a screen, the apps pair over Bluetooth and the phone hotspot supplies internet; without a screen, Carmind Mobile runs the full assistant and sends audio through the vehicle’s ordinary Bluetooth system.

## CodeMagic: build the installable APK

1. Extract the delivery ZIP before uploading it. `codemagic.yaml` must be visible at the top level of the GitHub repository, beside `package.json` and the `android` folder.
2. Commit and push all files to the `main` branch.
3. In CodeMagic, press **Check for configuration file** or refresh the application.
4. Select **Carmind AI - Installable Debug APK**.
5. Start the build. Download both APKs from **Artifacts**: `app-debug.apk` (**Carmind Car**) and `phone-debug.apk` (**Carmind Mobile**).

The sideloadable Carmind Mobile debug APK intentionally excludes WhatsApp
notification-listener access because Play Protect can completely block an
unreviewed APK that declares this sensitive capability. Voice, media,
Bluetooth, hotspot, maps, contacts and calling tests remain available. Enable
WhatsApp notification integration only in the signed production distribution
after store review and explicit customer consent.

The debug APK is signed automatically with the Android debug certificate and can
be installed directly for acceptance testing. The release workflow creates the
production Android App Bundle; Play Store distribution still requires the
owner's private release signing identity.

## GitHub Actions alternative

Open **Actions**, select **Build Carmind Android APK**, then choose **Run workflow**. The downloadable artifact is named `Carmind-AI-car-and-phone-APKs`.

## Release signing

The release workflow creates an unsigned Android App Bundle. Before Play Store publishing, create and securely store the owner's release keystore, add it to CodeMagic's Android code-signing identities, and connect that signing identity to the release workflow. Never commit the keystore or its passwords to GitHub.

## Android restrictions that remain visible to the driver

- Modern Android requires a user confirmation panel for Wi-Fi changes and Bluetooth pairing/connection.
- Contact calling requires Contacts and Phone permission.
- The two devices must first be paired in Android Bluetooth settings. Carmind then connects them locally using its private Bluetooth service.
- WhatsApp access is limited to new Android notifications the user explicitly permits. Full chat history is not accessible; voice reply works only when WhatsApp exposes a notification reply action.
- Voice recognition quality and offline support depend on the speech services and offline language packs installed on the Android device.
- Google routing, YouTube search, Spotify search, payment verification, and connected AI answers require their server-side API configuration and internet access.
- A true locked-car launcher/kiosk requires device-owner provisioning by the vehicle/tablet administrator; an ordinary APK cannot silently make itself device owner.
