const server = String(import.meta.env.VITE_CONTROL_SERVER_URL || "https://carmindai.online").replace(/\/$/, "");

export function serverConfigured() { return Boolean(server); }

async function request(path, payload, options = {}) {
  if (!server) throw new Error("server-not-configured");
  const response = await fetch(`${server}${path}`, {
    method: payload === undefined ? "GET" : "POST",
    headers: {
      ...(payload === undefined ? {} : {"Content-Type":"application/json"}),
      ...(options.token ? {Authorization:`Bearer ${options.token}`} : {}),
    },
    body: payload === undefined ? undefined : JSON.stringify(payload),
    signal: AbortSignal.timeout(options.timeout || 15000),
  });
  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.error || `server-${response.status}`);
  }
  return options.raw ? response : response.json();
}

async function transcribeAudio(audio, language = "en-NG", prompt = "") {
  if (!server) throw new Error("server-not-configured");
  const response = await fetch(`${server}/api/stt`, {
    method: "POST",
    headers: {"Content-Type":audio.type || "audio/webm", "X-Carmind-Language":language, "X-Carmind-Prompt":String(prompt).slice(0, 1000)},
    body: audio,
    signal: AbortSignal.timeout(30000),
  });
  const result = await response.json().catch(() => ({}));
  if (!response.ok) throw new Error(result.error || `server-${response.status}`);
  return result;
}

export const serverApi = {
  status: () => request("/api/integrations/status"),
  publicConfig: () => request("/api/public/config"),
  translate: (text, sourceLanguage, targetLanguage) => request("/api/translate", {text, sourceLanguage, targetLanguage}),
  converse: (message, context) => request("/api/ai/respond", {message, context}),
  resolveIntent: (transcript, context) => request("/api/ai/intent", {transcript, context}, {timeout:10000}),
  route: (origin, destination, options = {}) => request("/api/maps/route", {origin, destination, ...options}),
  youtube: (query) => request("/api/media/youtube", {query}, {timeout:1800}),
  spotify: (query) => request("/api/media/spotify", {query}, {timeout:1800}),
  checkout: (plan, currency, amount, customerEmail) => request("/api/payments/checkout", {plan, currency, amount, customerEmail}),
  speech: (text, language) => request("/api/tts", {text, language}, {raw:true, timeout:30000}),
  transcribe: transcribeAudio,
  registerDevice: (data) => request("/api/devices/register", data),
  phoneConnectionStatus: (token) => request("/api/phone-connection/status", undefined, {token}),
  subscriptionStatus: (token) => request("/api/subscription/status", undefined, {token}),
};
