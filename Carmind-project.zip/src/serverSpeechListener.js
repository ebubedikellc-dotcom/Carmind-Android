const recorderType = () => ["audio/webm;codecs=opus", "audio/mp4", "audio/webm", "audio/ogg;codecs=opus"]
  .find((type) => globalThis.MediaRecorder?.isTypeSupported?.(type)) || "";

export function serverSpeechAvailable() {
  return Boolean(globalThis.MediaRecorder && navigator.mediaDevices?.getUserMedia && globalThis.AudioContext);
}

export function createServerSpeechListener({transcribe, onTranscript, onState, onError}) {
  let stream, recorder, context, analyser, frame, running = false, busy = false;
  let speaking = false, speechStartedAt = 0, lastVoiceAt = 0, noiseFloor = 0.008;
  let pending = "none", lastFlushAt = 0;
  function flush(mode) {
    if (!recorder || recorder.state !== "recording" || pending !== "none") return;
    pending = mode;
    recorder.requestData();
  }
  function monitor() {
    if (!running || !analyser) return;
    const values = new Float32Array(analyser.fftSize);
    analyser.getFloatTimeDomainData(values);
    const rms = Math.sqrt(values.reduce((sum, value) => sum + value * value, 0) / values.length);
    const now = performance.now(), threshold = Math.max(0.018, noiseFloor * 2.7);
    if (!speaking) noiseFloor = noiseFloor * 0.96 + Math.min(rms, 0.04) * 0.04;
    if (rms > threshold) {
      if (!speaking) speechStartedAt = now;
      speaking = true; lastVoiceAt = now; onState?.("hearing");
    }
    if (speaking && now - lastVoiceAt > 1450 && now - speechStartedAt > 650) {
      speaking = false; flush("transcribe");
    } else if (!speaking && now - lastFlushAt > 8000) flush("discard");
    frame = requestAnimationFrame(monitor);
  }
  async function start() {
    const liveTrack = stream?.getAudioTracks?.().some((track) => track.readyState === "live");
    if (running && liveTrack && recorder?.state === "recording" && context?.state !== "closed") return;
    // Safari can suspend or end the real microphone while the page is in the
    // background without updating Carmind's visible Listening state. Dispose
    // that stale session and request a genuinely live stream on return.
    if (running || stream || recorder || context) await stop();
    stream = await navigator.mediaDevices.getUserMedia({audio:{echoCancellation:true, noiseSuppression:true, autoGainControl:true, channelCount:1}});
    context = new AudioContext();
    analyser = context.createAnalyser(); analyser.fftSize = 1024;
    context.createMediaStreamSource(stream).connect(analyser);
    const type = recorderType();
    recorder = new MediaRecorder(stream, type ? {mimeType:type, audioBitsPerSecond:32000} : undefined);
    recorder.ondataavailable = async (event) => {
      const mode = pending; pending = "none"; lastFlushAt = performance.now();
      if (mode !== "transcribe" || !event.data?.size || busy || !running) return;
      busy = true; onState?.("understanding");
      try {
        const result = await transcribe(event.data), text = String(result?.text || "").trim();
        if (text && running) onTranscript?.(text);
      } catch (error) { onError?.(error); }
      finally { busy = false; }
    };
    recorder.start(); running = true; lastFlushAt = performance.now(); onState?.("listening"); monitor();
  }
  async function stop() {
    running = false; cancelAnimationFrame(frame); pending = "discard";
    try { if (recorder?.state !== "inactive") recorder?.stop(); } catch {}
    stream?.getTracks().forEach((track) => track.stop());
    try { await context?.close(); } catch {}
    recorder = stream = context = analyser = null; speaking = false;
  }
  return {
    start,
    stop,
    get active() {
      return Boolean(running && recorder?.state === "recording" &&
        stream?.getAudioTracks?.().some((track) => track.readyState === "live"));
    },
  };
}
