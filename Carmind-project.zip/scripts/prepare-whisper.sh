#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "$0")/.." && pwd)"
native_dir="$project_root/android/app/src/main/cpp"
whisper_dir="$native_dir/whisper.cpp"
model_file="$project_root/android/app/src/main/assets/model-whisper.bin"

if [ ! -f "$whisper_dir/CMakeLists.txt" ]; then
  git clone --depth 1 https://github.com/ggml-org/whisper.cpp.git "$whisper_dir"
fi

if [ ! -s "$model_file" ]; then
  mkdir -p "$(dirname "$model_file")"
  curl --fail --location --retry 4 --retry-delay 3 \
    "https://huggingface.co/ggerganov/whisper.cpp/resolve/main/ggml-small.en-q5_1.bin" \
    --output "$model_file"
fi

test -s "$whisper_dir/CMakeLists.txt"
test "$(wc -c < "$model_file")" -gt 100000000
