import { normalizeLocalCommand } from "../src/languagePacks.js";

const cases = [
  ["dearest would", "decrease volume"],
  ["bring the sound down small", "decrease volume"],
  ["sound dey too loud", "decrease volume"],
  ["in greece world", "increase volume"],
  ["raise am small", "increase volume"],
  ["blue car mine a video", "play carmind demo video"],
  ["blew karma in demo video", "play carmind demo video"],
  ["where did the more audio", "play carmind demo audio"],
  ["where the demo audio", "play carmind demo audio"],
  ["play the demo audio", "play carmind demo audio"],
  ["wear did the more video", "play carmind demo video"],
  ["give me music for me", "play music"],
  ["i wan hear Burna Boy", "play burna boy"],
  ["continue am", "continue playing"],
  ["change this song", "next song"],
  ["former song", "previous song"],
  ["off the video", "stop music"],
  ["make the video big", "fullscreen"],
  ["carry me go Lagos", "drive me to lagos"],
  ["show me road to Onitsha", "drive me to onitsha"],
  ["make we move Nnewi", "drive me to nnewi"],
  ["we are going Abuja", "drive me to abuja"],
  ["take me my house", "drive me home"],
  ["take me my workplace", "drive me to my office"],
  ["end the direction", "stop navigation"],
  ["different road", "find another route"],
  ["no toll gate", "avoid toll roads"],
  ["petrol station around here", "find nearest filling station"],
  ["hospital close by", "find nearest hospital"],
  ["enter set in", "open settings"],
  ["click assistance", "open assistant"],
  ["show direction", "open drive"],
  ["open player", "open media"],
  ["open train my camera", "open train my carmind"],
  ["open to my comment", "open train my carmind"],
  ["open train my comment", "open train my carmind"],
  ["open to my common", "open train my carmind"],
  ["show subscription", "open payment"],
  ["open how to use", "open help and learning"],
  ["show phone connection", "open connected apps"],
  ["take me back", "go back"],
  ["give a call to my wife", "call my wife"],
  ["ring my father", "call my father"],
  ["pick the incoming call", "answer call"],
  ["cut the phone call", "reject call"],
  ["on wife eye", "turn on wifi"],
  ["off why fi", "turn off wifi"],
  ["enable blue tooth", "turn on bluetooth"],
  ["disable bluetooth", "turn off bluetooth"],
  ["pair me with bluetooth Toyota", "connect me to bluetooth toyota"],
  ["join me to wifi Samsung", "connect me to wifi samsung"],
  ["I lost a big business deal today", "i lost a big business deal today"],
  ["the blue car passed me", "the blue car passed me"],
  ["open my comments", "open my comments"],
  ["I am bored today", "i am bored today"],
];

for (const verb of ["bring", "turn", "take", "shift"])
  for (const noun of ["sound", "voice", "volume"])
    for (const direction of ["down", "low", "lower", "small"])
      cases.push([`${verb} the ${noun} ${direction}`, "decrease volume"]);
for (const verb of ["bring", "turn", "take", "shift"])
  for (const noun of ["sound", "voice", "volume"])
    for (const direction of ["up", "high", "higher"])
      cases.push([`${verb} the ${noun} ${direction}`, "increase volume"]);
for (const verb of ["put", "give", "bring", "start"])
  for (const kind of ["music", "song", "audio", "video"])
    cases.push([`${verb} me the ${kind}`, `play ${kind}`]);

let failures = 0;
for (const [spoken, expected] of cases) {
  const actual = normalizeLocalCommand(spoken, "en-NG");
  if (actual !== expected) {
    failures += 1;
    console.error(`FAIL: ${spoken}\n  expected: ${expected}\n  received: ${actual}`);
  }
}
if (failures) process.exit(1);
console.log(`${cases.length} Nigerian-English command tests passed.`);
