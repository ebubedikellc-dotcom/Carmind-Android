import { normalizeLocalCommand, requestedVolumeLevel, findMeaningTrainingMatch } from "../src/languagePacks.js";

const cases = [
  ["dearest would", "decrease volume"],
  ["bring the sound down small", "decrease volume"],
  ["sound dey too loud", "decrease volume"],
  ["in greece world", "increase volume"],
  ["raise am small", "increase volume"],
  ["reduce the volume to 60 percent", "decrease volume to 60 percent"],
  ["increase the volume to eighty percent", "increase volume to eighty percent"],
  ["set volume to 40 percent", "set volume to 40 percent"],
  ["blue car mine a video", "play carmind demo video"],
  ["blew karma in demo video", "play carmind demo video"],
  ["where did the more audio", "play carmind demo audio"],
  ["where the demo audio", "play carmind demo audio"],
  ["play the demo audio", "play carmind demo audio"],
  ["wear did the more video", "play carmind demo video"],
  ["give me music for me", "play music"],
  ["i wan hear Burna Boy", "play burna boy"],
  ["continue am", "continue playing"],
  ["change this song", "next song"],
  ["former song", "previous song"],
  ["off the video", "stop music"],
  ["make the video big", "fullscreen"],
  ["carry me go Lagos", "drive me to lagos"],
  ["show me road to Onitsha", "drive me to onitsha"],
  ["make we move Nnewi", "drive me to nnewi"],
  ["we are going Abuja", "drive me to abuja"],
  ["take me my house", "drive me home"],
  ["take me my workplace", "drive me to my office"],
  ["end the direction", "stop navigation"],
  ["different road", "find another route"],
  ["no toll gate", "avoid toll roads"],
  ["petrol station around here", "find nearest filling station"],
  ["hospital close by", "find nearest hospital"],
  ["enter set in", "open settings"],
  ["click assistance", "open assistant"],
  ["show direction", "open drive"],
  ["open player", "open media"],
  ["open train my camera", "open train my carmind"],
  ["open to my comment", "open train my carmind"],
  ["open train my comment", "open train my carmind"],
  ["open to my common", "open train my carmind"],
  ["show subscription", "open payment"],
  ["open how to use", "open help and learning"],
  ["show phone connection", "open connected apps"],
  ["take me back", "go back"],
  ["give a call to my wife", "call my wife"],
  ["ring my father", "call my father"],
  ["pick the incoming call", "answer call"],
  ["cut the phone call", "reject call"],
  ["on wife eye", "turn on wifi"],
  ["off why fi", "turn off wifi"],
  ["enable blue tooth", "turn on bluetooth"],
  ["disable bluetooth", "turn off bluetooth"],
  ["pair me with bluetooth Toyota", "connect me to bluetooth toyota"],
  ["join me to wifi Samsung", "connect me to wifi samsung"],
  ["I lost a big business deal today", "i lost a big business deal today"],
  ["the blue car passed me", "the blue car passed me"],
  ["open my comments", "open my comments"],
  ["I am bored today", "i am bored today"],
  ["play burna boy on spotty pie", "play burna boy on spotify"],
  ["play calm down on sportify", "play calm down on spotify"],
  ["play sunrise drive on you tube", "play sunrise drive on youtube"],
  ["play city lights on u tube", "play city lights on youtube"],
  ["play combine them on youtube", "play calm down on youtube"],
  ["play calm down on Spotify by Davido", "play calm down on spotify by davido"],
  ["play Die on Your Matter by Wizkid on Spotify", "play die on your matter by wizkid on spotify"],
  ["play Night Bridge on carmine media", "play night bridge on carmind media"],
  ["find it anywhere", "find it anywhere"],
  ["take up the volume", "increase volume"],
  ["bring down the volume", "decrease volume"],
  ["put the sound louder", "increase volume"],
  ["make it quieter", "decrease volume"],
];

for (const verb of ["bring", "turn", "take", "shift"])
  for (const noun of ["sound", "voice", "volume"])
    for (const direction of ["down", "low", "lower", "small"])
      cases.push([`${verb} the ${noun} ${direction}`, "decrease volume"]);
for (const verb of ["bring", "turn", "take", "shift"])
  for (const noun of ["sound", "voice", "volume"])
    for (const direction of ["up", "high", "higher"])
      cases.push([`${verb} the ${noun} ${direction}`, "increase volume"]);
for (const verb of ["put", "give", "bring", "start"])
  for (const kind of ["music", "song", "audio", "video"])
    cases.push([`${verb} me the ${kind}`, `play ${kind}`]);

let failures = 0;
for (const [spoken, expected] of cases) {
  const actual = normalizeLocalCommand(spoken, "en-NG");
  if (actual !== expected) {
    failures += 1;
    console.error(`FAIL: ${spoken}\n  expected: ${expected}\n  received: ${actual}`);
  }
}
if (failures) process.exit(1);
console.log(`${cases.length} Nigerian-English command tests passed.`);

for (const [spoken, expected] of [
  ["reduce volume to 60%", 60],
  ["decrease the volume to 60percent", 60],
  ["set volume to sixty percent", 60],
  ["increase the sound to eighty", 80],
  ["set volume to two", 2],
]) {
  const actual = requestedVolumeLevel(normalizeLocalCommand(spoken, "en-NG"));
  if (actual !== expected) {
    console.error(`FAIL: ${spoken}\n  expected volume: ${expected}\n  received: ${actual}`);
    process.exit(1);
  }
}
console.log("Exact spoken volume tests passed.");

const trainedQuestions = [
  {q:"What should I call you?", a:"My name is Mercedes."},
  {q:"How are you today?", a:"I am fine."},
  {q:"Tell me a joke", a:"A driving joke."},
  {q:"Do you remember me?", a:"Yes."},
];
for (const [spoken, answer] of [
  ["What are you called?", "My name is Mercedes."],
  ["How have you been?", "I am fine."],
  ["Say something funny please", "A driving joke."],
  ["Have we met before?", "Yes."],
]) {
  const actual = findMeaningTrainingMatch(spoken, trainedQuestions, {assistant:"Mercedes"})?.a;
  if (actual !== answer) {
    console.error(`FAIL meaning match: ${spoken}\n  expected: ${answer}\n  received: ${actual}`);
    process.exit(1);
  }
}
console.log("Different-wording training tests passed.");
