import { readFile } from "node:fs/promises";

const read = (file) => readFile(file, "utf8");
const readOptional = (file) => read(file).catch(() => "");
const [app, native, listener, phoneService, carGradle, phoneGradle, settings, codemagic, workflow, prepare, server, control, schema] = await Promise.all([
  read("src/main.jsx"),
  read("android/app/src/main/java/ai/carmind/car/MainActivity.java"),
  read("android/app/src/main/java/ai/carmind/car/VoskListeningEngine.java"),
  read("android/phone/src/main/java/ai/carmind/phone/PhoneLinkService.java"),
  read("android/app/build.gradle"),
  read("android/phone/build.gradle"),
  read("android/settings.gradle"),
  read("codemagic.yaml"),
  read(".github/workflows/android-apk.yml"),
  read("scripts/prepare-vosk.sh"),
  readOptional("release/control-server/server.mjs"),
  readOptional("release/control-server/control.html"),
  readOptional("release/control-server/schema.sql"),
]);

const checks = [
  [native.includes("new VoskListeningEngine") && !native.includes("new WhisperListeningEngine"), "MainActivity uses only Vosk"],
  [listener.includes("StorageService.unpack") && listener.includes("model-en-us") && listener.includes("new SpeechService"), "offline Vosk model and listener are wired"],
  [listener.includes("void restart()") && listener.includes("boolean isHealthy()") && native.includes("voskListening.restart()"), "listener restarts after returning to Carmind"],
  [listener.includes("SPEECH_END_SILENCE_MS = 800L") && listener.includes("BLUETOOTH_OPENING_GRACE_MS = 2200L") && listener.includes("deliveryDelayFor") && listener.includes("scheduleRestart"), "adaptive speech ending uses 0.8 seconds and reserves 2.2 seconds for incomplete Bluetooth wake fragments"],
  [listener.includes("partialFrom") && listener.includes("partialText = next") && listener.includes("pendingText.isBlank() ? partialText"), "partial Bluetooth phrases are retained until the driver finishes"],
  [listener.includes("looksLikeNoise") && listener.includes("isAudioStalled") && native.includes("prepareRecognitionInputRoute"), "car Bluetooth routing, noise rejection and silent-stream recovery are wired"],
  [carGradle.includes("vosk-android") && phoneGradle.includes("vosk-android"), "both Android apps include Vosk"],
  [!carGradle.toLowerCase().includes("whisper") && !phoneGradle.toLowerCase().includes("whisper") && !settings.toLowerCase().includes("whisper"), "Whisper.cpp build references are absent"],
  [prepare.includes("vosk-model-en-us-0.22-lgraph.zip") && prepare.includes('test -s "$model_dir/uuid"'), "cloud build verifies the Vosk model"],
  [codemagic.includes("scripts/prepare-vosk.sh") && !codemagic.toLowerCase().includes("whisper"), "CodeMagic prepares only Vosk"],
  [workflow.includes("scripts/prepare-vosk.sh") && !workflow.toLowerCase().includes("whisper"), "GitHub Actions prepares only Vosk"],
  [native.includes("releaseStalledSpeech") && native.includes("2500L") && native.includes("prepareSpeechOutputRoute()"), "speech-output watchdog restores listening"],
  [native.includes("onResume()") && native.includes("!voskListening.isHealthy()"), "returning to the app health-checks the microphone"],
  [app.includes("Contacts & Calls") && app.includes("Should I look on YouTube or Spotify?"), "newer contact and media commands remain present"],
  [app.includes("When I hear") && app.includes("voiceSamples:[...samples.slice(-79)") && app.includes("Saving Settings must never erase pronunciation corrections"), "spoken personal pronunciation corrections are remembered locally"],
  [app.includes('name: "Rainy Road"') && app.includes('name: "Golden Morning"'), "test media remains present"],
  [native.includes('"whatsapp audio"') && native.includes('"/android/media/"') && native.includes("if (path.isBlank()) return false"), "car media rejects chat media and unknown folders by default"],
  [native.includes('path.startsWith("songs/")') && native.includes('path.startsWith("music videos/")') && !native.includes('path.startsWith("dcim/")'), "car library accepts only explicit music, songs, movies and video folders"],
  [native.includes("durationMs < 30_000L") && native.includes("durationMs < 15_000L"), "short voice notes and status clips are excluded"],
  [phoneService.includes("allowedPhoneMusic") && phoneService.includes('"/android/media/"') && phoneService.includes('path.startsWith("songs/")'), "connected-phone playback applies the same private-media boundary"],
  [app.includes("carmindMediaSection") && app.includes("My music") && app.includes("My videos"), "Media is separated into voice-addressable Music and Videos sections"],
  [app.includes('Playing the item in Now Playing.') && app.includes('window.carmindMediaAction("resume")'), "plain Play resumes the exact Now Playing item"],
  [app.includes('item.album || ""') && app.includes('item.folder || ""'), "voice search indexes title, artist, album, folder and genre metadata"],
  [native.includes("MediaStore.Audio.Media.ALBUM") && native.includes('item.put("folder", path)'), "Android customer media metadata is indexed for voice matching"],
  [app.includes("Nigerian Intonation Mode") && app.includes("Nigerian Voice Setup") && app.includes("voiceProfileVersion: VOICE_PROFILE_VERSION"), "Nigerian voice calibration is visible and saved locally"],
  [app.includes('const plans = [') && app.includes('["open media", "go to media", "show my music and videos"]') && app.includes("[0, 1, 2].map") && app.includes("Use your own words") && app.includes("phrases[index].action") && app.includes("phraseOnly: true"), "each command action asks for three customer-chosen personal phrasings"],
  [app.includes('className="card calibration-card" data-no-translate') && app.includes('key={`voice-prompt-${step}`}') && app.includes('(actions[Math.floor(step / 3)] || "complete").toUpperCase()'), "voice training always displays the live action instead of a translated stale prompt"],
  [app.includes("soundsConsistent") && app.includes("learnedByRepetition: true") && app.includes("Repeat your own wording") && app.includes("count < 3") && !app.includes("expectedAlternative"), "the customer repeats their own wording three times before a personal pronunciation mapping can pass"],
  [app.includes("continueAfterPass") && app.includes("Passed. I understand this command. Moving to the next command.") && app.includes("acceptingRef.current") && app.includes("index !== stepRef.current"), "training advances with a current attempt reference instead of rejecting later answers from an old render"],
  [app.includes("Three voice attempts") && app.includes("Attempt ${attempt + 1} passed") && app.includes("Talk now — Carmind is listening.") && app.includes("Talk now.`"), "training shows all three passes and tells the customer exactly when to speak"],
  [app.includes("const localMediaLookup") && app.includes('openExternalTarget("https://open.spotify.com")'), "local look-for commands and direct Spotify opening are wired"],
  [app.includes("serverApi.resolveIntent") && app.includes("serverApi.converse") && app.includes("!resolvedByAi"), "unknown phrases route to Qwen and conversation without weakening the local command guard"],
  [!server || (server.includes("qwenCompletion") && server.includes("grokCompletion") && server.includes("QWEN_CONFIDENCE_THRESHOLD") && server.includes('provider:"grok"')), "server uses Qwen for meaning and Grok for conversation"],
  [!control || (control.includes("Qwen meaning + Grok conversation") && control.includes("GROK_API_KEY") && control.includes("QWEN_API_KEY")), "private control panel contains separate Qwen and Grok settings"],
  [!schema || (schema.includes("CREATE TABLE IF NOT EXISTS admin_settings") && schema.includes("CREATE TABLE IF NOT EXISTS audit_log")), "encrypted settings and audit records are persisted"],
];

const failed = checks.filter(([ok]) => !ok).map(([, name]) => name);
if (failed.length) throw new Error(`Carmind app wiring failed: ${failed.join(", ")}`);
console.log("Both Carmind Android apps use Vosk locally; Qwen meaning and Grok conversation routing are wired.");
