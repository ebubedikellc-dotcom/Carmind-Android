import { readFile } from "node:fs/promises";

const files = Object.fromEntries(await Promise.all([
  ["api", "src/serverApi.js"],
  ["app", "src/main.jsx"],
  ["native", "android/app/src/main/java/ai/carmind/car/MainActivity.java"],
  ["bridge", "android/app/src/main/java/ai/carmind/car/CarmindBridge.java"],
  ["carManifest", "android/app/src/main/AndroidManifest.xml"],
  ["phoneManifest", "android/phone/src/main/AndroidManifest.xml"],
  ["vosk", "android/app/src/main/java/ai/carmind/car/VoskListeningEngine.java"],
  ["phone", "android/phone/build.gradle"],
  ["carGradle", "android/app/build.gradle"],
  ["phoneService", "android/phone/src/main/java/ai/carmind/phone/PhoneLinkService.java"],
  ["settings", "android/settings.gradle"],
  ["codemagic", "codemagic.yaml"],
  ["prepare", "scripts/prepare-vosk.sh"],
].map(async ([key, file]) => [key, await readFile(file, "utf8")])))

const checks = [
  [files.api.includes('https://carmindai.online'), "shared production server URL"],
  [!files.app.includes('serverApi.resolveIntent') && !files.app.includes('serverApi.converse'), "voice commands and trained answers do not wait for remote Qwen"],
  [files.app.includes('nativeStartTimer') && files.native.includes('startHandsFreeListening(recognitionLanguage)'), "automatic microphone startup and resume"],
  [files.native.includes('new String[]{Manifest.permission.RECORD_AUDIO}') && files.native.includes('carmindNativeListeningState(true)'), "separate microphone permission and listening handshake"],
  [files.native.includes('webView.postDelayed(this::requestCorePermissions, 900)') && files.native.includes('optionalPermissionsRequested'), "first-launch permission flow continues after microphone approval without reopening"],
  [files.native.includes('carmindNativeCalibrationReady') && files.native.includes('carmindNativeCalibrationError') && files.app.includes('Preparing the microphone'), "voice calibration waits for the real native microphone and reports silence"],
  [files.native.includes('voskListening.start()') && !files.native.includes('WhisperListeningEngine'), "Vosk is the only primary full-app listener"],
  [files.native.includes('carmindNativeListeningPreparing') && files.app.includes('carmindNativeListeningPreparing'), "full-app listener reports preparing until the native engine is ready"],
  [files.prepare.includes('vosk-model-en-us-0.22-lgraph.zip') && files.prepare.includes('model-en-us') && files.prepare.includes('--retry-all-errors'), "larger offline Vosk model with resilient cloud-build download"],
  [files.native.includes('Manifest.permission.READ_MEDIA_AUDIO') && files.native.includes('Manifest.permission.READ_MEDIA_VIDEO') && files.native.includes('Manifest.permission.READ_CONTACTS') && files.native.includes('Manifest.permission.CALL_PHONE') && files.carManifest.includes('android.permission.READ_MEDIA_VIDEO') && files.phoneManifest.includes('android.permission.READ_MEDIA_VIDEO'), "declared and runtime contacts, direct-call, music and video permissions"],
  [files.native.includes('ContactsContract.CommonDataKinds.Phone') && files.native.includes('Intent.ACTION_CALL') && files.phoneService.includes('ContactsContract.CommonDataKinds.Phone') && files.phoneService.includes('Intent.ACTION_CALL'), "contact lookup and direct-call execution on car device or connected phone"],
  [files.phoneService.includes('MediaStore.Audio.Media.EXTERNAL_CONTENT_URI') && files.phoneService.includes('player.start()'), "connected-phone music lookup and immediate playback"],
  [files.native.includes('getDeviceMediaLibrary()') && files.native.includes('MediaStore.Audio.Media.EXTERNAL_CONTENT_URI') && files.native.includes('MediaStore.Video.Media.EXTERNAL_CONTENT_URI') && files.bridge.includes('getDeviceMediaLibrary()') && files.app.includes('carmindRefreshDeviceLibrary'), "automatic Android music and video discovery in Carmind Media"],
  [files.vosk.includes('SpeechService') && files.vosk.includes('startListening(this)'), "continuous silent Vosk recognition service"],
  [files.carGradle.includes("net.java.dev.jna:jna:5.13.0@aar") && files.phone.includes("net.java.dev.jna:jna:5.13.0@aar") && files.vosk.includes('model.close()'), "Vosk JNA runtime is included for both Android applications"],
  [files.vosk.includes('@Override public void onFinalResult') && files.vosk.includes('deliver(hypothesis)') && files.vosk.includes('scheduleRestart()'), "final speech is delivered once and interrupted microphones recover automatically"],
  [files.native.includes('if (listeningRequested) voskListening.start()') && files.native.includes('else startHandsFreeListening(recognitionLanguage)'), "listener is reacquired after permissions, calls, media routes and returning to Carmind"],
  [!files.app.includes('Customer Demo') && !files.app.includes('Public preview') && !files.app.includes('29°C Lagos'), "production app identity contains no demo-user or invented weather labels"],
  [files.app.includes('isPlaybackVoiceCommand(raw, understood, profile.assistant)') && files.app.includes('setTimeout(resumeListening, 120)'), "hands-free commands stay active during Media and Drive playback"],
  [files.app.includes('window.carmindDuck?.(true)') && files.app.includes('window.carmindDuck?.(false)'), "navigation and assistant speech duck then restore media"],
  [files.phone.includes("main.assets.srcDirs = ['../app/src/main/assets']"), "Mobile shared Carmind interface"],
  [files.settings.includes("include ':app'") && files.settings.includes("include ':phone'"), "Car and Mobile build modules"],
  [files.codemagic.includes('name: Open Carmind project') && files.codemagic.includes('test -s "$CM_BUILD_DIR/carmind_build/package-lock.json"'), "CodeMagic opens the tablet-upload ZIP before npm ci"],
  [files.codemagic.includes('rm -rf "$CM_BUILD_DIR/carmind_build"') && files.codemagic.includes('cd "$CM_BUILD_DIR/carmind_build"') && files.codemagic.includes('carmind_build/android/phone/build/outputs/apk/debug/*.apk'), "CodeMagic builds in a clean isolated directory and collects both APKs"],
];

const failed = checks.filter(([ok]) => !ok).map(([, name]) => name);
if (failed.length) throw new Error(`Carmind app wiring failed: ${failed.join(", ")}`);
console.log("Both Carmind Android apps use the restored local Vosk listening and Carmind command flow.");
