import { readFile } from "node:fs/promises";

const files = Object.fromEntries(await Promise.all([
  ["api", "src/serverApi.js"],
  ["app", "src/main.jsx"],
  ["native", "android/app/src/main/java/ai/carmind/car/MainActivity.java"],
  ["phone", "android/phone/build.gradle"],
  ["settings", "android/settings.gradle"],
  ["codemagic", "codemagic.yaml"],
].map(async ([key, file]) => [key, await readFile(file, "utf8")])))

const checks = [
  [files.api.includes('https://carmindai.online'), "shared production server URL"],
  [files.api.includes('/api/ai/intent'), "Qwen meaning-resolution endpoint"],
  [files.app.includes('serverApi.resolveIntent'), "Carmind intent fallback"],
  [files.app.includes('serverApi.converse'), "Carmind conversation fallback"],
  [files.app.includes('nativeStartTimer') && files.native.includes('startHandsFreeListening(recognitionLanguage)'), "automatic microphone startup and resume"],
  [files.native.includes('new String[]{Manifest.permission.RECORD_AUDIO}') && files.native.includes('carmindNativeListeningState(true)'), "separate microphone permission and listening handshake"],
  [files.app.includes('isPlaybackVoiceCommand(raw, understood, profile.assistant)') && files.app.includes('setTimeout(resumeListening, 120)'), "hands-free commands stay active during Media and Drive playback"],
  [files.app.includes('window.carmindDuck?.(true)') && files.app.includes('window.carmindDuck?.(false)'), "navigation and assistant speech duck then restore media"],
  [files.phone.includes("main.assets.srcDirs = ['../app/src/main/assets']"), "Mobile shared Carmind interface"],
  [files.settings.includes("include ':app'") && files.settings.includes("include ':phone'"), "Car and Mobile build modules"],
  [files.codemagic.includes('name: Open Carmind project') && files.codemagic.includes('test -s package-lock.json'), "CodeMagic opens the tablet-upload ZIP before npm ci"],
];

const failed = checks.filter(([ok]) => !ok).map(([, name]) => name);
if (failed.length) throw new Error(`Carmind app wiring failed: ${failed.join(", ")}`);
console.log("Both Carmind Android apps are wired to the shared server intent and conversation flow.");
