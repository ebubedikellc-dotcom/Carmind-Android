import { readFile } from "node:fs/promises";

const files = Object.fromEntries(await Promise.all([
  ["api", "src/serverApi.js"],
  ["app", "src/main.jsx"],
  ["phone", "android/phone/build.gradle"],
  ["settings", "android/settings.gradle"],
].map(async ([key, file]) => [key, await readFile(file, "utf8")])))

const checks = [
  [files.api.includes('https://carmindai.online'), "shared production server URL"],
  [files.api.includes('/api/ai/intent'), "Qwen meaning-resolution endpoint"],
  [files.app.includes('serverApi.resolveIntent'), "Carmind intent fallback"],
  [files.app.includes('serverApi.converse'), "Carmind conversation fallback"],
  [files.phone.includes("main.assets.srcDirs = ['../app/src/main/assets']"), "Mobile shared Carmind interface"],
  [files.settings.includes("include ':app'") && files.settings.includes("include ':phone'"), "Car and Mobile build modules"],
];

const failed = checks.filter(([ok]) => !ok).map(([, name]) => name);
if (failed.length) throw new Error(`Carmind app wiring failed: ${failed.join(", ")}`);
console.log("Both Carmind Android apps are wired to the shared server intent and conversation flow.");
