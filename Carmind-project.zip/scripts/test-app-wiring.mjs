import { readFile } from "node:fs/promises";

const read = (file) => readFile(file, "utf8");
const [app, native, listener, phoneService, carGradle, phoneGradle, settings, codemagic, workflow, prepare] = await Promise.all([
  read("src/main.jsx"),
  read("android/app/src/main/java/ai/carmind/car/MainActivity.java"),
  read("android/app/src/main/java/ai/carmind/car/VoskListeningEngine.java"),
  read("android/phone/src/main/java/ai/carmind/phone/PhoneLinkService.java"),
  read("android/app/build.gradle"),
  read("android/phone/build.gradle"),
  read("android/settings.gradle"),
  read("codemagic.yaml"),
  read(".github/workflows/android-apk.yml"),
  read("scripts/prepare-vosk.sh"),
]);

const checks = [
  [native.includes("new VoskListeningEngine") && !native.includes("new WhisperListeningEngine"), "MainActivity uses only Vosk"],
  [listener.includes("StorageService.unpack") && listener.includes("model-en-us") && listener.includes("new SpeechService"), "offline Vosk model and listener are wired"],
  [listener.includes("void restart()") && listener.includes("boolean isHealthy()") && native.includes("voskListening.restart()"), "listener restarts after returning to Carmind"],
  [listener.includes("UTTERANCE_SETTLE_MS = 1500L") && listener.includes("queueDelivery") && listener.includes("scheduleRestart"), "Bluetooth-split phrases settle and interrupted listening restarts"],
  [listener.includes("partialFrom") && listener.includes("partialText = next") && listener.includes("pendingText.isBlank() ? partialText"), "partial Bluetooth phrases are retained until the driver finishes"],
  [carGradle.includes("vosk-android") && phoneGradle.includes("vosk-android"), "both Android apps include Vosk"],
  [!carGradle.toLowerCase().includes("whisper") && !phoneGradle.toLowerCase().includes("whisper") && !settings.toLowerCase().includes("whisper"), "Whisper.cpp build references are absent"],
  [prepare.includes("vosk-model-en-us-0.22-lgraph.zip") && prepare.includes('test -s "$model_dir/uuid"'), "cloud build verifies the Vosk model"],
  [codemagic.includes("scripts/prepare-vosk.sh") && !codemagic.toLowerCase().includes("whisper"), "CodeMagic prepares only Vosk"],
  [workflow.includes("scripts/prepare-vosk.sh") && !workflow.toLowerCase().includes("whisper"), "GitHub Actions prepares only Vosk"],
  [native.includes("releaseStalledSpeech") && native.includes("2500L") && native.includes("prepareSpeechOutputRoute()"), "speech-output watchdog restores listening"],
  [native.includes("onResume()") && native.includes("!voskListening.isHealthy()"), "returning to the app health-checks the microphone"],
  [app.includes("Contacts & Calls") && app.includes("Should I look on YouTube or Spotify?"), "newer contact and media commands remain present"],
  [app.includes("When I hear") && app.includes("voiceSamples:[...samples.slice(-79)") && app.includes("Saving Settings must never erase pronunciation corrections"), "spoken personal pronunciation corrections are remembered locally"],
  [app.includes('name: "Rainy Road"') && app.includes('name: "Golden Morning"'), "test media remains present"],
  [native.includes('"whatsapp audio"') && native.includes('"/android/media/"') && native.includes("if (path.isBlank()) return false"), "car media rejects chat media and unknown folders by default"],
  [native.includes('path.startsWith("songs/")') && native.includes('path.startsWith("music videos/")') && !native.includes('path.startsWith("dcim/")'), "car library accepts only explicit music, songs, movies and video folders"],
  [native.includes("durationMs < 30_000L") && native.includes("durationMs < 15_000L"), "short voice notes and status clips are excluded"],
  [phoneService.includes("allowedPhoneMusic") && phoneService.includes('"/android/media/"') && phoneService.includes('path.startsWith("songs/")'), "connected-phone playback applies the same private-media boundary"],
  [app.includes("carmindMediaSection") && app.includes("My music") && app.includes("My videos"), "Media is separated into voice-addressable Music and Videos sections"],
];

const failed = checks.filter(([ok]) => !ok).map(([, name]) => name);
if (failed.length) throw new Error(`Carmind app wiring failed: ${failed.join(", ")}`);
console.log("Both Carmind Android apps use the restored local Vosk listener and contain no Whisper.cpp build dependency.");
