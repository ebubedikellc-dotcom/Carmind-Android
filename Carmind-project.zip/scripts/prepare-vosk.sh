#!/usr/bin/env bash
set -euo pipefail

project_root="$(cd "$(dirname "$0")/.." && pwd)"
model_dir="$project_root/android/app/src/main/assets/model-en-us"
build_dir="$project_root/.build/vosk"
archive="$build_dir/vosk-model-en-us-0.22-lgraph.zip"

if [ ! -s "$model_dir/am/final.mdl" ]; then
  mkdir -p "$build_dir" "$project_root/android/app/src/main/assets"
  curl --fail --location --retry 8 --retry-all-errors --retry-delay 4 \
    --connect-timeout 30 --continue-at - \
    "https://alphacephei.com/vosk/models/vosk-model-en-us-0.22-lgraph.zip" \
    --output "$archive"
  unzip -q -o "$archive" -d "$build_dir"
  rm -rf "$model_dir"
  mv "$build_dir/vosk-model-en-us-0.22-lgraph" "$model_dir"
fi

test -s "$model_dir/am/final.mdl"
test -s "$model_dir/conf/model.conf"
