# Carmind AI — Source Delivery

This release contains two separate deliverables:

- `carmind-main-app-source.zip`: the GitHub-ready Carmind web application source built today.
- `carmind-control-server.zip`: the private server package for owner administration and time-limited treatment links.

The server package now includes a real private control page at `/control`,
encrypted database-backed API/business settings, a Dockerfile and a one-command
Docker Compose installation with PostgreSQL plus a private Qwen3 8B model through
Ollama. No Gemini or paid conversation API key is used. Whisper hears speech,
Qwen resolves intended meaning, and Carmind alone validates and executes commands.

## What is working in the current web application

- Registration and editable driver profile
- Custom assistant name and spoken welcome
- Chrome speech recognition and text-to-speech
- Continuous-listening recovery while the page remains active
- Screen Wake Lock while listening where Android Chrome supports it
- Multilingual microphone, voice, translation and emotional-meaning layers
- Voice navigation between Carmind screens
- Saved Home and Office demonstration routes
- One-box global and personal training
- Internal music/video library and imported car-storage files
- Voice media commands, mood search, title/artist search and volume control
- Subscription/trial screens and owner-configurable international pricing
- Separate `/control` owner administration route in the current web build
- Server fallback for AI conversation, translation and cloud speech
- Protected Google Routes, YouTube search and Spotify search server endpoints
- Flexible custom wake-name recognition, including names such as Mercedes G63
- Phone Connection page with server-controlled free/paid/maintenance states
- Carmind Car and Carmind Mobile connectivity included with the main subscription
- Carmind Mobile full assistant with “car with Android screen” and “car without Android screen” setup modes

## Native Android boundaries

The web build cannot provide unrestricted background microphone capture or control a second phone. Use the included Carmind Car and Carmind Mobile APKs. Dedicated-device kiosk ownership and Android Auto projection still require administrator/OEM provisioning beyond an ordinary installed APK.

Production hardening should add:

- Media3 `ExoPlayer`, `MediaSession` and `MediaSessionService`
- Android location foreground services for journey tracking
- Android lock-task mode only on an allowlisted fully managed/dedicated device
- Android Keystore for device secrets
- A server-verified subscription entitlement with signed offline grace data

## Required production integrations

Qwen conversation and meaning resolution are self-hosted by the server package. The server `.env.example` lists separate credentials required for optional cloud speech, Google Routes, YouTube and Spotify. Until those credentials are supplied, Carmind keeps its local fallbacks and does not invent a successful connection.

Payment providers require provider-specific checkout creation and signed webhook verification. Do not mark subscriptions paid from a browser redirect alone.

## Security boundaries

- Keep API keys, payment secrets, database credentials and treatment signing keys on the server.
- Do not commit `.env` files.
- Do not use a treatment link as remote shell access.
- Revoke treatment links after use and keep audit records.
- The current web control route was intentionally left open for testing. Protect or remove it before a commercial release.

## Build the web source

Run `npm ci`, then `npm run build`. The generated `dist` folder is the deployable web build. Do not upload `node_modules` to GitHub.
