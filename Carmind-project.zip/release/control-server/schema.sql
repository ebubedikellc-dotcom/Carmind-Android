CREATE TABLE IF NOT EXISTS treatment_links (
  id BIGSERIAL PRIMARY KEY,
  token_hash TEXT UNIQUE NOT NULL,
  created_by TEXT NOT NULL,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  expires_at TIMESTAMPTZ NOT NULL,
  revoked_at TIMESTAMPTZ,
  redeemed_at TIMESTAMPTZ,
  redeemed_device_id TEXT,
  allowed_scope TEXT[] NOT NULL DEFAULT ARRAY['diagnostics','configuration'],
  CHECK (expires_at > created_at)
);

CREATE INDEX IF NOT EXISTS treatment_links_expiry_idx ON treatment_links(expires_at);

CREATE TABLE IF NOT EXISTS audit_log (
  id BIGSERIAL PRIMARY KEY,
  occurred_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  actor TEXT NOT NULL,
  action TEXT NOT NULL,
  target TEXT,
  details JSONB NOT NULL DEFAULT '{}'::jsonb
);

CREATE TABLE IF NOT EXISTS admin_settings (
  setting_key TEXT PRIMARY KEY,
  encrypted_value TEXT NOT NULL,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_by TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS customer_accounts (
  id UUID PRIMARY KEY,
  email TEXT UNIQUE NOT NULL,
  display_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS customer_devices (
  id UUID PRIMARY KEY,
  customer_id UUID NOT NULL REFERENCES customer_accounts(id) ON DELETE CASCADE,
  install_id TEXT UNIQUE NOT NULL,
  device_type TEXT NOT NULL CHECK (device_type IN ('car','phone')),
  device_name TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  last_seen_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS customer_devices_customer_idx ON customer_devices(customer_id);

CREATE TABLE IF NOT EXISTS subscriptions (
  customer_id UUID PRIMARY KEY REFERENCES customer_accounts(id) ON DELETE CASCADE,
  provider TEXT NOT NULL,
  plan TEXT NOT NULL CHECK (plan IN ('monthly','yearly')),
  status TEXT NOT NULL DEFAULT 'active',
  current_period_end TIMESTAMPTZ NOT NULL,
  last_payment_reference TEXT,
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

CREATE INDEX IF NOT EXISTS subscriptions_expiry_idx ON subscriptions(current_period_end);

CREATE TABLE IF NOT EXISTS payment_events (
  provider TEXT NOT NULL,
  event_id TEXT NOT NULL,
  received_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  customer_email TEXT,
  payment_reference TEXT,
  PRIMARY KEY(provider,event_id)
);

CREATE TABLE IF NOT EXISTS phone_pairings (
  id UUID PRIMARY KEY,
  customer_id UUID NOT NULL REFERENCES customer_accounts(id) ON DELETE CASCADE,
  car_device_id UUID NOT NULL REFERENCES customer_devices(id) ON DELETE CASCADE,
  phone_device_id UUID REFERENCES customer_devices(id) ON DELETE CASCADE,
  pairing_code_hash TEXT NOT NULL,
  expires_at TIMESTAMPTZ NOT NULL,
  paired_at TIMESTAMPTZ,
  revoked_at TIMESTAMPTZ,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  CHECK (expires_at > created_at)
);

CREATE INDEX IF NOT EXISTS phone_pairings_code_idx ON phone_pairings(pairing_code_hash, expires_at);
