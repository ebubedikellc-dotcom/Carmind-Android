# Carmind Control Server

This package belongs on the private server, not in the public app repository. It provides Carmind's protected AI, translation, speech, Google Routes, YouTube search, Spotify search, shared Carmind Car/Mobile feature policy and signed treatment-link integration layer. It now installs a private Qwen3 8B model through Ollama: Whisper supplies text, Qwen resolves the intended meaning, Carmind validates the result against its command and training rules, and the device's selected British voice speaks the answer. Qwen never executes a device action directly.

## Installation

### One-upload Docker installation (recommended)

1. Upload this complete folder to the server and extract it.
2. Copy `.env.example` to `.env`, set `POSTGRES_PASSWORD`, and replace every
   required placeholder.
3. Run `docker compose up -d --build`.
4. Allow the first start to download Qwen3 8B (approximately 5.2 GB). Check progress with `docker compose logs -f ollama-model`.
5. Put an HTTPS reverse proxy in front of port 8080.
6. Open `https://your-server.example/control`.

Use a server with at least 16 GB RAM and at least 15 GB free disk space for Qwen3 8B plus the application and database. Ollama is not exposed to the public internet; only the Carmind server can reach it on the private Docker network. No Gemini, OpenAI, or other paid conversation API key is required.

### Manual installation

1. Create a PostgreSQL database and run `schema.sql`.
2. Copy `.env.example` to `.env` and replace every placeholder.
3. Run `npm install --omit=dev`.
4. Start behind HTTPS with `npm start` under systemd, Docker, or another process supervisor.
5. Restrict the control panel and treatment-link creation endpoint to the owner. Never expose `ADMIN_API_TOKEN` to the app or browser.
6. Set `VITE_CONTROL_SERVER_URL` in the customer-app build to this server's public HTTPS origin.

Open `https://your-server.example/control` after deployment. Sign in with the
private `ADMIN_API_TOKEN`. The owner control page stores API, pricing and payout
settings encrypted in PostgreSQL; secret values are never returned unmasked.

## Integration status endpoint

`GET /api/integrations/status` reports only whether each provider has been configured. It never returns secret values.

Provider endpoints:

- `POST /api/ai/respond`
- `POST /api/ai/intent` — repairs uncertain Nigerian-English/noisy transcripts into an allowed Carmind command
- `POST /api/translate`
- `POST /api/tts`
- `POST /api/maps/route`
- `POST /api/media/youtube`
- `POST /api/media/spotify`
- `POST /api/payments/checkout`
- `POST /api/payments/webhook`
- `GET /api/subscription/status`
- `POST /api/devices/register`
- `GET /api/phone-connection/status`
## Connected apps subscription rule

`PHONE_CONNECTION_ENABLED` is a maintenance switch for Carmind Car and Carmind Mobile communication. Connected-app functions have no separate charge; they are included in the customer’s normal monthly or yearly Carmind subscription.

For automatic monthly/yearly access, choose Paystack or Flutterwave in the
control panel, add the provider secret key and webhook secret, and point the
provider webhook to `https://YOUR-DOMAIN/api/payments/webhook`. Carmind verifies
the provider signature, records each payment once, and extends the registered
customer’s subscription. A browser redirect is never treated as proof of payment.

Google Routes, YouTube, Spotify and optional cloud speech remain unavailable until their matching environment variables are filled. Qwen conversation and Nigerian-English meaning resolution work locally after the Docker model download completes. Payment checkout and webhook verification must be configured for the payment provider chosen by the owner.

Create a link by sending `POST /api/admin/treatment-links` with `Authorization: Bearer <ADMIN_API_TOKEN>` and JSON such as `{ "hours": 3 }`.

The returned link opens Carmind with a one-time random treatment token. Carmind exchanges it for a signed session that expires at the same time as the link. Treatment scope is limited to diagnostics and configuration; it does not provide shell access, database exports, passwords, payment secrets or arbitrary code execution.
