# Carmind AI Verification Checklist

## Verified in this release

- Production web build completes successfully.
- Main JavaScript bundle and media assets compile into the deployable output.
- Control-server source passes the Node syntax checker.
- Treatment-link durations are restricted to 1, 2, 3, 5 or 24 hours.
- Treatment tokens use cryptographically random values and are stored only as SHA-256 hashes.
- Treatment sessions are signed, expire automatically and are limited to diagnostics/configuration scope.
- Admin, signing, database and payment secrets are excluded from the public app source.
- Speech command handlers cover greetings, emotional support, screen navigation, route demonstration, media search, playback, seeking and volume.
- Web listening requests Screen Wake Lock and automatically recovers after ordinary recognition shutdowns while the page remains visible.
- The control server rejects oversized request bodies and uses parameterized PostgreSQL queries.
- The private server control page loads successfully at `/control`.
- Owner API, pricing and payout settings are encrypted with AES-256-GCM before database storage.
- Server health and control-page HTTP smoke tests pass.
- Nigerian-English intent tests cover imperfect grammar and common Pidgin commands.
- Bundled MP3 and MP4 files are valid playable media files.

## Must be tested after deployment

- Microphone permission and speech recognition on each target Android head unit.
- Installed TTS voices for every selected language.
- YouTube/Spotify account authorization and their own autoplay policies.
- Real map provider key, routing, geocoding, live GPS and rerouting.
- Payment-provider checkout, webhook signature verification, renewals and failed-payment locking.
- Full encrypted-setting save/read tests against the production PostgreSQL database.
- HTTPS, DNS, PostgreSQL TLS, backups, firewall and server monitoring.
- Treatment-link creation, redemption, expiry and revocation against the deployed server.

## Requires the native Android project

- Always-on/background wake-word service.
- Reliable microphone capture while the UI is not visible.
- Device-wide Wi-Fi/Bluetooth/system-volume control subject to Android permission and policy.
- Media indexing from vehicle storage and reliable background playback.
- Genuine Android Auto/Automotive integration.
- Lock-task/kiosk mode with owner-PIN exit on a managed/dedicated device.
- Background GPS navigation and audio focus/ducking.
- Installable APK/AAB and physical-device acceptance testing.

The web source must not be renamed as an APK. A native Android implementation and device test remain a separate release stage.
