plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "online.carmindai.app"
    compileSdk = 35

    defaultConfig {
        applicationId = "online.carmindai.app"
        minSdk = 26
        targetSdk = 35
        versionCode = 120
        versionName = "1.2.0-final-stack"
        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions { jvmTarget = "17" }
    buildFeatures { aidl = true }
}

dependencies {
    implementation("androidx.core:core-ktx:1.15.0")
    implementation("androidx.activity:activity-ktx:1.10.1")
    // Free offline speech stack (Apache-2.0)
    implementation("net.java.dev.jna:jna:5.18.1@aar")
    implementation("com.alphacephei:vosk-android:0.3.75@aar")
    // Optional advanced Android control. Requires user-installed Shizuku/Sui.
    implementation("dev.rikka.shizuku:api:13.1.5")
    implementation("dev.rikka.shizuku:provider:13.1.5")
    // Free offline speech stack (Apache-2.0)
    // Optional advanced Android control. Requires user-installed Shizuku/Sui.
    testImplementation("junit:junit:4.13.2")
}
