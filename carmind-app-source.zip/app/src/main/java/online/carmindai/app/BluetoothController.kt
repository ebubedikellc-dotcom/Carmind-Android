package online.carmindai.app
import android.Manifest
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import java.util.Locale
class BluetoothController(private val activity:Activity){
 fun connectNamed(name:String):String{
  val a=BluetoothAdapter.getDefaultAdapter()?:return "Bluetooth is not available."
  if(Build.VERSION.SDK_INT>=31 && ContextCompat.checkSelfPermission(activity,Manifest.permission.BLUETOOTH_CONNECT)!=PackageManager.PERMISSION_GRANTED) return "Bluetooth permission is required before I can see paired devices."
  if(!a.isEnabled){activity.startActivity(Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE));return "Bluetooth is off. I opened the Bluetooth request first."}
  val w=name.trim().lowercase(Locale.getDefault()); @Suppress("MissingPermission") val ds=a.bondedDevices?:emptySet<BluetoothDevice>(); @Suppress("MissingPermission") val m=ds.firstOrNull{(it.name?:"").lowercase(Locale.getDefault())==w}?:ds.firstOrNull{(it.name?:"").lowercase(Locale.getDefault()).contains(w)}
  if(m==null){activity.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS));return "I could not find a paired Bluetooth device called $name. I opened Bluetooth devices."}
  activity.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); @Suppress("MissingPermission") return "I found ${m.name}. I opened Bluetooth so Android can complete the connection."
 }
 fun disconnectNamed(name:String):String{activity.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS));return "I opened Bluetooth devices so $name can be disconnected. Android restricts silent profile disconnection."}
}
