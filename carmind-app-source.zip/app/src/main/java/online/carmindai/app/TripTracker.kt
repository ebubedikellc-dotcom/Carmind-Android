package online.carmindai.app

import android.location.Location
import java.util.Locale

class TripTracker(private val prefs: AppPrefs) {
    private var last: Location? = null

    fun onLocation(location: Location) {
        val prev = last
        if (prev != null) {
            val d = prev.distanceTo(location)
            // Ignore unrealistic jumps and very tiny GPS noise.
            if (d in 2f..2500f) {
                prefs.tripDistanceMeters = prefs.tripDistanceMeters + d
            }
        } else if (prefs.tripStartedAt == 0L) {
            prefs.tripStartedAt = System.currentTimeMillis()
        }
        last = Location(location)
    }

    fun finishTrip(): String? {
        val started = prefs.tripStartedAt
        if (started == 0L) return null
        val now = System.currentTimeMillis()
        val mins = ((now - started) / 60000L).coerceAtLeast(1)
        val km = prefs.tripDistanceMeters / 1000f
        val summary = if (km >= 1f) {
            "Trip complete. You travelled ${String.format(Locale.US, "%.1f", km)} kilometers in about $mins minutes."
        } else {
            "Trip complete. You travelled about ${prefs.tripDistanceMeters.toInt()} meters in about $mins minutes."
        }
        prefs.lastTripSummary = summary
        prefs.tripStartedAt = 0L
        prefs.tripDistanceMeters = 0f
        last = null
        return summary
    }

    fun currentSummary(): String {
        val started = prefs.tripStartedAt
        val mins = if (started > 0) ((System.currentTimeMillis() - started) / 60000L).coerceAtLeast(0) else 0
        val km = prefs.tripDistanceMeters / 1000f
        return "This trip is ${String.format(Locale.US, "%.1f", km)} kilometers so far and about $mins minutes."
    }
}
