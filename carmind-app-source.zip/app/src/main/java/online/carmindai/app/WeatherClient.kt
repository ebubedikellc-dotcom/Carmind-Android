package online.carmindai.app

import android.location.Location
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.Locale

data class WeatherReport(
    val temperatureC: Double,
    val apparentC: Double?,
    val windKmh: Double?,
    val weatherCode: Int
) {
    fun spoken(): String {
        val condition = when (weatherCode) {
            0 -> "clear"
            1, 2 -> "partly cloudy"
            3 -> "cloudy"
            45, 48 -> "foggy"
            51, 53, 55, 56, 57 -> "drizzling"
            61, 63, 65, 66, 67 -> "raining"
            71, 73, 75, 77 -> "snowing"
            80, 81, 82 -> "showery"
            85, 86 -> "snowy"
            95, 96, 99 -> "stormy"
            else -> "mixed"
        }
        val temp = temperatureC.toInt()
        val feels = apparentC?.toInt()
        val wind = windKmh?.toInt()
        return buildString {
            append("It is $temp degrees Celsius and $condition")
            if (feels != null && kotlin.math.abs(feels - temp) >= 2) append(". It feels like $feels degrees")
            if (wind != null && wind >= 20) append(". Winds are around $wind kilometers per hour")
            append(".")
        }
    }
}

object WeatherClient {
    fun fetch(location: Location): Result<WeatherReport> =
        fetchFromCarMind(location).recoverCatching { fetchDirect(location).getOrThrow() }

    private fun fetchFromCarMind(location: Location): Result<WeatherReport> = runCatching {
        val url = URL("https://carmindai.online/api/integrations/weather?lat=${location.latitude}&lng=${location.longitude}")
        parse(url, "CarMindAI/7.0")
    }

    private fun fetchDirect(location: Location): Result<WeatherReport> = runCatching {
        val lat = String.format(Locale.US, "%.5f", location.latitude)
        val lon = String.format(Locale.US, "%.5f", location.longitude)
        val url = URL(
            "https://api.open-meteo.com/v1/forecast" +
                "?latitude=$lat&longitude=$lon" +
                "&current=temperature_2m,apparent_temperature,weather_code,wind_speed_10m" +
                "&timezone=auto"
        )
        parse(url, "CarMindAI/7.0-fallback")
    }

    private fun parse(url: URL, ua: String): WeatherReport {
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 12_000
            readTimeout = 12_000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", ua)
        }
        try {
            val body = conn.inputStream.bufferedReader().use { it.readText() }
            val root = JSONObject(body)
            val current = if (root.has("current")) root.getJSONObject("current") else root
            return WeatherReport(
                temperatureC = current.getDouble("temperature_2m"),
                apparentC = current.optDouble("apparent_temperature").takeUnless { it.isNaN() },
                windKmh = current.optDouble("wind_speed_10m").takeUnless { it.isNaN() },
                weatherCode = current.optInt("weather_code", -1)
            )
        } finally {
            conn.disconnect()
        }
    }
}
