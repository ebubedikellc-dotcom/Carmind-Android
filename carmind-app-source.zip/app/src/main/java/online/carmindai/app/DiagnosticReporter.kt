package online.carmindai.app

import android.content.Context
import android.os.Build
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.concurrent.Executors

class DiagnosticReporter(
    private val context: Context,
    private val prefs: AppPrefs
) {
    private val executor = Executors.newSingleThreadExecutor()
    private val endpoint = "https://carmindai.online/api/commerce/diagnostics/report"

    fun report(
        category: String,
        event: String,
        status: String = "ok",
        detail: String = "",
        code: String = "",
        commandType: String = "",
        service: String = "",
        destination: String = "",
        permission: String = "",
        source: String = "android"
    ) {
        executor.execute {
            runCatching {
                val body = JSONObject()
                    .put("installIdHash", sha256(prefs.installId))
                    .put("customerId", prefs.customerId)
                    .put("device", "${Build.MANUFACTURER} ${Build.MODEL}")
                    .put("androidVersion", Build.VERSION.RELEASE ?: "")
                    .put("appVersion", "22.0.0")
                    .put("category", category.take(60))
                    .put("event", event.take(100))
                    .put("status", status.take(40))
                    .put("detail", detail.take(300))
                    .put("code", code.take(80))
                    .put("commandType", commandType.take(100))
                    .put("service", service.take(80))
                    .put("destination", destination.take(160))
                    .put("permission", permission.take(100))
                    .put("source", source.take(80))

                val c = URL(endpoint).openConnection() as HttpURLConnection
                c.requestMethod = "POST"
                c.connectTimeout = 5000
                c.readTimeout = 5000
                c.doOutput = true
                c.setRequestProperty("Content-Type","application/json")
                c.outputStream.use {
                    it.write(body.toString().toByteArray(StandardCharsets.UTF_8))
                }
                runCatching { c.inputStream.close() }
                c.disconnect()
            }
        }
    }

    private fun sha256(s: String): String {
        val d = MessageDigest.getInstance("SHA-256")
            .digest(s.toByteArray(StandardCharsets.UTF_8))
        return d.joinToString("") { "%02x".format(it) }
    }
}
