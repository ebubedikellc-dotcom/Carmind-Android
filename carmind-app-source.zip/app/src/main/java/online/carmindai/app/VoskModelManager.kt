package online.carmindai.app

import android.content.Context
import java.io.File
import java.io.FileOutputStream
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors
import java.util.zip.ZipInputStream

/**
 * Downloads the Apache-2.0 Vosk small English model once, then keeps it locally.
 * The model is ~40 MB. After the first successful setup, recognition can run offline.
 */
object VoskModelManager {
    private const val MODEL_URL = "https://alphacephei.com/vosk/models/vosk-model-small-en-us-0.15.zip"
    private const val MODEL_DIR = "vosk-model-small-en-us-0.15"
    private val executor = Executors.newSingleThreadExecutor()

    fun ensureModelAsync(
        context: Context,
        onReady: (File) -> Unit,
        onError: (Throwable) -> Unit
    ) {
        executor.execute {
            try {
                val finalDir = File(context.filesDir, MODEL_DIR)
                if (isReady(finalDir)) {
                    onReady(finalDir)
                    return@execute
                }
                val tmpZip = File(context.cacheDir, "$MODEL_DIR.zip.part")
                val tmpDir = File(context.filesDir, "$MODEL_DIR.tmp")
                tmpZip.delete()
                tmpDir.deleteRecursively()
                tmpDir.mkdirs()
                download(tmpZip)
                unzipStrippingTopDirectory(tmpZip, tmpDir)
                if (!isReady(tmpDir)) error("Downloaded Vosk model is incomplete")
                finalDir.deleteRecursively()
                if (!tmpDir.renameTo(finalDir)) {
                    tmpDir.copyRecursively(finalDir, overwrite = true)
                    tmpDir.deleteRecursively()
                }
                tmpZip.delete()
                onReady(finalDir)
            } catch (t: Throwable) {
                onError(t)
            }
        }
    }

    private fun isReady(dir: File): Boolean =
        dir.isDirectory && File(dir, "conf/mfcc.conf").isFile && File(dir, "am/final.mdl").isFile

    private fun download(out: File) {
        val conn = (URL(MODEL_URL).openConnection() as HttpURLConnection).apply {
            connectTimeout = 20_000
            readTimeout = 60_000
            instanceFollowRedirects = true
            setRequestProperty("User-Agent", "CarMindAI/1.1")
        }
        try {
            conn.connect()
            if (conn.responseCode !in 200..299) error("Model download HTTP ${conn.responseCode}")
            conn.inputStream.use { input ->
                FileOutputStream(out).use { output -> input.copyTo(output, 128 * 1024) }
            }
        } finally {
            conn.disconnect()
        }
    }

    private fun unzipStrippingTopDirectory(zipFile: File, destination: File) {
        val destCanonical = destination.canonicalFile
        ZipInputStream(zipFile.inputStream().buffered()).use { zin ->
            while (true) {
                val entry = zin.nextEntry ?: break
                val raw = entry.name.replace('\\', '/')
                val slash = raw.indexOf('/')
                val relative = if (slash >= 0) raw.substring(slash + 1) else raw
                if (relative.isBlank()) continue
                val out = File(destination, relative).canonicalFile
                if (!out.path.startsWith(destCanonical.path + File.separator)) error("Unsafe model ZIP path")
                if (entry.isDirectory) out.mkdirs() else {
                    out.parentFile?.mkdirs()
                    FileOutputStream(out).use { fos -> zin.copyTo(fos, 128 * 1024) }
                }
                zin.closeEntry()
            }
        }
    }
}
