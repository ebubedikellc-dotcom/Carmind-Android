package online.carmindai.app

import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.nio.charset.StandardCharsets
import java.security.MessageDigest
import java.util.concurrent.Executors

class CommerceClient {
    private val executor = Executors.newSingleThreadExecutor()
    private val base = "https://carmindai.online"

    data class State(
        val ok: Boolean,
        val customerId: String = "",
        val active: Boolean = false,
        val trialActive: Boolean = false,
        val paidActive: Boolean = false,
        val trialEndsAt: Long = 0L,
        val featureFlagsJson: String = "{}",
        val price: Double = 59500.0,
        val currency: String = "NGN",
        val message: String = "",
        val trainingBox: String = "",
        val ownerProfile: String = "",
        val maintenanceBox: String = "",
        val voiceDirectionsEnabled: Boolean = true,
        val drivingGreetingEnabled: Boolean = true,
        val drivingModeEnabled: Boolean = true,
        val floatingMicEnabled: Boolean = false,
        val autoParkingEnabled: Boolean = true,
        val error: String = ""
    )

    data class Checkout(val ok: Boolean, val url: String = "", val error: String = "")

    fun deviceHash(raw: String): String {
        val d = MessageDigest.getInstance("SHA-256").digest(raw.toByteArray(StandardCharsets.UTF_8))
        return d.joinToString("") { "%02x".format(it) }
    }

    fun register(
        installId: String,
        deviceHash: String,
        email: String,
        phone: String,
        name: String,
        callback: (State) -> Unit
    ) {
        executor.execute {
            callback(runCatching {
                val body = JSONObject()
                    .put("installId", installId)
                    .put("deviceHash", deviceHash)
                    .put("email", email)
                    .put("phone", phone)
                    .put("name", name)
                parseState(post("/api/commerce/register-device", body))
            }.getOrElse { State(false, error = it.message ?: "Registration failed") })
        }
    }

    fun entitlement(customerId: String, callback: (State) -> Unit) {
        executor.execute {
            callback(runCatching {
                val encoded = java.net.URLEncoder.encode(customerId, "UTF-8")
                parseState(get("/api/commerce/entitlement?customerId=$encoded"))
            }.getOrElse { State(false, error = it.message ?: "Entitlement check failed") })
        }
    }

    fun checkout(customerId: String, callback: (Checkout) -> Unit) {
        executor.execute {
            callback(runCatching {
                val j = post("/api/commerce/checkout", JSONObject().put("customerId", customerId))
                Checkout(j.optBoolean("ok"), j.optString("checkoutUrl"), j.optString("error"))
            }.getOrElse { Checkout(false, error = it.message ?: "Checkout failed") })
        }
    }

    private fun parseState(j: JSONObject): State {
        val e = j.optJSONObject("entitlement") ?: JSONObject()
        val cfg = j.optJSONObject("config") ?: JSONObject()
        val flags = j.optJSONObject("featureFlags")?.toString() ?: "{}"
        val appSettings = j.optJSONObject("appSettings") ?: JSONObject()
        return State(
            ok = j.optBoolean("ok"),
            customerId = j.optString("customerId"),
            active = e.optBoolean("active"),
            trialActive = e.optBoolean("trialActive"),
            paidActive = e.optBoolean("paidActive"),
            trialEndsAt = e.optLong("trialEndsAt"),
            featureFlagsJson = flags,
            price = cfg.optDouble("basePrice", 59500.0),
            currency = cfg.optString("currency", "NGN"),
            message = cfg.optString("customerPayMessage", ""),
            trainingBox = appSettings.optString("trainingBox", ""),
            ownerProfile = appSettings.optString("ownerProfile", ""),
            maintenanceBox = appSettings.optString("maintenanceBox", ""),
            voiceDirectionsEnabled = appSettings.optBoolean("voiceDirectionsEnabled", true),
            drivingGreetingEnabled = appSettings.optBoolean("drivingGreetingEnabled", true),
            drivingModeEnabled = appSettings.optBoolean("drivingModeEnabled", true),
            floatingMicEnabled = appSettings.optBoolean("floatingMicEnabled", false),
            autoParkingEnabled = appSettings.optBoolean("autoParkingEnabled", true)
        )
    }

    private fun get(path: String): JSONObject {
        val c = URL(base + path).openConnection() as HttpURLConnection
        c.requestMethod = "GET"
        c.connectTimeout = 12000
        c.readTimeout = 12000
        return read(c)
    }

    private fun post(path: String, body: JSONObject): JSONObject {
        val c = URL(base + path).openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.connectTimeout = 12000
        c.readTimeout = 12000
        c.doOutput = true
        c.setRequestProperty("Content-Type", "application/json")
        c.outputStream.use { it.write(body.toString().toByteArray(StandardCharsets.UTF_8)) }
        return read(c)
    }

    private fun read(c: HttpURLConnection): JSONObject {
        val code = c.responseCode
        val stream = if (code in 200..299) c.inputStream else c.errorStream
        val text = stream?.bufferedReader()?.use { it.readText() } ?: "{}"
        val j = JSONObject(text.ifBlank { "{}" })
        if (code !in 200..299) throw IllegalStateException(j.optString("error", "HTTP $code"))
        return j
    }
}
