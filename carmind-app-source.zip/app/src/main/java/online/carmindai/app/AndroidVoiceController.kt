package online.carmindai.app

import android.app.Activity
import android.content.Intent
import android.provider.Settings
import java.util.Locale

class AndroidVoiceController(private val activity: Activity) {

    fun handle(raw: String): String? {
        val q = raw.trim().lowercase(Locale.getDefault())
        val a11y = CarMindAccessibilityService.instance

        return when {
            q in setOf("go home","home screen","take me home screen") -> {
                if (a11y?.home() == true) "Going to the home screen."
                else needAccessibility()
            }

            q in setOf("go back","back","previous screen") -> {
                if (a11y?.back() == true) "Going back."
                else needAccessibility()
            }

            q in setOf("show recent apps","recent apps","open recent apps") -> {
                if (a11y?.recents() == true) "Opening recent apps."
                else needAccessibility()
            }

            q in setOf("open notifications","show notifications") -> {
                if (a11y?.notifications() == true) "Opening notifications."
                else needAccessibility()
            }

            q in setOf("open quick settings","show quick settings") -> {
                if (a11y?.quickSettings() == true) "Opening quick settings."
                else needAccessibility()
            }

            q in setOf("scroll down","move down","go down") -> {
                if (a11y?.scrollForward() == true) "Scrolling down."
                else needAccessibility()
            }

            q in setOf("scroll up","move up","go up") -> {
                if (a11y?.scrollBackward() == true) "Scrolling up."
                else needAccessibility()
            }

            q.startsWith("tap ") || q.startsWith("click ") || q.startsWith("press ") -> {
                val target = q.substringAfter(' ').trim()
                if (target.isBlank()) return "What should I press?"
                if (a11y?.clickText(target) == true) "Done."
                else "I could not find $target on the screen."
            }

            q.startsWith("type ") || q.startsWith("write ") -> {
                val text = q.substringAfter(' ').trim()
                if (text.isBlank()) return "What should I type?"
                if (a11y?.typeText(text) == true) "Typed."
                else "Tap the text box first, then tell me what to type."
            }

            q in setOf("enable android control","turn on android control","give carmind android control") -> {
                activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
                "Opening Accessibility settings. Enable CarMind once, then I can control more of Android by voice."
            }

            else -> null
        }
    }

    private fun needAccessibility(): String {
        activity.startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        return "CarMind Android Control is not enabled yet. I opened Accessibility settings so you can enable it once."
    }
}
