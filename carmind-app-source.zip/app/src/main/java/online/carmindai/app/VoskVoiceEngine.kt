package online.carmindai.app

import org.json.JSONObject
import org.vosk.Model
import org.vosk.Recognizer
import org.vosk.android.RecognitionListener
import org.vosk.android.SpeechService
import java.io.File

class VoskVoiceEngine {
    interface Listener {
        fun onPartial(text: String)
        fun onResult(text: String)
        fun onError(error: Throwable)
    }

    private var model: Model? = null
    private var recognizer: Recognizer? = null
    private var speech: SpeechService? = null

    @Synchronized
    fun start(modelDir: File, listener: Listener) {
        stop()
        val m = Model(modelDir.absolutePath)
        val r = Recognizer(m, 16_000.0f)
        val s = SpeechService(r, 16_000.0f)
        model = m
        recognizer = r
        speech = s
        s.startListening(object : RecognitionListener {
            override fun onPartialResult(hypothesis: String?) {
                val text = jsonText(hypothesis, "partial")
                if (text.isNotBlank()) listener.onPartial(text)
            }
            override fun onResult(hypothesis: String?) {
                val text = jsonText(hypothesis, "text")
                if (text.isNotBlank()) listener.onResult(text)
            }
            override fun onFinalResult(hypothesis: String?) {
                val text = jsonText(hypothesis, "text")
                if (text.isNotBlank()) listener.onResult(text)
            }
            override fun onError(exception: Exception?) {
                listener.onError(exception ?: IllegalStateException("Vosk recognition failed"))
            }
            override fun onTimeout() {}
        })
    }

    @Synchronized
    fun stop() {
        runCatching { speech?.stop() }
        runCatching { speech?.shutdown() }
        runCatching { recognizer?.close() }
        runCatching { model?.close() }
        speech = null
        recognizer = null
        model = null
    }

    private fun jsonText(raw: String?, key: String): String =
        runCatching { JSONObject(raw.orEmpty()).optString(key).trim() }.getOrDefault("")
}
