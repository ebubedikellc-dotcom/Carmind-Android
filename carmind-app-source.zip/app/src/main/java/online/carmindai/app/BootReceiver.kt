package online.carmindai.app

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat

/**
 * Android 14+ does not allow a BOOT_COMPLETED receiver to start a microphone
 * foreground service directly. On those versions we post a one-tap car-ready
 * notification. On older versions, where permitted, we restore listening.
 */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent?) {
        val action = intent?.action ?: return
        if (action !in setOf(Intent.ACTION_BOOT_COMPLETED, Intent.ACTION_MY_PACKAGE_REPLACED)) return

        val prefs = AppPrefs(context)
        if (!prefs.carMode || !prefs.continuousListening) return

        if (Build.VERSION.SDK_INT < 34) {
            runCatching {
                ContextCompat.startForegroundService(
                    context,
                    Intent(context, CarMindVoiceService::class.java).putExtra("enable", true)
                )
            }.onFailure { postReadyNotification(context) }
        } else {
            postReadyNotification(context)
        }
    }

    private fun postReadyNotification(context: Context) {
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "CarMind car startup", NotificationManager.IMPORTANCE_HIGH)
            )
        }
        val open = Intent(context, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TOP
            putExtra("start_listening", true)
        }
        val pi = PendingIntent.getActivity(context, 901, open, PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(context, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("CarMind AI is ready")
            .setContentText("Tap once to activate ${AppPrefs(context).assistantName} listening after car startup")
            .setContentIntent(pi)
            .setAutoCancel(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        nm.notify(901, n)
    }

    companion object { private const val CHANNEL = "carmind_boot" }
}
