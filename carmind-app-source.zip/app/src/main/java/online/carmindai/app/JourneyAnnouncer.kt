package online.carmindai.app

import android.content.Context
import android.location.Geocoder
import android.location.Location
import java.util.Locale

/**
 * Lightweight road/place transition announcer. This works without a paid maps
 * SDK. Exact "next turn" instructions can be supplied by the website/backend
 * through the native route_instruction action.
 */
class JourneyAnnouncer(private val context: Context, private val onAnnouncement: (String) -> Unit) {
    private var lastArea: String? = null
    private var lastRoad: String? = null
    private var lastAnnouncedLocation: Location? = null
    private var lastCheckAt = 0L

    fun onLocation(location: Location) {
        val now = System.currentTimeMillis()
        val moved = lastAnnouncedLocation?.distanceTo(location) ?: Float.MAX_VALUE
        if (now - lastCheckAt < 45_000L && moved < 700f) return
        lastCheckAt = now

        runCatching {
            @Suppress("DEPRECATION")
            val address = Geocoder(context, Locale.getDefault())
                .getFromLocation(location.latitude, location.longitude, 1)
                ?.firstOrNull() ?: return

            val area = listOfNotNull(address.subLocality, address.locality, address.subAdminArea)
                .firstOrNull { it.isNotBlank() }
            val road = listOfNotNull(address.thoroughfare, address.featureName)
                .firstOrNull { it.isNotBlank() && !it.equals(area, true) }

            val phrases = mutableListOf<String>()
            if (lastRoad != null && road != null && !road.equals(lastRoad, true)) {
                phrases += "You just passed $lastRoad. You are now on $road."
            } else if (lastArea != null && area != null && !area.equals(lastArea, true)) {
                phrases += "You just left $lastArea. You are now around $area."
            }

            if (phrases.isEmpty() && moved >= 3_000f && area != null) {
                phrases += "You are moving through $area${road?.let { " on $it" } ?: ""}."
            }

            if (phrases.isNotEmpty()) {
                onAnnouncement(phrases.joinToString(" "))
                lastAnnouncedLocation = Location(location)
            }
            if (area != null) lastArea = area
            if (road != null) lastRoad = road
        }
    }
}
