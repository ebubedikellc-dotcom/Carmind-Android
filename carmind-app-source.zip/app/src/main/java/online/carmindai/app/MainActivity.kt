package online.carmindai.app

import android.Manifest
import android.app.Activity
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.speech.*
import android.speech.tts.TextToSpeech
import android.webkit.*
import android.widget.Button
import android.widget.TextView
import android.view.WindowManager
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.Locale

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var talkButton: Button
    private lateinit var prefs: AppPrefs
    private lateinit var tts: TextToSpeech
    private lateinit var announcer: JourneyAnnouncer
    private var recognizer: SpeechRecognizer? = null
    private var lastLocation: Location? = null
    private var wakeArmed = false

    private val voiceBroadcast = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra("text").orEmpty()
            if (text.isNotBlank()) handleContinuousSpeech(text)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = AppPrefs(this)
        web = findViewById(R.id.webView)
        status = findViewById(R.id.statusText)
        talkButton = findViewById(R.id.talkButton)
        tts = TextToSpeech(this, this)
        announcer = JourneyAnnouncer(this) { if (prefs.announcePlaces) speak(it) }
        if (prefs.carMode) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setupWebView()
        talkButton.setOnClickListener { startListeningOnce() }
        requestNeededPermissions()
        startLocation()
        registerVoiceReceiver()
        if (prefs.continuousListening || intent.getBooleanExtra("start_listening", false)) setContinuousListening(true)
    }

    private fun setupWebView() {
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = "$userAgentString CarMindNative/3.0"
        }
        web.addJavascriptInterface(NativeBridge(this), "CarMindNative")
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                // Website media capture is denied by default; native speech owns the microphone.
                request?.deny()
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return if (uri.host?.endsWith("carmindai.online") == true) false else {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    true
                }
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                injectBridge()
                showStatus("CarMind connected")
            }
        }
        web.loadUrl("https://carmindai.online/")
    }

    private fun injectBridge() {
        val name = JSONObject.quote(prefs.assistantName)
        val js = """
            (function(){
              window.CARMIND_NATIVE = true;
              window.CARMIND_ASSISTANT_NAME = $name;
              window.CarMindApp = window.CarMindApp || {
                speak: function(t){ CarMindNative.speak(String(t||'')); },
                listen: function(){ CarMindNative.listen(); },
                action: function(action,payload){ CarMindNative.execute(JSON.stringify({action:action,payload:payload||{}})); },
                setAssistantName: function(n){ CarMindNative.setAssistantName(String(n||'')); },
                setContinuousListening: function(v){ CarMindNative.setContinuousListening(!!v); },
                state: function(){ try{return JSON.parse(CarMindNative.getState());}catch(e){return {native:true};} }
              };
              function syncAssistant(){
                try {
                  var candidate = null;
                  if (window.CARMIND_CONFIG && window.CARMIND_CONFIG.assistantName) candidate = window.CARMIND_CONFIG.assistantName;
                  if (!candidate) { var m=document.querySelector('meta[name="carmind-assistant-name"]'); if(m) candidate=m.content; }
                  if (!candidate) { var el=document.querySelector('[data-carmind-assistant-name]'); if(el) candidate=el.getAttribute('data-carmind-assistant-name')||el.textContent; }
                  if (!candidate) candidate=localStorage.getItem('carmind_assistant_name');
                  if (!candidate) {
                    var text=(document.body&&document.body.innerText)||'';
                    var mm=text.match(/Current assistant\s*\n?\s*([A-Za-z][A-Za-z0-9 _-]{1,40})/i);
                    if(mm) candidate=mm[1].trim();
                  }
                  if(candidate) CarMindNative.setAssistantName(String(candidate).trim());
                } catch(e) {}
              }
              function pushSpeechIntoWeb(text){
                try {
                  var candidates=[].slice.call(document.querySelectorAll('textarea,input[type=\"text\"]'));
                  var box=candidates.find(function(x){ var p=((x.placeholder||'')+' '+(x.getAttribute('aria-label')||'')).toLowerCase(); return /message|chat|ask|type|say/.test(p); });
                  if(!box) return;
                  var setter=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(box),'value');
                  if(setter&&setter.set) setter.set.call(box,text); else box.value=text;
                  box.dispatchEvent(new Event('input',{bubbles:true}));
                  box.dispatchEvent(new Event('change',{bubbles:true}));
                  var form=box.closest('form');
                  var btn=(form&&form.querySelector('button[type=\"submit\"]')) || [].slice.call(document.querySelectorAll('button')).find(function(b){ return /send|submit|ask/.test((b.innerText||b.getAttribute('aria-label')||'').toLowerCase()); });
                  if(btn) btn.click();
                } catch(e) {}
              }
              window.addEventListener('carmind:speech',function(e){ if(e.detail&&e.detail.text) pushSpeechIntoWeb(e.detail.text); });
              var lastSpoken='';
              function speakNewestAssistantMessage(){
                try {
                  var sels=['[data-message-author-role=\"assistant\"]','[data-role=\"assistant\"]','.assistant-message','.ai-message','.message.assistant'];
                  var nodes=[]; sels.forEach(function(s){ nodes=nodes.concat([].slice.call(document.querySelectorAll(s))); });
                  if(!nodes.length) return;
                  var txt=(nodes[nodes.length-1].innerText||nodes[nodes.length-1].textContent||'').trim();
                  if(txt && txt!==lastSpoken && txt.length<1800){ lastSpoken=txt; CarMindNative.speak(txt); }
                } catch(e) {}
              }
              syncAssistant();
              try { new MutationObserver(function(){syncAssistant();speakNewestAssistantMessage();}).observe(document.documentElement,{subtree:true,childList:true,characterData:true}); } catch(e) {}
              window.dispatchEvent(new CustomEvent('carmind:native-ready',{detail:{assistantName:$name,native:true}}));
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    fun setAssistantName(name: String) {
        val old = prefs.assistantName
        prefs.assistantName = name
        if (!old.equals(prefs.assistantName, true)) showStatus("Assistant name synced: ${prefs.assistantName}")
    }

    fun setContinuousListening(enabled: Boolean) {
        prefs.continuousListening = enabled
        val service = Intent(this, CarMindVoiceService::class.java).putExtra("enable", enabled)
        if (enabled) {
            if (!hasPermission(Manifest.permission.RECORD_AUDIO)) { requestNeededPermissions(); return }
            ContextCompat.startForegroundService(this, service)
            showStatus("Wake listening ON: Hello ${prefs.assistantName}")
        } else {
            stopService(Intent(this, CarMindVoiceService::class.java))
            showStatus("Wake listening OFF")
        }
    }

    fun startListeningOnce() {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) { requestNeededPermissions(); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { showStatus("Speech recognition unavailable"); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { showStatus("Listening…") }
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (heard.isNotBlank()) handleOneShotSpeech(heard) else showStatus("Ready")
                }
                override fun onError(error: Int) { showStatus("Ready") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            sr.startListening(recognizerIntent())
        }
    }

    private fun recognizerIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
    }

    private fun handleContinuousSpeech(text: String) {
        val low = text.lowercase(Locale.getDefault())
        val wake = prefs.assistantName.lowercase(Locale.getDefault())
        val woke = low == "hello" || low.contains("hello $wake") || low.startsWith(wake) || low.contains("hey $wake")
        if (wakeArmed) {
            wakeArmed = false
            processCommandOrConversation(text)
        } else if (woke) {
            wakeArmed = true
            speak("Hello, how can I help you?")
            emitToWeb("carmind:wake", JSONObject().put("heard", text).put("assistantName", prefs.assistantName))
        }
    }

    private fun handleOneShotSpeech(text: String) {
        val low = text.lowercase(Locale.getDefault())
        val wake = prefs.assistantName.lowercase(Locale.getDefault())
        val stripped = listOf("hello $wake", "hey $wake", wake).firstOrNull { low.startsWith(it) }
            ?.let { text.drop(it.length).trim().trimStart(',', ' ') }
        if (stripped != null && stripped.isBlank()) {
            speak("Hello, how can I help you?")
            return
        }
        processCommandOrConversation(stripped?.ifBlank { text } ?: text)
    }

    private fun processCommandOrConversation(text: String) {
        showStatus("You: ${text.take(70)}")
        val parsed = CommandParser.parse(text)
        if (parsed != null) {
            when (parsed.action) {
                "navigate" -> navigate(parsed.payload)
                "music" -> searchMusic(parsed.payload)
                "video" -> searchVideo(parsed.payload)
                "call" -> dial(parsed.payload)
                "message" -> composeMessage(parsed.payload)
            }
        } else {
            emitToWeb("carmind:speech", JSONObject().put("text", text).put("assistantName", prefs.assistantName))
        }
    }

    fun speak(text: String) {
        if (text.isBlank()) return
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, "carmind-${System.currentTimeMillis()}")
        showStatus(text.take(85))
    }

    fun executeAction(action: String, payload: JSONObject) {
        when (action.lowercase(Locale.getDefault())) {
            "speak" -> speak(payload.optString("text"))
            "listen" -> startListeningOnce()
            "navigate" -> navigate(payload.optString("destination"))
            "music" -> searchMusic(payload.optString("query"))
            "video" -> searchVideo(payload.optString("query"))
            "call" -> dial(payload.optString("number", payload.optString("contact")))
            "sms", "message" -> sms(payload.optString("number", payload.optString("contact")), payload.optString("message"))
            "set_assistant_name" -> setAssistantName(payload.optString("name"))
            "continuous_listening" -> setContinuousListening(payload.optBoolean("enabled", false))
            "route_instruction" -> speak(payload.optString("text", payload.optString("instruction")))
            "set_destination" -> { prefs.activeDestination = payload.optString("destination"); showStatus("Destination synced") }
            "announce_places" -> { prefs.announcePlaces = payload.optBoolean("enabled", true); showStatus("Journey announcements updated") }
            "car_mode" -> {
                prefs.carMode = payload.optBoolean("enabled", true)
                if (prefs.carMode) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
            else -> showStatus("Unknown action: $action")
        }
    }

    private fun navigate(destination: String) {
        if (destination.isBlank()) { speak("Where would you like to go?"); return }
        prefs.activeDestination = destination
        val googleNav = Uri.parse("google.navigation:q=${Uri.encode(destination)}")
        val geo = Uri.parse("geo:0,0?q=${Uri.encode(destination)}")
        val launched = runCatching { startActivity(Intent(Intent.ACTION_VIEW, googleNav)); true }.getOrDefault(false)
        if (!launched) runCatching { startActivity(Intent(Intent.ACTION_VIEW, geo)) }
        speak("Opening navigation to $destination")
        emitToWeb("carmind:action", JSONObject().put("action", "navigate").put("destination", destination))
    }

    private fun searchMusic(query: String) {
        if (query.isBlank()) { speak("What should I play?"); return }
        val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode("$query music")}")
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        speak("Opening music for $query")
    }

    private fun searchVideo(query: String) {
        if (query.isBlank()) { speak("Which video should I find?"); return }
        val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        speak("Opening the video search")
    }

    private fun dial(nameOrNumber: String) {
        if (nameOrNumber.isBlank()) { speak("Who should I call?"); return }
        val phone = ContactResolver.resolvePhone(this, nameOrNumber)
        if (phone == null) {
            if (!hasPermission(Manifest.permission.READ_CONTACTS) && !nameOrNumber.any { it.isDigit() }) requestNeededPermissions()
            speak("I could not find that contact. You can say the phone number instead.")
            return
        }
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phone)}")))
        speak("Opening the dialer for $nameOrNumber")
    }

    private fun composeMessage(raw: String) {
        val split = raw.split(" saying ", " message ", limit = 2)
        val who = split.firstOrNull().orEmpty()
        val message = split.getOrNull(1).orEmpty()
        sms(who, message)
    }

    private fun sms(nameOrNumber: String, message: String) {
        if (nameOrNumber.isBlank()) { speak("Who should I message?"); return }
        val phone = ContactResolver.resolvePhone(this, nameOrNumber)
        if (phone == null) { speak("I could not find that contact."); return }
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phone)}")).apply { putExtra("sms_body", message) }
        startActivity(intent)
        speak("Opening your message to $nameOrNumber")
    }

    private fun startLocation() {
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        runCatching {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10_000L, 25f, object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    lastLocation = location
                    announcer.onLocation(location)
                    emitToWeb("carmind:location", JSONObject()
                        .put("lat", location.latitude)
                        .put("lng", location.longitude)
                        .put("speedMps", location.speed)
                        .put("bearing", location.bearing)
                        .put("accuracyM", location.accuracy))
                }
            })
        }
    }

    private fun emitToWeb(event: String, detail: JSONObject) {
        val ev = JSONObject.quote(event)
        val json = detail.toString()
        web.post { web.evaluateJavascript("window.dispatchEvent(new CustomEvent($ev,{detail:$json}));", null) }
    }

    fun nativeStateJson(): String = JSONObject()
        .put("native", true)
        .put("version", "3.0.0")
        .put("assistantName", prefs.assistantName)
        .put("continuousListening", prefs.continuousListening)
        .put("carMode", prefs.carMode)
        .put("announcePlaces", prefs.announcePlaces)
        .put("activeDestination", prefs.activeDestination)
        .put("lat", lastLocation?.latitude ?: JSONObject.NULL)
        .put("lng", lastLocation?.longitude ?: JSONObject.NULL)
        .toString()

    fun showStatus(s: String) { status.text = s }

    private fun hasPermission(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun requestNeededPermissions() {
        val requested = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) requested += Manifest.permission.POST_NOTIFICATIONS
        val missing = requested.filterNot { hasPermission(it) }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 44)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 44) startLocation()
    }

    private fun registerVoiceReceiver() {
        val filter = IntentFilter(CarMindVoiceService.ACTION_HEARD)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(voiceBroadcast, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(voiceBroadcast, filter)
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            tts.language = Locale.getDefault()
            tts.setSpeechRate(0.95f)
        }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(voiceBroadcast) }
        recognizer?.destroy()
        tts.shutdown()
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
