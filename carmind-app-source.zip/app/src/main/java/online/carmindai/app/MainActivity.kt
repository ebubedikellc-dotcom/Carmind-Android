package online.carmindai.app

import android.Manifest
import android.app.Activity
import android.app.AlertDialog
import android.content.*
import android.content.pm.PackageManager
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.speech.*
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.webkit.*
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.TextView
import android.view.WindowManager
import android.view.ViewGroup
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import org.json.JSONObject
import java.util.Locale
import java.util.ArrayDeque

class MainActivity : Activity(), TextToSpeech.OnInitListener {
    private lateinit var web: WebView
    private lateinit var status: TextView
    private lateinit var talkButton: Button
    private lateinit var prefs: AppPrefs
    private lateinit var tts: TextToSpeech
    private lateinit var announcer: JourneyAnnouncer
    private lateinit var routeGuidance: RouteGuidanceManager
    private lateinit var audioFocusDucker: AudioFocusDucker
    private lateinit var tripTracker: TripTracker
    private lateinit var driveStateDetector: DriveStateDetector
    private lateinit var commerce: CommerceClient
    private lateinit var systemCommands: SystemCommandController
    private lateinit var bluetoothController: BluetoothController
    private lateinit var mediaRouter: MediaRouter
    private var ttsReady = false
    private val pendingSpeech = ArrayDeque<String>()
    private var releaseAudioFocusAfterSpeech = false
    private var lastAccessCheckAt = 0L
    private var accessCheckInFlight = false
    private var paymentDialogVisible = false
    private var recognizer: SpeechRecognizer? = null
    private var lastLocation: Location? = null
    private var wakeArmed = false
    private var restartListeningAfterSpeech = false

    private val voiceBroadcast = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            val text = intent?.getStringExtra("text").orEmpty()
            val mode = intent?.getStringExtra("mode").orEmpty()
            if (text.isNotBlank()) handleContinuousSpeech(text, mode)
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = AppPrefs(this)
        commerce = CommerceClient()
        systemCommands = SystemCommandController(this)
        bluetoothController = BluetoothController(this)
        mediaRouter = MediaRouter(this)
        web = findViewById(R.id.webView)
        status = findViewById(R.id.statusText)
        talkButton = findViewById(R.id.talkButton)
        tts = TextToSpeech(this, this)
        announcer = JourneyAnnouncer(this) { if (prefs.announcePlaces) speak(it) }
        audioFocusDucker = AudioFocusDucker(this)
        tripTracker = TripTracker(prefs)
        driveStateDetector = DriveStateDetector { parked ->
            if (prefs.autoParkingEnabled && featureEnabled("parking")) {
                prefs.parkingLat = parked.latitude
                prefs.parkingLng = parked.longitude
                prefs.parkingSavedAt = System.currentTimeMillis()
                val summary = tripTracker.finishTrip()
                if (summary != null && featureEnabled("trip")) {
                    showStatus("Trip saved; parking remembered")
                }
            }
        }
        routeGuidance = RouteGuidanceManager { speakNavigation(it) }
        if (prefs.carMode) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        setupWebView()
        talkButton.setOnClickListener { startListeningOnce() }
        requestNeededPermissions()
        startLocation()
        android.os.Handler(mainLooper).postDelayed({ maybeDrivingGreeting() }, 1800L)
        registerVoiceReceiver()
        registerCommerce()
        android.os.Handler(mainLooper).postDelayed({ maybeShowCustomerSetup() }, 900L)
        // Do not start the microphone loop until the server has confirmed access.
        // This prevents repeated recognizer start/stop sounds while entitlement is still unknown.
        if (
            prefs.profileSetupComplete &&
            prefs.commerceStatusKnown &&
            prefs.commerceAccessActive
        ) {
            prefs.continuousListening = true
            setContinuousListening(true)
        } else if (
            prefs.commerceStatusKnown &&
            prefs.commerceAccessActive &&
            intent.getBooleanExtra("start_listening", false)
        ) {
            setContinuousListening(true)
        }
    }

    private fun setupWebView() {
        with(web.settings) {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            mixedContentMode = WebSettings.MIXED_CONTENT_NEVER_ALLOW
            userAgentString = "$userAgentString CarMindNative/19.2"
        }
        web.addJavascriptInterface(NativeBridge(this), "CarMindNative")
        web.webChromeClient = object : WebChromeClient() {
            override fun onPermissionRequest(request: PermissionRequest?) {
                // Website media capture is denied by default; native speech owns the microphone.
                request?.deny()
            }
        }
        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val uri = request?.url ?: return false
                return if (uri.host?.endsWith("carmindai.online") == true) false else {
                    runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
                    true
                }
            }
            override fun onPageFinished(view: WebView?, url: String?) {
                injectBridge()
                showStatus("CarMind connected")
            }
        }
        web.loadUrl("https://carmindai.online/")
    }

    private fun injectBridge() {
        val name = JSONObject.quote(prefs.assistantName)
        val js = """
            (function(){
              window.CARMIND_NATIVE = true;
              window.CARMIND_ASSISTANT_NAME = $name;
              window.CarMindApp = window.CarMindApp || {
                speak: function(t){ CarMindNative.speak(String(t||'')); },
                listen: function(){ CarMindNative.listen(); },
                action: function(action,payload){ CarMindNative.execute(JSON.stringify({action:action,payload:payload||{}})); },
                setAssistantName: function(n){ CarMindNative.setAssistantName(String(n||'')); },
                setContinuousListening: function(v){ CarMindNative.setContinuousListening(!!v); },
                setTrainingBox: function(t){ CarMindNative.setTrainingBox(String(t||'')); },
                setOwnerProfile: function(t){ CarMindNative.setOwnerProfile(String(t||'')); },
                setVoiceDirectionsEnabled: function(v){ CarMindNative.setVoiceDirectionsEnabled(!!v); },
                setMaintenanceBox: function(t){ CarMindNative.setMaintenanceBox(String(t||'')); },
                setDrivingGreetingEnabled: function(v){ CarMindNative.setDrivingGreetingEnabled(!!v); },
                setDrivingModeEnabled: function(v){ CarMindNative.setDrivingModeEnabled(!!v); },
                setFloatingMicEnabled: function(v){ CarMindNative.setFloatingMicEnabled(!!v); },
                setFeatureFlags: function(j){ CarMindNative.setFeatureFlags(String(j||'{}')); },
                setAutoParkingEnabled: function(v){ CarMindNative.setAutoParkingEnabled(!!v); },
                setCustomerIdentity: function(n,e,p){ CarMindNative.setCustomerIdentity(String(n||''),String(e||''),String(p||'')); },
                setCustomerDisplayName: function(n){ CarMindNative.setCustomerDisplayName(String(n||'')); },
                openCustomerSetup: function(){ CarMindNative.openCustomerSetup(); },
                refreshEntitlement: function(){ CarMindNative.refreshEntitlement(); },
                openPayment: function(){ CarMindNative.openPayment(); },
                state: function(){ try{return JSON.parse(CarMindNative.getState());}catch(e){return {native:true};} }
              };
              function syncAssistant(){
                try {
                  var candidate = null;
                  if (window.CARMIND_CONFIG && window.CARMIND_CONFIG.assistantName) candidate = window.CARMIND_CONFIG.assistantName;
                  if (!candidate) { var m=document.querySelector('meta[name="carmind-assistant-name"]'); if(m) candidate=m.content; }
                  if (!candidate) { var el=document.querySelector('[data-carmind-assistant-name]'); if(el) candidate=el.getAttribute('data-carmind-assistant-name')||el.textContent; }
                  if (!candidate) candidate=localStorage.getItem('carmind_assistant_name');
                  if (!candidate) {
                    var text=(document.body&&document.body.innerText)||'';
                    var mm=text.match(/Current assistant\s*\n?\s*([A-Za-z][A-Za-z0-9 _-]{1,40})/i);
                    if(mm) candidate=mm[1].trim();
                  }
                  if(candidate) CarMindNative.setAssistantName(String(candidate).trim());
                } catch(e) {}
              }
              function pushSpeechIntoWeb(text){
                try {
                  var candidates=[].slice.call(document.querySelectorAll('textarea,input[type=\"text\"]'));
                  var box=candidates.find(function(x){ var p=((x.placeholder||'')+' '+(x.getAttribute('aria-label')||'')).toLowerCase(); return /message|chat|ask|type|say/.test(p); });
                  if(!box) return;
                  var setter=Object.getOwnPropertyDescriptor(Object.getPrototypeOf(box),'value');
                  if(setter&&setter.set) setter.set.call(box,text); else box.value=text;
                  box.dispatchEvent(new Event('input',{bubbles:true}));
                  box.dispatchEvent(new Event('change',{bubbles:true}));
                  var form=box.closest('form');
                  var btn=(form&&form.querySelector('button[type=\"submit\"]')) || [].slice.call(document.querySelectorAll('button')).find(function(b){ return /send|submit|ask/.test((b.innerText||b.getAttribute('aria-label')||'').toLowerCase()); });
                  if(btn) btn.click();
                } catch(e) {}
              }
              window.addEventListener('carmind:speech',function(e){ if(e.detail&&e.detail.text) pushSpeechIntoWeb(e.detail.text); });
              var lastSpoken='';
              function speakNewestAssistantMessage(){
                try {
                  var sels=['[data-message-author-role=\"assistant\"]','[data-role=\"assistant\"]','.assistant-message','.ai-message','.message.assistant'];
                  var nodes=[]; sels.forEach(function(s){ nodes=nodes.concat([].slice.call(document.querySelectorAll(s))); });
                  if(!nodes.length) return;
                  var txt=(nodes[nodes.length-1].innerText||nodes[nodes.length-1].textContent||'').trim();
                  if(txt && txt!==lastSpoken && txt.length<1800){ lastSpoken=txt; CarMindNative.speak(txt); }
                } catch(e) {}
              }
              syncAssistant();
              try {
                var tb = localStorage.getItem('carmind_training_box');
                if (tb) CarMindNative.setTrainingBox(tb);
                var op = localStorage.getItem('carmind_owner_profile');
                if (op) CarMindNative.setOwnerProfile(op);
                var vd = localStorage.getItem('carmind_voice_directions');
                if (vd !== null) CarMindNative.setVoiceDirectionsEnabled(vd === 'true');
                var mb = localStorage.getItem('carmind_maintenance_box');
                if (mb) CarMindNative.setMaintenanceBox(mb);
                var dg = localStorage.getItem('carmind_driving_greeting');
                if (dg !== null) CarMindNative.setDrivingGreetingEnabled(dg === 'true');
                var dm = localStorage.getItem('carmind_driving_mode');
                if (dm !== null) CarMindNative.setDrivingModeEnabled(dm === 'true');
                var fm = localStorage.getItem('carmind_floating_mic');
                if (fm !== null) CarMindNative.setFloatingMicEnabled(fm === 'true');
                var ff = localStorage.getItem('carmind_feature_flags');
                if (ff) CarMindNative.setFeatureFlags(ff);
                var ap = localStorage.getItem('carmind_auto_parking');
                if (ap !== null) CarMindNative.setAutoParkingEnabled(ap === 'true');
              } catch(e) {}
              try { new MutationObserver(function(){syncAssistant();speakNewestAssistantMessage();}).observe(document.documentElement,{subtree:true,childList:true,characterData:true}); } catch(e) {}
              window.dispatchEvent(new CustomEvent('carmind:native-ready',{detail:{assistantName:$name,native:true}}));
            })();
        """.trimIndent()
        web.evaluateJavascript(js, null)
    }

    private fun registerCommerce(force: Boolean = false) {
        val now = System.currentTimeMillis()
        if (!force && (accessCheckInFlight || now - lastAccessCheckAt < 10_000L)) return
        accessCheckInFlight = true
        lastAccessCheckAt = now
        val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val raw = "$androidId|${Build.MANUFACTURER}|${Build.MODEL}|$packageName"
        commerce.register(prefs.installId,commerce.deviceHash(raw),prefs.customerEmail,prefs.customerPhone,prefs.customerName) { state ->
            runOnUiThread {
                accessCheckInFlight = false
                if (state.ok) applyCommerceState(state) else showStatus("Access check unavailable — retrying silently")
            }
        }
    }

    fun refreshEntitlement() {
        val cid = prefs.customerId
        if (cid.isBlank()) { runOnUiThread { registerCommerce(force = true) }; return }
        if (accessCheckInFlight) return
        accessCheckInFlight = true
        commerce.entitlement(cid) { state ->
            runOnUiThread { accessCheckInFlight = false; if (state.ok) applyCommerceState(state) }
        }
    }

    private fun applyCommerceState(state: CommerceClient.State) {
        if (state.customerId.isNotBlank()) prefs.customerId = state.customerId
        prefs.commerceStatusKnown = true
        prefs.commerceAccessActive = state.active
        prefs.trialEndsAt = state.trialEndsAt
        prefs.featureFlagsJson = state.featureFlagsJson
        prefs.trainingBox = state.trainingBox
        prefs.ownerProfile = state.ownerProfile
        prefs.maintenanceBox = state.maintenanceBox
        prefs.voiceDirectionsEnabled = state.voiceDirectionsEnabled
        prefs.drivingGreetingEnabled = state.drivingGreetingEnabled
        prefs.drivingModeEnabled = state.drivingModeEnabled
        prefs.autoParkingEnabled = state.autoParkingEnabled
        if (!prefs.carNameCustomized && state.carName.isNotBlank()) prefs.carName = state.carName
        if (!prefs.wakeNameCustomized && state.wakeName.isNotBlank()) { prefs.wakeName = state.wakeName; prefs.assistantName = state.wakeName }
        if (!prefs.mediaServiceCustomized && state.preferredMediaService.isNotBlank()) prefs.preferredMediaService = state.preferredMediaService
        prefs.basePrice = state.price
        prefs.currency = state.currency
        if (state.message.isNotBlank()) prefs.paymentMessage = state.message

        // Owner controls the default. Android still requires the customer to grant overlay permission once.
        prefs.floatingMicEnabled = state.floatingMicEnabled && featureEnabled("floating_mic")
        if (prefs.floatingMicEnabled && Settings.canDrawOverlays(this)) {
            ContextCompat.startForegroundService(this, Intent(this, FloatingMicService::class.java))
        } else if (!prefs.floatingMicEnabled) {
            stopService(Intent(this, FloatingMicService::class.java))
        }

        emitToWeb("carmind:commerce", JSONObject()
            .put("active", state.active)
            .put("trialActive", state.trialActive)
            .put("paidActive", state.paidActive)
            .put("ownerFree", state.ownerFree)
            .put("legacyFree", state.legacyFree)
            .put("trialEndsAt", state.trialEndsAt)
            .put("price", state.price)
            .put("currency", state.currency)
            .put("featureFlags", JSONObject(state.featureFlagsJson)))

        if (!state.active) {
            stopService(Intent(this, CarMindVoiceService::class.java))
            showStatus("Payment required")
            showPaymentRequired()
        } else if (prefs.continuousListening) {
            // Access is confirmed: start hands-free wake listening automatically.
            setContinuousListening(true)
        }
    }

    fun setCustomerIdentity(name: String, email: String, phone: String) {
        prefs.customerName = name.trim()
        prefs.customerEmail = email.trim()
        prefs.customerPhone = phone.trim()
        registerCommerce()
    }

    fun openPayment() {
        showPaymentRequired(force = true)
    }

    private fun showPaymentRequired(force: Boolean = false) {
        if (!force && (!prefs.commerceStatusKnown || prefs.commerceAccessActive)) return
        if (paymentDialogVisible) return
        paymentDialogVisible = true

        val input = EditText(this).apply {
            hint = "Email for payment"
            inputType = android.text.InputType.TYPE_CLASS_TEXT or android.text.InputType.TYPE_TEXT_VARIATION_EMAIL_ADDRESS
            setText(prefs.customerEmail)
        }

        AlertDialog.Builder(this)
            .setTitle("CarMind payment")
            .setMessage("${prefs.paymentMessage}\n\nPrice: ${prefs.currency} ${String.format(Locale.US, "%,.0f", prefs.basePrice)}")
            .setView(input)
            .setNegativeButton("Not now") { _, _ -> paymentDialogVisible = false }
            .setOnCancelListener { paymentDialogVisible = false }
            .setPositiveButton("Pay") { _, _ ->
                paymentDialogVisible = false
                val email = input.text.toString().trim()
                if (email.isBlank()) {
                    speak("Please enter your email before payment.")
                    return@setPositiveButton
                }
                prefs.customerEmail = email
                registerCommerceAndCheckout()
            }
            .show()
    }

    private fun registerCommerceAndCheckout() {
        val androidId = Settings.Secure.getString(contentResolver, Settings.Secure.ANDROID_ID) ?: "unknown"
        val raw = "$androidId|${Build.MANUFACTURER}|${Build.MODEL}|$packageName"
        commerce.register(
            prefs.installId,
            commerce.deviceHash(raw),
            prefs.customerEmail,
            prefs.customerPhone,
            prefs.customerName
        ) { state ->
            runOnUiThread {
                if (!state.ok) {
                    showStatus("Could not prepare payment")
                    return@runOnUiThread
                }
                applyCommerceState(state)
                commerce.checkout(state.customerId) { checkout ->
                    runOnUiThread {
                        if (checkout.ok && checkout.url.startsWith("https://")) {
                            startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(checkout.url)))
                        } else {
                            showStatus(checkout.error.ifBlank { "Payment is not configured yet" })
                        }
                    }
                }
            }
        }
    }

    private fun maybeShowCustomerSetup() {
        if (isFinishing || isDestroyed) return
        if (prefs.profileSetupComplete && prefs.customerDisplayName.isNotBlank()) return

        val pad = (16 * resources.displayMetrics.density).toInt()
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, pad, pad, 0)
        }

        fun field(hintText: String, value: String): EditText =
            EditText(this).apply {
                hint = hintText
                setText(value)
                setSingleLine(true)
                layoutParams = LinearLayout.LayoutParams(
                    ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT
                )
            }

        val nameInput = field("Your name", prefs.customerDisplayName)
        val carInput = field("Car name (example: My Mercedes)", prefs.carName)
        val wakeInput = field("Wake-up name (example: Mercedes)", prefs.wakeName)
        val homeInput = field("Home location/address (optional)", prefs.homeLabel)
        val workInput = field("Work/office location (optional)", prefs.workLabel)

        val mediaLabel = TextView(this).apply {
            text = "Preferred music service (optional)"
            setPadding(0, pad / 2, 0, 0)
        }
        val mediaInput = field(
            "spotify / youtube_music / youtube",
            prefs.preferredMediaService
        )

        box.addView(nameInput)
        box.addView(carInput)
        box.addView(wakeInput)
        box.addView(homeInput)
        box.addView(workInput)
        box.addView(mediaLabel)
        box.addView(mediaInput)

        AlertDialog.Builder(this)
            .setTitle("Set up your CarMind")
            .setMessage("Tell CarMind who you are and what you want to call your car assistant.")
            .setView(box)
            .setCancelable(false)
            .setPositiveButton("Save") { _, _ ->
                val name = CustomerProfile.cleanName(nameInput.text.toString())
                prefs.customerDisplayName = name

                carInput.text.toString().trim().takeIf { it.isNotBlank() }?.let {
                    prefs.carName = it
                }
                wakeInput.text.toString().trim().takeIf { it.isNotBlank() }?.let {
                    prefs.wakeName = it
                    prefs.assistantName = it
                }

                prefs.homeLabel = homeInput.text.toString()
                prefs.workLabel = workInput.text.toString()

                prefs.preferredMediaService =
                    when (mediaInput.text.toString().trim().lowercase(Locale.getDefault())) {
                        "youtube music", "youtube_music", "yt music" -> "youtube_music"
                        "youtube", "yt" -> "youtube"
                        "spotify" -> "spotify"
                        else -> ""
                    }

                prefs.profileSetupComplete = true
                // Hands-free is the normal CarMind mode; Talk remains only a backup.
                prefs.continuousListening = true

                if (name.isNotBlank()) {
                    setCustomerIdentity(name, prefs.customerEmail, prefs.customerPhone)
                    speak("Nice to meet you $name. CarMind is ready.")
                } else {
                    registerCommerce()
                }

                if (
                    prefs.continuousListening &&
                    prefs.commerceStatusKnown &&
                    prefs.commerceAccessActive
                ) {
                    setContinuousListening(true)
                }
            }
            .show()
    }

    fun openCustomerSetup() {
        prefs.profileSetupComplete = false
        maybeShowCustomerSetup()
    }

    fun setCustomerDisplayName(name: String) {
        val clean = CustomerProfile.cleanName(name)
        prefs.customerDisplayName = clean
        prefs.profileSetupComplete = clean.isNotBlank()
        if (clean.isNotBlank()) {
            setCustomerIdentity(clean, prefs.customerEmail, prefs.customerPhone)
            showStatus("Your name: $clean")
        }
    }

    fun setAssistantName(name: String) {
        val old = prefs.assistantName
        prefs.assistantName = name
        if (!old.equals(prefs.assistantName, true)) showStatus("Assistant name synced: ${prefs.assistantName}")
    }
    fun setCarName(name: String) { prefs.carName=name; prefs.carNameCustomized=true; showStatus("Car name: ${prefs.carName}") }
    fun setWakeName(name: String) { prefs.wakeName=name; prefs.assistantName=name; prefs.wakeNameCustomized=true; showStatus("Wake-up name: ${prefs.wakeName}") }
    fun setPreferredMediaService(name: String) { prefs.preferredMediaService=name.lowercase(Locale.getDefault()).trim(); prefs.mediaServiceCustomized=true }

    fun setTrainingBox(text: String) {
        prefs.trainingBox = text
        showStatus("CarMind training updated")
    }

    fun setOwnerProfile(text: String) {
        prefs.ownerProfile = text
        showStatus("Owner profile updated")
    }

    fun setVoiceDirectionsEnabled(enabled: Boolean) {
        prefs.voiceDirectionsEnabled = enabled
        showStatus(if (enabled) "Voice directions enabled" else "Voice directions muted")
    }

    fun setMaintenanceBox(text: String) {
        prefs.maintenanceBox = text
        showStatus("Maintenance reminders updated")
    }

    fun setDrivingGreetingEnabled(enabled: Boolean) {
        prefs.drivingGreetingEnabled = enabled
    }

    fun setDrivingModeEnabled(enabled: Boolean) {
        prefs.drivingModeEnabled = enabled
        if (enabled) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else if (!prefs.carMode) window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        showStatus(if (enabled) "Driving mode enabled" else "Driving mode disabled")
    }

    fun setFloatingMicEnabled(enabled: Boolean) {
        val allowed = enabled && featureEnabled("floating_mic")
        prefs.floatingMicEnabled = allowed
        if (!allowed) {
            stopService(Intent(this, FloatingMicService::class.java))
            return
        }
        if (Settings.canDrawOverlays(this)) {
            ContextCompat.startForegroundService(this, Intent(this, FloatingMicService::class.java))
        } else {
            runCatching {
                startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            }
            speak("Please allow CarMind to appear over other apps, then turn on the floating microphone again.")
        }
    }

    fun setFeatureFlags(json: String) {
        prefs.featureFlagsJson = json
        showStatus("CarMind features updated")
    }

    fun setAutoParkingEnabled(enabled: Boolean) {
        prefs.autoParkingEnabled = enabled
    }

    private fun featureEnabled(name: String, defaultValue: Boolean = true): Boolean =
        FeatureGate.enabled(prefs.featureFlagsJson, name, defaultValue)

    private fun disabledMessage(name: String) {
        speak("$name is currently turned off for this account.")
    }

    fun setContinuousListening(enabled: Boolean) {
        prefs.continuousListening = enabled
        val service = Intent(this, CarMindVoiceService::class.java).putExtra("enable", enabled)
        if (enabled) {
            if (!hasPermission(Manifest.permission.RECORD_AUDIO)) { requestNeededPermissions(); return }
            ContextCompat.startForegroundService(this, service)
            showStatus("Wake listening ON: Hello ${prefs.assistantName}")
        } else {
            stopService(Intent(this, CarMindVoiceService::class.java))
            showStatus("Wake listening OFF")
        }
    }

    fun startListeningOnce() {
        if (!hasPermission(Manifest.permission.RECORD_AUDIO)) { requestNeededPermissions(); return }
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { showStatus("Speech recognition unavailable"); return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { sr ->
            sr.setRecognitionListener(object : RecognitionListener {
                override fun onReadyForSpeech(params: Bundle?) { showStatus("Listening…") }
                override fun onResults(results: Bundle?) {
                    val heard = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                    if (heard.isNotBlank()) handleOneShotSpeech(heard) else showStatus("Ready")
                }
                override fun onError(error: Int) { showStatus("Ready") }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(buffer: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(partialResults: Bundle?) {}
                override fun onEvent(eventType: Int, params: Bundle?) {}
            })
            sr.startListening(recognizerIntent())
        }
    }

    private fun recognizerIntent() = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
        putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
    }

    private fun handleContinuousSpeech(text: String, mode: String = "") {
        val low = text.lowercase(Locale.getDefault())
        val wake = prefs.wakeName.lowercase(Locale.getDefault())
        val woke = low == wake ||
            low.contains("hello $wake") ||
            low.contains("hey $wake") ||
            low.contains("hi $wake")

        if (mode == "command" || prefs.awaitingCommandUntil > System.currentTimeMillis()) {
            prefs.awaitingCommandUntil = 0L
            wakeArmed = false
            processCommandOrConversation(text)
            return
        }

        if (mode == "wake" || woke) {
            wakeArmed = true
            prefs.awaitingCommandUntil = System.currentTimeMillis() + 20_000L
            speak(CustomerProfile.wakeGreeting(prefs))
            emitToWeb(
                "carmind:wake",
                JSONObject()
                    .put("heard", text)
                    .put("assistantName", prefs.wakeName)
                    .put("customerDisplayName", prefs.customerDisplayName)
        .put("profileSetupComplete", prefs.profileSetupComplete)
        .put("homeLabel", prefs.homeLabel)
        .put("workLabel", prefs.workLabel)
        .put("carName", prefs.carName)
            )
        }
    }

    private fun handleOneShotSpeech(text: String) {
        val low = text.lowercase(Locale.getDefault())
        val wake = prefs.wakeName.lowercase(Locale.getDefault())
        val stripped = listOf("hello $wake", "hey $wake", wake).firstOrNull { low.startsWith(it) }
            ?.let { text.drop(it.length).trim().trimStart(',', ' ') }
        if (stripped != null && stripped.isBlank()) {
            speak("Hello, how can I help you?")
            return
        }
        processCommandOrConversation(stripped?.ifBlank { text } ?: text)
    }

    private fun processCommandOrConversation(text: String) {
        showStatus("You: ${text.take(70)}")
        if (!prefs.commerceStatusKnown) {
            showStatus("Checking access…")
            registerCommerce()
            return
        }
        if (!prefs.commerceAccessActive) {
            stopService(Intent(this, CarMindVoiceService::class.java))
            showStatus("Payment required")
            showPaymentRequired()
            return
        }
        val lowText = text.trim().lowercase(Locale.getDefault())
        if (
            lowText in setOf(
                "take me home",
                "navigate home",
                "go home"
            )
        ) {
            val dest = prefs.homeLabel.ifBlank {
                OwnerProfile.parse(prefs.ownerProfile)["home"].orEmpty()
            }
            if (dest.isBlank()) {
                speak("You have not saved a home location yet.")
            } else {
                prefs.journeyDestination = dest
                navigate(dest)
            }
            return
        }

        if (
            lowText in setOf(
                "take me to work",
                "take me to the office",
                "navigate to work",
                "go to work"
            )
        ) {
            val profile = OwnerProfile.parse(prefs.ownerProfile)
            val dest = prefs.workLabel.ifBlank {
                profile["work"].orEmpty().ifBlank {
                    profile["office"].orEmpty()
                }
            }
            if (dest.isBlank()) {
                speak("You have not saved a work location yet.")
            } else {
                prefs.journeyDestination = dest
                navigate(dest)
            }
            return
        }

        SmartIntentBrain.understand(text)?.let { u ->
            when(u.action) {
                "volume_max","volume_min","volume_up","volume_down","mute","unmute","flashlight_on","flashlight_off","wifi_on","wifi_off","bluetooth_on","bluetooth_off","open_app" -> { systemCommands.execute(u)?.let{ speak(it) }; return }
                "bluetooth_connect" -> { speak(bluetoothController.connectNamed(u.payload)); return }
                "bluetooth_disconnect" -> { speak(bluetoothController.disconnectNamed(u.payload)); return }
                "media_play" -> { speak(mediaRouter.play(u.payload,u.service,u.mediaType,prefs.preferredMediaService)); return }
                "navigate","navigate_nearest" -> { prefs.journeyDestination=u.payload; navigate(u.payload); return }
                "where_am_i" -> { tellCurrentLocation(); return }
                "journey_progress" -> { val d=prefs.journeyDestination; speak(if(d.isBlank()) "There is no active destination yet." else "Your active destination is $d. I will continue route guidance as location updates arrive."); return }
            }
        }

        // Built-in CarMind functions get first chance.
        if (lowText in setOf("remember where i parked", "remember where i parked the car", "save parking", "save my parking")) {
            if (featureEnabled("parking")) saveParkingLocation() else disabledMessage("Parking memory")
            return
        }

        if (lowText in setOf("where did i park", "where is my car", "take me to my car")) {
            if (featureEnabled("parking")) guideToParking() else disabledMessage("Parking memory")
            return
        }

        if (lowText in setOf("trip summary", "how far have i driven", "how long have i been driving")) {
            if (featureEnabled("trip")) speak(tripTracker.currentSummary()) else disabledMessage("Trip summary")
            return
        }

        if (lowText in setOf("end trip", "finish trip", "trip complete")) {
            if (!featureEnabled("trip")) { disabledMessage("Trip summary"); return }
            val summary = tripTracker.finishTrip() ?: "There is no active trip to finish."
            if (featureEnabled("parking")) saveParkingLocation(silent = true)
            speak(summary)
            return
        }

        if (lowText.contains("maintenance") || lowText in setOf("service reminders", "what service is due")) {
            if (featureEnabled("maintenance")) speak(MaintenanceBrain.spoken(prefs.maintenanceBox))
            else disabledMessage("Maintenance reminders")
            return
        }

        val parsed = CommandParser.parse(text)
        if (parsed != null) {
            when (parsed.action) {
                "navigate" -> if (featureEnabled("navigation")) navigate(parsed.payload) else disabledMessage("Navigation")
                "weather" -> if (featureEnabled("weather")) tellWeather() else disabledMessage("Weather")
                "where_am_i" -> if (featureEnabled("location")) tellCurrentLocation() else disabledMessage("Location")
                "music" -> if (featureEnabled("music")) searchMusic(parsed.payload) else disabledMessage("Music control")
                "video" -> if (featureEnabled("video")) searchVideo(parsed.payload) else disabledMessage("Video control")
                "call" -> if (featureEnabled("calls")) dial(parsed.payload) else disabledMessage("Calls")
                "message" -> if (featureEnabled("messages")) composeMessage(parsed.payload) else disabledMessage("Messages")
            }
            return
        }

        if (
            lowText in setOf(
                "what is my name",
                "what's my name",
                "do you know my name",
                "who am i"
            )
        ) {
            val name = prefs.customerDisplayName.trim()
            speak(
                if (name.isBlank()) "You have not told me your name yet."
                else "Your name is $name."
            )
            return
        }

        if (
            lowText in setOf(
                "change my name",
                "edit my name",
                "change my profile",
                "edit my profile"
            )
        ) {
            openCustomerSetup()
            return
        }

        // Then owner facts and one-box training.
        val profile = OwnerProfile.parse(prefs.ownerProfile)
        if (featureEnabled("owner_profile")) {
            OwnerProfile.localOwnerAnswer(text, profile)?.let {
                speak(it)
                return
            }
        }

        if (featureEnabled("training")) {
            LocalTrainingBrain.findAnswer(prefs.trainingBox, text)?.let {
                speak(it)
                return
            }
        }

        val localFallback = when {
            lowText in setOf("how are you", "how are you doing", "how are you today") ->
                "I'm fine today. How are you?"
            lowText in setOf("are you there", "can you hear me") ->
                "Yes, I'm here and listening."
            else -> null
        }

        if (localFallback != null) {
            speak(CustomerProfile.maybeUseName(prefs, localFallback))
            return
        }

        // Unknown speech can still be handed to the website. No AI is embedded.
        emitToWeb("carmind:speech", JSONObject()
            .put("text", text)
            .put("assistantName", prefs.assistantName)
        .put("carName", prefs.carName)
        .put("wakeName", prefs.wakeName)
        .put("preferredMediaService", prefs.preferredMediaService)
        .put("journeyDestination", prefs.journeyDestination)
            .put("source", "native_voice"))
        showStatus("I don't have a local answer for that yet")
    }

    fun speak(text: String) {
        if (text.isBlank()) return

        if (!ttsReady) {
            if (pendingSpeech.size >= 8) pendingSpeech.removeFirst()
            pendingSpeech.addLast(text)
            showStatus(text.take(85))
            return
        }

        restartListeningAfterSpeech = prefs.continuousListening
        if (restartListeningAfterSpeech) {
            stopService(Intent(this, CarMindVoiceService::class.java))
        }

        val utteranceId = "carmind-${System.currentTimeMillis()}"
        tts.speak(text, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
        showStatus(text.take(85))
    }

    fun executeAction(action: String, payload: JSONObject) {
        when (action.lowercase(Locale.getDefault())) {
            "speak" -> speak(payload.optString("text"))
            "listen" -> startListeningOnce()
            "navigate" -> navigate(payload.optString("destination"))
            "weather" -> tellWeather()
            "where_am_i" -> tellCurrentLocation()
            "music" -> searchMusic(payload.optString("query"))
            "video" -> searchVideo(payload.optString("query"))
            "call" -> dial(payload.optString("number", payload.optString("contact")))
            "sms", "message" -> sms(payload.optString("number", payload.optString("contact")), payload.optString("message"))
            "set_assistant_name" -> setAssistantName(payload.optString("name"))
            "continuous_listening" -> setContinuousListening(payload.optBoolean("enabled", false))
            "route_instruction" -> speak(payload.optString("text", payload.optString("instruction")))
            "set_destination" -> { prefs.activeDestination = payload.optString("destination"); showStatus("Destination synced") }
            "announce_places" -> { prefs.announcePlaces = payload.optBoolean("enabled", true); showStatus("Journey announcements updated") }
            "car_mode" -> {
                prefs.carMode = payload.optBoolean("enabled", true)
                if (prefs.carMode) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON) else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
            else -> showStatus("Unknown action: $action")
        }
    }

    private fun speakNavigation(text: String) {
        if (!prefs.voiceDirectionsEnabled || !featureEnabled("voice_directions") || text.isBlank()) return
        releaseAudioFocusAfterSpeech = true
        audioFocusDucker.duckForSpeech()
        speak(text)
    }

    private fun saveParkingLocation(silent: Boolean = false) {
        val loc = lastLocation
        if (loc == null) {
            if (!silent) speak("I do not have a GPS location yet.")
            return
        }
        prefs.parkingLat = loc.latitude
        prefs.parkingLng = loc.longitude
        prefs.parkingSavedAt = System.currentTimeMillis()
        if (!silent) speak("I remembered where you parked.")
        emitToWeb("carmind:parking", JSONObject().put("lat", loc.latitude).put("lng", loc.longitude))
    }

    private fun guideToParking() {
        val lat = prefs.parkingLat
        val lng = prefs.parkingLng
        if (lat.isNaN() || lng.isNaN()) {
            speak("I do not have a saved parking location yet.")
            return
        }
        val geo = Uri.parse("geo:$lat,$lng?q=$lat,$lng(CarMind parking)")
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, geo)) }
        speak("Opening the location where you parked.")
    }

    private fun maybeDrivingGreeting() {
        if (!prefs.drivingGreetingEnabled || !featureEnabled("driving_greeting")) return
        val cal = java.util.Calendar.getInstance()
        val day = cal.get(java.util.Calendar.DAY_OF_YEAR)
        if (prefs.lastGreetingDay == day) return
        prefs.lastGreetingDay = day

        val hour = cal.get(java.util.Calendar.HOUR_OF_DAY)
        val part = when (hour) {
            in 5..11 -> "Good morning"
            in 12..17 -> "Good afternoon"
            else -> "Good evening"
        }
        val profile = OwnerProfile.parse(prefs.ownerProfile)
        val owner = profile["name"] ?: profile["owner"] ?: ""
        val who = if (owner.isBlank()) "" else " $owner"
        speak("$part$who. ${prefs.assistantName} is ready. Where are we going?")
    }

    private fun tellWeather() {
        val loc = lastLocation
        if (loc == null) {
            if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) {
                requestNeededPermissions()
                speak("I need location permission before I can check the weather where you are.")
            } else {
                startLocation()
                speak("I'm getting your location. Ask me about the weather again in a moment.")
            }
            return
        }

        showStatus("Checking live weather…")
        Thread {
            val result = WeatherClient.fetch(loc)
            runOnUiThread {
                result.onSuccess { report ->
                    speak(report.spoken())
                    emitToWeb("carmind:weather", JSONObject()
                        .put("temperatureC", report.temperatureC)
                        .put("weatherCode", report.weatherCode)
                        .put("lat", loc.latitude)
                        .put("lng", loc.longitude))
                }.onFailure {
                    speak("I couldn't reach the weather service right now. Please try again shortly.")
                }
            }
        }.start()
    }

    private fun tellCurrentLocation() {
        val loc = lastLocation
        if (loc == null) {
            speak("I'm still getting your location.")
            startLocation()
            return
        }

        Thread {
            val phrase = runCatching {
                @Suppress("DEPRECATION")
                val address = android.location.Geocoder(this, Locale.getDefault())
                    .getFromLocation(loc.latitude, loc.longitude, 1)
                    ?.firstOrNull()

                if (address == null) {
                    "Your current position is ${"%.5f".format(Locale.US, loc.latitude)}, ${"%.5f".format(Locale.US, loc.longitude)}."
                } else {
                    val road = listOfNotNull(address.thoroughfare, address.featureName)
                        .firstOrNull { it.isNotBlank() }
                    val area = listOfNotNull(address.subLocality, address.locality, address.subAdminArea)
                        .firstOrNull { it.isNotBlank() }
                    when {
                        road != null && area != null -> "You are on $road around $area."
                        road != null -> "You are on $road."
                        area != null -> "You are around $area."
                        else -> "I have your GPS position, but I can't identify the road name right now."
                    }
                }
            }.getOrElse {
                "I have your GPS position, but I can't identify the road name right now."
            }
            runOnUiThread { speak(phrase) }
        }.start()
    }

    private fun navigate(destination: String) {
        if (destination.isBlank()) { speak("Where would you like to go?"); return }
        prefs.activeDestination = destination

        val origin = lastLocation
        if (origin != null) {
            showStatus("Planning route to $destination…")
            Thread {
                val result = RouteClient.fetch(origin, destination)
                runOnUiThread {
                    result.onSuccess { plan ->
                        routeGuidance.setPlan(plan)
                        emitToWeb("carmind:route", JSONObject()
                            .put("destination", plan.destination)
                            .put("distanceMeters", plan.distanceMeters)
                            .put("durationSeconds", plan.durationSeconds)
                            .put("steps", plan.steps.size))
                    }.onFailure {
                        // If the owner has not added the routing API key yet,
                        // navigation still works by handing off to a map app.
                        speak("I could not load my own route guidance, so I am opening your navigation app.")
                    }
                }
            }.start()
        }

        // Keep a visual map running too. Google Maps is tried first; any other
        // installed geo-capable app (including Organic Maps) can handle fallback.
        val googleNav = Uri.parse("google.navigation:q=${Uri.encode(destination)}&mode=d")
        val geo = Uri.parse("geo:0,0?q=${Uri.encode(destination)}")

        val launchedGoogle = runCatching {
            startActivity(Intent(Intent.ACTION_VIEW, googleNav).apply {
                setPackage("com.google.android.apps.maps")
            })
            true
        }.getOrDefault(false)

        if (!launchedGoogle) {
            runCatching { startActivity(Intent(Intent.ACTION_VIEW, geo)) }
        }

        if (origin == null) speak("Starting directions to $destination.")
        emitToWeb("carmind:action", JSONObject()
            .put("action", "navigate")
            .put("destination", destination)
            .put("lat", lastLocation?.latitude ?: JSONObject.NULL)
            .put("lng", lastLocation?.longitude ?: JSONObject.NULL))
    }

    private fun searchMusic(query: String) {
        if (query.isBlank()) { speak("What should I play?"); return }
        val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode("$query music")}")
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        speak("Opening music for $query")
    }

    private fun searchVideo(query: String) {
        if (query.isBlank()) { speak("Which video should I find?"); return }
        val uri = Uri.parse("https://www.youtube.com/results?search_query=${Uri.encode(query)}")
        runCatching { startActivity(Intent(Intent.ACTION_VIEW, uri)) }
        speak("Opening the video search")
    }

    private fun dial(nameOrNumber: String) {
        if (nameOrNumber.isBlank()) { speak("Who should I call?"); return }
        val profile = OwnerProfile.parse(prefs.ownerProfile)
        val target = OwnerProfile.resolveRelationship(nameOrNumber, profile)
        val phone = ContactResolver.resolvePhone(this, target)
        if (phone == null) {
            if (!hasPermission(Manifest.permission.READ_CONTACTS) && !nameOrNumber.any { it.isDigit() }) requestNeededPermissions()
            speak("I could not find that contact. You can say the phone number instead.")
            return
        }
        startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${Uri.encode(phone)}")))
        speak("Opening the dialer for $nameOrNumber")
    }

    private fun composeMessage(raw: String) {
        val split = raw.split(" saying ", " message ", limit = 2)
        val who = split.firstOrNull().orEmpty()
        val message = split.getOrNull(1).orEmpty()
        sms(who, message)
    }

    private fun sms(nameOrNumber: String, message: String) {
        if (nameOrNumber.isBlank()) { speak("Who should I message?"); return }
        val profile = OwnerProfile.parse(prefs.ownerProfile)
        val target = OwnerProfile.resolveRelationship(nameOrNumber, profile)
        val phone = ContactResolver.resolvePhone(this, target)
        if (phone == null) { speak("I could not find that contact."); return }
        val intent = Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:${Uri.encode(phone)}")).apply { putExtra("sms_body", message) }
        startActivity(intent)
        speak("Opening your message to $nameOrNumber")
    }

    private fun startLocation() {
        if (!hasPermission(Manifest.permission.ACCESS_FINE_LOCATION)) return
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        runCatching {
            lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 10_000L, 25f, object : LocationListener {
                override fun onLocationChanged(location: Location) {
                    lastLocation = location
                    announcer.onLocation(location)
                    routeGuidance.onLocation(location)
                    tripTracker.onLocation(location)
                    driveStateDetector.onLocation(location)
                    emitToWeb("carmind:location", JSONObject()
                        .put("lat", location.latitude)
                        .put("lng", location.longitude)
                        .put("speedMps", location.speed)
                        .put("bearing", location.bearing)
                        .put("accuracyM", location.accuracy))
                }
            })
        }
    }

    private fun emitToWeb(event: String, detail: JSONObject) {
        val ev = JSONObject.quote(event)
        val json = detail.toString()
        web.post { web.evaluateJavascript("window.dispatchEvent(new CustomEvent($ev,{detail:$json}));", null) }
    }

    fun nativeStateJson(): String = JSONObject()
        .put("native", true)
        .put("version", "19.2.0")
        .put("assistantName", prefs.assistantName)
        .put("carName", prefs.carName)
        .put("wakeName", prefs.wakeName)
        .put("preferredMediaService", prefs.preferredMediaService)
        .put("journeyDestination", prefs.journeyDestination)
        .put("continuousListening", prefs.continuousListening)
        .put("carMode", prefs.carMode)
        .put("announcePlaces", prefs.announcePlaces)
        .put("activeDestination", prefs.activeDestination)
        .put("voiceDirectionsEnabled", prefs.voiceDirectionsEnabled)
        .put("drivingGreetingEnabled", prefs.drivingGreetingEnabled)
        .put("drivingModeEnabled", prefs.drivingModeEnabled)
        .put("floatingMicEnabled", prefs.floatingMicEnabled)
        .put("autoParkingEnabled", prefs.autoParkingEnabled)
        .put("hasTraining", prefs.trainingBox.isNotBlank())
        .put("hasOwnerProfile", prefs.ownerProfile.isNotBlank())
        .put("hasParkingLocation", !prefs.parkingLat.isNaN() && !prefs.parkingLng.isNaN())
        .put("lastTripSummary", prefs.lastTripSummary)
        .put("commerceStatusKnown", prefs.commerceStatusKnown)
        .put("commerceAccessActive", prefs.commerceAccessActive)
        .put("trialEndsAt", prefs.trialEndsAt)
        .put("basePrice", prefs.basePrice)
        .put("currency", prefs.currency)
        .put("ownerTrainingSynced", prefs.trainingBox.isNotBlank())
        .put("lat", lastLocation?.latitude ?: JSONObject.NULL)
        .put("lng", lastLocation?.longitude ?: JSONObject.NULL)
        .toString()

    fun showStatus(s: String) { status.text = s }

    private fun hasPermission(p: String) = ContextCompat.checkSelfPermission(this, p) == PackageManager.PERMISSION_GRANTED

    private fun requestNeededPermissions() {
        val requested = mutableListOf(Manifest.permission.RECORD_AUDIO, Manifest.permission.ACCESS_FINE_LOCATION, Manifest.permission.READ_CONTACTS)
        if (Build.VERSION.SDK_INT >= 33) requested += Manifest.permission.POST_NOTIFICATIONS
        val missing = requested.filterNot { hasPermission(it) }
        if (missing.isNotEmpty()) ActivityCompat.requestPermissions(this, missing.toTypedArray(), 44)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 44) {
            startLocation()
            if (hasPermission(Manifest.permission.RECORD_AUDIO) && prefs.continuousListening) {
                setContinuousListening(true)
            } else if (!hasPermission(Manifest.permission.RECORD_AUDIO)) {
                showStatus("Microphone permission is required for hands-free listening")
            }
        }
    }

    private fun registerVoiceReceiver() {
        val filter = IntentFilter(CarMindVoiceService.ACTION_HEARD)
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(voiceBroadcast, filter, RECEIVER_NOT_EXPORTED)
        else @Suppress("DEPRECATION") registerReceiver(voiceBroadcast, filter)
    }

    override fun onInit(statusCode: Int) {
        if (statusCode == TextToSpeech.SUCCESS) {
            ttsReady = true
            tts.language = Locale.getDefault()
            tts.setSpeechRate(0.95f)
            tts.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {}
                override fun onError(utteranceId: String?) {
                    finishSpokenUtterance()
                }
                override fun onDone(utteranceId: String?) {
                    finishSpokenUtterance()
                }
            })

            val latest = if (pendingSpeech.isEmpty()) null else pendingSpeech.last()
            pendingSpeech.clear()
            latest?.let { speak(it) }
        } else {
            ttsReady = false
            showStatus("Text-to-speech is unavailable on this device")
        }
    }

    private fun finishSpokenUtterance() {
        if (releaseAudioFocusAfterSpeech) {
            releaseAudioFocusAfterSpeech = false
            audioFocusDucker.release()
        }
        restartContinuousListeningAfterSpeech()
    }

    private fun restartContinuousListeningAfterSpeech() {
        if (!restartListeningAfterSpeech) return
        restartListeningAfterSpeech = false
        runOnUiThread {
            if (prefs.continuousListening && hasPermission(Manifest.permission.RECORD_AUDIO)) {
                setContinuousListening(true)
                showStatus("${prefs.assistantName} is listening")
            }
        }
    }

    override fun onResume() {
        super.onResume()
        if (::commerce.isInitialized && prefs.customerId.isNotBlank()) {
            refreshEntitlement()
        }
    }

    override fun onDestroy() {
        runCatching { unregisterReceiver(voiceBroadcast) }
        recognizer?.destroy()
        tts.shutdown()
        web.destroy()
        super.onDestroy()
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (web.canGoBack()) web.goBack() else super.onBackPressed()
    }
}
