package online.carmindai.app

import java.text.SimpleDateFormat
import java.util.Locale

object MaintenanceBrain {
    data class Item(val label: String, val due: String)

    fun parse(raw: String): List<Item> =
        raw.lineSequence().mapNotNull { line ->
            val x = line.trim()
            if (x.isBlank() || x.startsWith("#")) return@mapNotNull null
            val sep = listOf("=>", "=", "|", ":").firstOrNull { x.contains(it) } ?: return@mapNotNull null
            val p = x.split(sep, limit = 2)
            if (p.size != 2) null else Item(p[0].trim(), p[1].trim())
        }.filter { it.label.isNotBlank() && it.due.isNotBlank() }.toList()

    fun spoken(raw: String): String {
        val items = parse(raw)
        if (items.isEmpty()) return "You have no maintenance reminders saved."
        return "Your maintenance reminders are: " + items.joinToString(". ") { "${it.label}, ${it.due}" } + "."
    }
}
