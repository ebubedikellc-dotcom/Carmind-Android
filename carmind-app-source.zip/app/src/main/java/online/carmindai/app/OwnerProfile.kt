package online.carmindai.app

import java.util.Locale

object OwnerProfile {
    fun parse(raw: String): Map<String, String> {
        val out = linkedMapOf<String, String>()
        for (line in raw.lineSequence()) {
            val x = line.trim()
            if (x.isBlank() || x.startsWith("#")) continue
            var i = x.indexOf('=')
            if (i < 0) i = x.indexOf(':')
            if (i <= 0) continue
            val key = x.substring(0, i).trim().lowercase(Locale.getDefault())
            val value = x.substring(i + 1).trim()
            if (key.isNotBlank() && value.isNotBlank()) out[key] = value
        }
        return out
    }

    fun resolveRelationship(raw: String, profile: Map<String, String>): String {
        val key = raw.trim().lowercase(Locale.getDefault())
            .removePrefix("my ")
            .removePrefix("the ")
            .trim()
        return profile[key] ?: raw.trim()
    }

    fun localOwnerAnswer(input: String, profile: Map<String, String>): String? {
        val q = input.trim().lowercase(Locale.getDefault())
        val owner = profile["name"] ?: profile["owner"] ?: profile["owner name"]
        return when {
            q in setOf("what is my name", "what's my name", "who am i") && owner != null ->
                "Your name is $owner."
            q in setOf("who owns this car", "who is the owner of this car", "whose car is this") && owner != null ->
                "This car belongs to $owner."
            q in setOf("where is home", "what is my home address") && profile["home"] != null ->
                "Home is ${profile["home"]}."
            q in setOf("where is my office", "where is work") && (profile["office"] ?: profile["work"]) != null ->
                "Your office is ${profile["office"] ?: profile["work"]}."
            else -> null
        }
    }
}
