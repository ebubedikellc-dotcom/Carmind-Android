package online.carmindai.app

import android.location.Location
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class RouteStep(
    val instruction: String,
    val latitude: Double,
    val longitude: Double,
    val distanceMeters: Double
)

data class RoutePlan(
    val destination: String,
    val distanceMeters: Double,
    val durationSeconds: Double,
    val steps: List<RouteStep>
)

object RouteClient {
    private const val ENDPOINT = "https://carmindai.online/api/integrations/route"

    fun fetch(origin: Location, destination: String): Result<RoutePlan> = runCatching {
        val q = URLEncoder.encode(destination, Charsets.UTF_8.name())
        val url = URL("$ENDPOINT?lat=${origin.latitude}&lng=${origin.longitude}&destination=$q")
        val conn = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 15_000
            readTimeout = 20_000
            requestMethod = "GET"
            setRequestProperty("Accept", "application/json")
            setRequestProperty("User-Agent", "CarMindAI/7.0")
        }

        try {
            val code = conn.responseCode
            val stream = if (code in 200..299) conn.inputStream else conn.errorStream
            val body = stream.bufferedReader().use { it.readText() }
            if (code !in 200..299) error("route_http_$code:$body")
            val root = JSONObject(body)
            if (!root.optBoolean("ok", false)) error(root.optString("error", "route_failed"))

            val arr = root.getJSONArray("steps")
            val steps = ArrayList<RouteStep>(arr.length())
            for (i in 0 until arr.length()) {
                val x = arr.getJSONObject(i)
                steps += RouteStep(
                    instruction = x.getString("instruction"),
                    latitude = x.getDouble("lat"),
                    longitude = x.getDouble("lng"),
                    distanceMeters = x.optDouble("distanceMeters", 0.0)
                )
            }

            RoutePlan(
                destination = root.optString("destination", destination),
                distanceMeters = root.getDouble("distanceMeters"),
                durationSeconds = root.getDouble("durationSeconds"),
                steps = steps
            )
        } finally {
            conn.disconnect()
        }
    }
}
