package online.carmindai.app

import android.location.Location

class DriveStateDetector(private val onParked: (Location) -> Unit) {
    private var sawDriving = false
    private var stoppedSince = 0L
    private var firedForStop = false

    fun onLocation(location: Location) {
        val speed = if (location.hasSpeed()) location.speed else 0f

        if (speed >= 2.5f) {
            sawDriving = true
            stoppedSince = 0L
            firedForStop = false
            return
        }

        if (!sawDriving || speed > 0.8f) return

        val now = System.currentTimeMillis()
        if (stoppedSince == 0L) stoppedSince = now

        if (!firedForStop && now - stoppedSince >= 3 * 60 * 1000L) {
            firedForStop = true
            sawDriving = false
            onParked(Location(location))
        }
    }
}
