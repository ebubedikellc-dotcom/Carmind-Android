package online.carmindai.app

import org.json.JSONObject

object FeatureGate {
    fun enabled(json: String, key: String, defaultValue: Boolean = true): Boolean {
        return runCatching {
            val root = JSONObject(json.ifBlank { "{}" })
            if (!root.has(key)) defaultValue else root.optBoolean(key, defaultValue)
        }.getOrDefault(defaultValue)
    }
}
