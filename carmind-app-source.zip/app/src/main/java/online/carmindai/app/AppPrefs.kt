package online.carmindai.app

import android.content.Context

class AppPrefs(context: Context) {
    private val p = context.getSharedPreferences("carmind", Context.MODE_PRIVATE)

    var assistantName: String
        get() = p.getString("assistant_name", "Mercedes") ?: "Mercedes"
        set(value) { if (value.trim().isNotEmpty()) p.edit().putString("assistant_name", value.trim().take(48)).apply() }

    var continuousListening: Boolean
        get() = p.getBoolean("continuous_listening", true)
        set(value) = p.edit().putBoolean("continuous_listening", value).apply()

    var announcePlaces: Boolean
        get() = p.getBoolean("announce_places", true)
        set(value) = p.edit().putBoolean("announce_places", value).apply()

    var carMode: Boolean
        get() = p.getBoolean("car_mode", true)
        set(value) = p.edit().putBoolean("car_mode", value).apply()

    var activeDestination: String
        get() = p.getString("active_destination", "") ?: ""
        set(value) = p.edit().putString("active_destination", value.trim().take(180)).apply()
}
