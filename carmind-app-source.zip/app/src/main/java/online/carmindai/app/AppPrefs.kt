package online.carmindai.app

import android.content.Context

class AppPrefs(context: Context) {
    private val p = context.getSharedPreferences("carmind", Context.MODE_PRIVATE)

    var assistantName: String
        get() = p.getString("assistant_name", "Mercedes") ?: "Mercedes"
        set(value) { if (value.trim().isNotEmpty()) p.edit().putString("assistant_name", value.trim().take(48)).apply() }

    var continuousListening: Boolean
        get() = p.getBoolean("continuous_listening", true)
        set(value) = p.edit().putBoolean("continuous_listening", value).apply()

    var announcePlaces: Boolean
        get() = p.getBoolean("announce_places", true)
        set(value) = p.edit().putBoolean("announce_places", value).apply()

    var carMode: Boolean
        get() = p.getBoolean("car_mode", true)
        set(value) = p.edit().putBoolean("car_mode", value).apply()

    var activeDestination: String
        get() = p.getString("active_destination", "") ?: ""
        set(value) = p.edit().putString("active_destination", value.trim().take(180)).apply()

    var trainingBox: String
        get() = p.getString("training_box", "") ?: ""
        set(value) = p.edit().putString("training_box", value.take(100_000)).apply()

    var ownerProfile: String
        get() = p.getString("owner_profile", "") ?: ""
        set(value) = p.edit().putString("owner_profile", value.take(50_000)).apply()

    var voiceDirectionsEnabled: Boolean
        get() = p.getBoolean("voice_directions_enabled", true)
        set(value) = p.edit().putBoolean("voice_directions_enabled", value).apply()

    var parkingLat: Double
        get() = java.lang.Double.longBitsToDouble(p.getLong("parking_lat_bits", java.lang.Double.doubleToRawLongBits(Double.NaN)))
        set(value) = p.edit().putLong("parking_lat_bits", java.lang.Double.doubleToRawLongBits(value)).apply()

    var parkingLng: Double
        get() = java.lang.Double.longBitsToDouble(p.getLong("parking_lng_bits", java.lang.Double.doubleToRawLongBits(Double.NaN)))
        set(value) = p.edit().putLong("parking_lng_bits", java.lang.Double.doubleToRawLongBits(value)).apply()

    var parkingSavedAt: Long
        get() = p.getLong("parking_saved_at", 0L)
        set(value) = p.edit().putLong("parking_saved_at", value).apply()

    var tripStartedAt: Long
        get() = p.getLong("trip_started_at", 0L)
        set(value) = p.edit().putLong("trip_started_at", value).apply()

    var tripDistanceMeters: Float
        get() = p.getFloat("trip_distance_meters", 0f)
        set(value) = p.edit().putFloat("trip_distance_meters", value).apply()

    var lastTripSummary: String
        get() = p.getString("last_trip_summary", "") ?: ""
        set(value) = p.edit().putString("last_trip_summary", value.take(1000)).apply()

    var maintenanceBox: String
        get() = p.getString("maintenance_box", "") ?: ""
        set(value) = p.edit().putString("maintenance_box", value.take(50_000)).apply()

    var drivingGreetingEnabled: Boolean
        get() = p.getBoolean("driving_greeting_enabled", true)
        set(value) = p.edit().putBoolean("driving_greeting_enabled", value).apply()

    var drivingModeEnabled: Boolean
        get() = p.getBoolean("driving_mode_enabled", true)
        set(value) = p.edit().putBoolean("driving_mode_enabled", value).apply()

    var floatingMicEnabled: Boolean
        get() = p.getBoolean("floating_mic_enabled", false)
        set(value) = p.edit().putBoolean("floating_mic_enabled", value).apply()

    var lastGreetingDay: Int
        get() = p.getInt("last_greeting_day", -1)
        set(value) = p.edit().putInt("last_greeting_day", value).apply()

    var featureFlagsJson: String
        get() = p.getString("feature_flags_json", "{}") ?: "{}"
        set(value) = p.edit().putString("feature_flags_json", value.take(100_000)).apply()

    var autoParkingEnabled: Boolean
        get() = p.getBoolean("auto_parking_enabled", true)
        set(value) = p.edit().putBoolean("auto_parking_enabled", value).apply()

    var installId: String
        get() {
            val existing = p.getString("install_id", "") ?: ""
            if (existing.isNotBlank()) return existing
            val created = java.util.UUID.randomUUID().toString()
            p.edit().putString("install_id", created).apply()
            return created
        }
        set(value) = p.edit().putString("install_id", value.take(120)).apply()

    var customerId: String
        get() = p.getString("customer_id", "") ?: ""
        set(value) = p.edit().putString("customer_id", value.take(160)).apply()

    var customerEmail: String
        get() = p.getString("customer_email", "") ?: ""
        set(value) = p.edit().putString("customer_email", value.take(200)).apply()

    var customerPhone: String
        get() = p.getString("customer_phone", "") ?: ""
        set(value) = p.edit().putString("customer_phone", value.take(80)).apply()

    var customerName: String
        get() = p.getString("customer_name", "") ?: ""
        set(value) = p.edit().putString("customer_name", value.take(120)).apply()

    var commerceStatusKnown: Boolean
        get() = p.getBoolean("commerce_status_known", false)
        set(value) = p.edit().putBoolean("commerce_status_known", value).apply()

    var commerceAccessActive: Boolean
        get() = p.getBoolean("commerce_access_active", false)
        set(value) = p.edit().putBoolean("commerce_access_active", value).apply()

    var trialEndsAt: Long
        get() = p.getLong("trial_ends_at", 0L)
        set(value) = p.edit().putLong("trial_ends_at", value).apply()

    var paymentMessage: String
        get() = p.getString("payment_message", "Your free trial has ended. Please pay to continue using CarMind.") ?: "Your free trial has ended. Please pay to continue using CarMind."
        set(value) = p.edit().putString("payment_message", value.take(500)).apply()

    var basePrice: Double
        get() = java.lang.Double.longBitsToDouble(p.getLong("base_price_bits", java.lang.Double.doubleToRawLongBits(59500.0)))
        set(value) = p.edit().putLong("base_price_bits", java.lang.Double.doubleToRawLongBits(value)).apply()

    var currency: String
        get() = p.getString("currency", "NGN") ?: "NGN"
        set(value) = p.edit().putString("currency", value.take(8)).apply()

    var carName: String
        get() = p.getString("car_name", "My Car") ?: "My Car"
        set(value) = p.edit().putString("car_name", value.trim().take(80).ifBlank { "My Car" }).apply()

    var wakeName: String
        get() = p.getString("wake_name", assistantName) ?: assistantName
        set(value) = p.edit().putString("wake_name", value.trim().take(40).ifBlank { assistantName }).apply()

    var preferredMediaService: String
        get() = p.getString("preferred_media_service", "") ?: ""
        set(value) = p.edit().putString("preferred_media_service", value.trim().take(40)).apply()

    var journeyDestination: String
        get() = p.getString("journey_destination", "") ?: ""
        set(value) = p.edit().putString("journey_destination", value.trim().take(250)).apply()

    var carNameCustomized: Boolean
        get() = p.getBoolean("car_name_customized", false)
        set(value) = p.edit().putBoolean("car_name_customized", value).apply()

    var wakeNameCustomized: Boolean
        get() = p.getBoolean("wake_name_customized", false)
        set(value) = p.edit().putBoolean("wake_name_customized", value).apply()

    var mediaServiceCustomized: Boolean
        get() = p.getBoolean("media_service_customized", false)
        set(value) = p.edit().putBoolean("media_service_customized", value).apply()

    var awaitingCommandUntil: Long
        get() = p.getLong("awaiting_command_until", 0L)
        set(value) = p.edit().putLong("awaiting_command_until", value).apply()

    var customerDisplayName: String
        get() = p.getString("customer_display_name", customerName) ?: customerName
        set(value) {
            val clean = value.trim().take(80)
            p.edit().putString("customer_display_name", clean)
                .putString("customer_name", clean).apply()
        }

    var profileSetupComplete: Boolean
        get() = p.getBoolean("profile_setup_complete", false)
        set(value) = p.edit().putBoolean("profile_setup_complete", value).apply()

    var personalizationCounter: Int
        get() = p.getInt("personalization_counter", 0)
        set(value) = p.edit().putInt("personalization_counter", value).apply()

    var homeLabel: String
        get() = p.getString("home_label", "") ?: ""
        set(value) = p.edit().putString("home_label", value.trim().take(180)).apply()

    var workLabel: String
        get() = p.getString("work_label", "") ?: ""
        set(value) = p.edit().putString("work_label", value.trim().take(180)).apply()

    var externalRecordingPauseUntil: Long
        get() = p.getLong("external_recording_pause_until", 0L)
        set(value) = p.edit().putLong("external_recording_pause_until", value).apply()

    var pendingMediaQuery: String
        get() = p.getString("pending_media_query", "") ?: ""
        set(value) = p.edit().putString("pending_media_query", value.take(250)).apply()

    var pendingMediaType: String
        get() = p.getString("pending_media_type", "") ?: ""
        set(value) = p.edit().putString("pending_media_type", value.take(30)).apply()

    // Owner-selected engines. Only one engine is active for each job.
    var voiceEngine: String
        get() = p.getString("voice_engine", "vosk") ?: "vosk"
        set(value) = p.edit().putString("voice_engine", value.lowercase().trim().take(24).ifBlank { "vosk" }).apply()

    var androidControlEngine: String
        get() = p.getString("android_control_engine", "shizuku") ?: "shizuku"
        set(value) = p.edit().putString("android_control_engine", value.lowercase().trim().take(24).ifBlank { "shizuku" }).apply()

    var navigationEngine: String
        get() = p.getString("navigation_engine", "carmind") ?: "carmind"
        set(value) = p.edit().putString("navigation_engine", value.lowercase().trim().take(24).ifBlank { "carmind" }).apply()

}
