package online.carmindai.app

import android.app.Activity
import android.app.SearchManager
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import java.net.URLEncoder
import java.util.Locale

class MediaRouter(private val activity: Activity) {
    fun normalizeService(raw: String): String {
        val v = raw.trim().lowercase(Locale.getDefault())
        return when (v) {
            "spotify" -> "spotify"
            "youtube music", "youtube_music", "yt music", "ytmusic" -> "youtube_music"
            "youtube", "yt", "youtube video", "youtube videos" -> "youtube"
            else -> raw.trim()
        }
    }

    fun play(query: String, serviceRaw: String, typeRaw: String, preferred: String = ""): String {
        val q = query.trim()
        if (q.isBlank()) return "What would you like me to play?"

        var service = normalizeService(serviceRaw.ifBlank { preferred })
        if (service.isBlank()) service = bestInstalledService()
        if (service.isBlank()) {
            return "I could not find a compatible music app in your car. Install or choose a supported music app first."
        }

        return when (service) {
            "spotify" -> playSpotify(q)
            "youtube_music" -> playYouTubeMusic(q)
            "youtube" -> playYouTube(q)
            else -> playInstalledMediaApp(q, service)
        }
    }

    private fun bestInstalledService(): String {
        val pm = activity.packageManager
        fun installed(pkg: String) = runCatching { pm.getPackageInfo(pkg, 0); true }.getOrDefault(false)
        return when {
            installed("com.google.android.apps.youtube.music") -> "youtube_music"
            installed("com.spotify.music") -> "spotify"
            installed("com.google.android.youtube") -> "youtube"
            else -> {
                val probe = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
                pm.queryIntentActivities(probe, 0).firstOrNull()?.loadLabel(pm)?.toString().orEmpty()
            }
        }
    }

    private fun playSpotify(query: String): String =
        playFromSearch(query, "com.spotify.music", "Spotify")
            ?: openSearch(query, "spotify:search:", "https://open.spotify.com/search/", "Spotify")

    private fun playYouTubeMusic(query: String): String =
        playFromSearch(query, "com.google.android.apps.youtube.music", "YouTube Music")
            ?: run {
                val encoded = URLEncoder.encode(query, "UTF-8")
                activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://music.youtube.com/search?q=$encoded")))
                "Opening $query in YouTube Music."
            }

    private fun playYouTube(query: String): String {
        val encoded = URLEncoder.encode(query, "UTF-8")
        activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encoded")))
        return "Opening $query on YouTube."
    }

    private fun playInstalledMediaApp(query: String, appName: String): String {
        val pm = activity.packageManager
        val probe = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH)
        val wanted = appName.trim().lowercase(Locale.getDefault())
        val handlers = pm.queryIntentActivities(probe, 0)
        val match = handlers.firstOrNull {
            it.loadLabel(pm).toString().trim().lowercase(Locale.getDefault()) == wanted
        } ?: handlers.firstOrNull {
            it.loadLabel(pm).toString().trim().lowercase(Locale.getDefault()).contains(wanted)
        }
        if (match != null) {
            val label = match.loadLabel(pm).toString()
            playFromSearch(query, match.activityInfo.packageName, label)?.let { return it }
        }
        return "I could not find a music app called $appName in your car that accepts voice playback. Choose another supported music app."
    }

    private fun playFromSearch(query: String, packageName: String, label: String): String? {
        val intent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage(packageName)
            putExtra(SearchManager.QUERY, query)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }
        if (intent.resolveActivity(activity.packageManager) == null) return null
        return runCatching {
            activity.startActivity(intent)
            "Playing $query on $label."
        }.getOrNull()
    }

    private fun openSearch(query: String, appSchemePrefix: String, webPrefix: String, label: String): String {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val deep = Intent(Intent.ACTION_VIEW, Uri.parse(appSchemePrefix + encoded))
        if (deep.resolveActivity(activity.packageManager) != null) {
            activity.startActivity(deep)
            return "I opened $query in $label. This version of $label may require choosing a result."
        }
        activity.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(webPrefix + encoded)))
        return "Opening $query in $label."
    }
}
