package online.carmindai.app
import android.app.Activity
import android.content.Intent
import android.net.Uri
import java.net.URLEncoder
class MediaRouter(private val activity:Activity){
 fun play(query:String,serviceRaw:String,typeRaw:String,preferred:String=""):String{
  val q=query.trim(); if(q.isBlank()) return "What would you like me to play?"
  var s=serviceRaw.ifBlank{preferred}; var t=typeRaw
  if(s.isBlank()&&t.isBlank()) return "Do you want audio or video, and should I use Spotify, YouTube Music, or YouTube?"
  if(s.isBlank()) s=if(t=="video")"youtube" else "spotify"; if(t.isBlank()) t=if(s=="youtube")"video" else "audio"
  val e=URLEncoder.encode(q,"UTF-8"); val intents=when(s){"spotify"->listOf(Intent(Intent.ACTION_VIEW,Uri.parse("spotify:search:$e")),Intent(Intent.ACTION_VIEW,Uri.parse("https://open.spotify.com/search/$e")));"youtube_music"->listOf(Intent(Intent.ACTION_VIEW,Uri.parse("https://music.youtube.com/search?q=$e")));else->listOf(Intent(Intent.ACTION_VIEW,Uri.parse("https://www.youtube.com/results?search_query=$e")))}
  val i=intents.firstOrNull{it.resolveActivity(activity.packageManager)!=null}?:intents.last(); activity.startActivity(i)
  return when(s){"spotify"->"Playing $q on Spotify.";"youtube_music"->"Playing $q on YouTube Music.";else->"Opening $q on YouTube."}
 }
}
