package online.carmindai.app

import android.app.Activity
import android.app.SearchManager
import android.content.Intent
import android.net.Uri
import android.provider.MediaStore
import java.net.URLEncoder

class MediaRouter(private val activity: Activity) {

    fun play(
        query: String,
        serviceRaw: String,
        typeRaw: String,
        preferred: String = ""
    ): String {
        val q = query.trim()
        if (q.isBlank()) return "What would you like me to play?"

        var service = serviceRaw.ifBlank { preferred }
        var mediaType = typeRaw

        if (service.isBlank() && mediaType.isBlank()) {
            return "Do you want audio or video, and should I use Spotify, YouTube Music, or YouTube?"
        }

        if (service.isBlank()) {
            service = if (mediaType == "video") "youtube" else "spotify"
        }

        if (mediaType.isBlank()) {
            mediaType = if (service == "youtube") "video" else "audio"
        }

        return when (service) {
            "spotify" -> playSpotify(q)
            "youtube_music" -> playYouTubeMusic(q)
            else -> playYouTube(q)
        }
    }

    private fun playSpotify(query: String): String {
        val pkg = "com.spotify.music"

        // Preferred path: Android's standard "play from search" media intent.
        // Spotify can use this to start playback instead of only opening a search screen.
        val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage(pkg)
            putExtra(SearchManager.QUERY, query)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (playIntent.resolveActivity(activity.packageManager) != null) {
            runCatching { activity.startActivity(playIntent) }
                .onSuccess { return "Playing $query on Spotify." }
        }

        // Fallback: open Spotify search if this Spotify build doesn't implement media-play-from-search.
        val encoded = URLEncoder.encode(query, "UTF-8")
        val deepLink = Intent(Intent.ACTION_VIEW, Uri.parse("spotify:search:$encoded")).apply {
            setPackage(pkg)
        }

        if (deepLink.resolveActivity(activity.packageManager) != null) {
            activity.startActivity(deepLink)
            return "I opened $query in Spotify. This Spotify version may require you to choose a result."
        }

        val web = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://open.spotify.com/search/$encoded")
        )
        activity.startActivity(web)
        return "Opening $query in Spotify."
    }

    private fun playYouTubeMusic(query: String): String {
        val pkg = "com.google.android.apps.youtube.music"

        val playIntent = Intent(MediaStore.INTENT_ACTION_MEDIA_PLAY_FROM_SEARCH).apply {
            setPackage(pkg)
            putExtra(SearchManager.QUERY, query)
            putExtra(MediaStore.EXTRA_MEDIA_FOCUS, "vnd.android.cursor.item/*")
            addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        }

        if (playIntent.resolveActivity(activity.packageManager) != null) {
            runCatching { activity.startActivity(playIntent) }
                .onSuccess { return "Playing $query on YouTube Music." }
        }

        val encoded = URLEncoder.encode(query, "UTF-8")
        val fallback = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://music.youtube.com/search?q=$encoded")
        )
        activity.startActivity(fallback)
        return "Opening $query in YouTube Music."
    }

    private fun playYouTube(query: String): String {
        val encoded = URLEncoder.encode(query, "UTF-8")
        val intent = Intent(
            Intent.ACTION_VIEW,
            Uri.parse("https://www.youtube.com/results?search_query=$encoded")
        )
        activity.startActivity(intent)
        return "Opening $query on YouTube."
    }
}
