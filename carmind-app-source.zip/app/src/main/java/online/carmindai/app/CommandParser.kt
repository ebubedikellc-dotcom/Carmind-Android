package online.carmindai.app

data class ParsedCommand(val action: String, val payload: String = "")

object CommandParser {
    fun parse(input: String): ParsedCommand? {
        val text = input.trim()
        val low = text.lowercase()
        val rules = listOf(
            "navigate to " to "navigate",
            "take me to " to "navigate",
            "drive to " to "navigate",
            "play video " to "video",
            "show me video " to "video",
            "play me video " to "video",
            "play music " to "music",
            "play song " to "music",
            "play " to "music",
            "call " to "call",
            "text " to "message",
            "message " to "message"
        )
        for ((prefix, action) in rules) {
            if (low.startsWith(prefix)) {
                return ParsedCommand(action, text.substring(prefix.length).trim())
            }
        }
        return null
    }
}
