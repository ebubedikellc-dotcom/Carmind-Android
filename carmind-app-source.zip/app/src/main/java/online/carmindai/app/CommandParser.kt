package online.carmindai.app

data class ParsedCommand(val action: String, val payload: String = "")

object CommandParser {
    fun parse(input: String): ParsedCommand? {
        val text = input.trim()
        val low = text.lowercase()
        val rules = listOf(
            "what is the weather" to "weather",
            "what's the weather" to "weather",
            "how is the weather" to "weather",
            "weather today" to "weather",
            "weather now" to "weather",
            "will it rain" to "weather",
            "is it going to rain" to "weather",
            "where am i" to "where_am_i",
            "where are we" to "where_am_i",
            "what road am i on" to "where_am_i",
            "what road are we on" to "where_am_i",
            "navigate to " to "navigate",
            "take me to " to "navigate",
            "drive to " to "navigate",
            "play video " to "video",
            "show me video " to "video",
            "play me video " to "video",
            "play music " to "music",
            "play song " to "music",
            "play " to "music",
            "call " to "call",
            "text " to "message",
            "message " to "message"
        )
        for ((prefix, action) in rules) {
            if (low.startsWith(prefix)) {
                return ParsedCommand(action, text.substring(prefix.length).trim())
            }
        }
        return null
    }
}
