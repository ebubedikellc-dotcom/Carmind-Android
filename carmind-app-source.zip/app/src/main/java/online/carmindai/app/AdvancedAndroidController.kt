package online.carmindai.app

import android.app.Activity
import android.content.ComponentName
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.os.IBinder
import rikka.shizuku.Shizuku

/**
 * Optional advanced-control bridge.
 * Preferred path: Shizuku UserService (shell/root process).
 * Compatibility path: Shizuku newProcess for older/slow-start situations.
 * Only fixed allow-listed actions are ever executed.
 */
class AdvancedAndroidController(private val activity: Activity) {
    companion object {
        private const val REQUEST_CODE = 4412

        fun requestPermissionIfAvailable(activity: Activity) {
            runCatching {
                if (!Shizuku.pingBinder()) return
                if (Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED &&
                    !Shizuku.shouldShowRequestPermissionRationale()) {
                    Shizuku.requestPermission(REQUEST_CODE)
                }
            }
        }
    }

    @Volatile private var remote: IPrivilegedShell? = null
    @Volatile private var binding = false

    private val connection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            remote = IPrivilegedShell.Stub.asInterface(service)
            binding = false
        }
        override fun onServiceDisconnected(name: ComponentName?) {
            remote = null
            binding = false
        }
    }

    private val userServiceArgs by lazy {
        Shizuku.UserServiceArgs(ComponentName(activity.packageName, PrivilegedShellService::class.java.name))
            .daemon(false)
            .processNameSuffix("carmind_privileged")
            .debuggable(false)
            .version(120)
    }

    fun available(): Boolean = runCatching {
        Shizuku.pingBinder() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    }.getOrDefault(false)

    private fun ensureBound() {
        if (!available() || remote != null || binding) return
        binding = true
        runCatching { Shizuku.bindUserService(userServiceArgs, connection) }
            .onFailure { binding = false }
    }

    fun wifi(on: Boolean) = action(if (on) "wifi_on" else "wifi_off")
    fun bluetooth(on: Boolean) = action(if (on) "bluetooth_on" else "bluetooth_off")
    fun mobileData(on: Boolean) = action(if (on) "data_on" else "data_off")
    fun mediaPlayPause() = action("media_play_pause")
    fun mediaNext() = action("media_next")
    fun mediaPrevious() = action("media_previous")
    fun screenOff() = action("screen_off")

    private fun action(key: String): Boolean {
        if (!available()) return false
        ensureBound()
        val service = remote
        if (service != null) {
            val ok = runCatching { service.runAction(key) == 0 }.getOrDefault(false)
            if (ok) return true
        }
        return compatibilityProcess(key)
    }

    /** Compatibility fallback while UserService is still connecting. */
    @Suppress("DEPRECATION")
    private fun compatibilityProcess(key: String): Boolean {
        val command = when (key) {
            "wifi_on" -> "svc wifi enable"
            "wifi_off" -> "svc wifi disable"
            "bluetooth_on" -> "svc bluetooth enable"
            "bluetooth_off" -> "svc bluetooth disable"
            "data_on" -> "svc data enable"
            "data_off" -> "svc data disable"
            "media_play_pause" -> "input keyevent 85"
            "media_next" -> "input keyevent 87"
            "media_previous" -> "input keyevent 88"
            "screen_off" -> "input keyevent 26"
            else -> return false
        }
        return runCatching {
            val p = Shizuku.newProcess(arrayOf("sh", "-c", command), null, null)
            p.waitFor() == 0
        }.getOrDefault(false)
    }
}
