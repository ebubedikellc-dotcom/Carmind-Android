package online.carmindai.app

import android.location.Location
import kotlin.math.max

class RouteGuidanceManager(private val speak: (String) -> Unit) {
    private var plan: RoutePlan? = null
    private var stepIndex = 0
    private var lastProgressAnnouncementAt = 0L

    fun setPlan(value: RoutePlan) {
        plan = value
        stepIndex = 0
        lastProgressAnnouncementAt = 0L

        val km = value.distanceMeters / 1000.0
        val mins = value.durationSeconds / 60.0
        speak("Route ready to ${value.destination}. It is about ${formatKm(km)} kilometers and ${mins.toInt().coerceAtLeast(1)} minutes.")
    }

    fun clear() {
        plan = null
        stepIndex = 0
    }

    fun hasRoute(): Boolean = plan != null

    fun onLocation(location: Location) {
        val p = plan ?: return
        if (stepIndex >= p.steps.size) {
            speak("You have arrived at ${p.destination}.")
            clear()
            return
        }

        // Speak a maneuver when the vehicle is close to the point returned by
        // the routing service. Accuracy is considered so noisy GPS does not
        // require an unrealistically small radius.
        val step = p.steps[stepIndex]
        val target = Location("route-step").apply {
            latitude = step.latitude
            longitude = step.longitude
        }
        val distance = location.distanceTo(target)
        val trigger = max(70f, location.accuracy * 2.0f)

        if (distance <= trigger) {
            speak(step.instruction)
            stepIndex++
            return
        }

        // Occasional remaining-distance update without talking constantly.
        val now = System.currentTimeMillis()
        if (now - lastProgressAnnouncementAt > 15 * 60 * 1000L && stepIndex > 0) {
            val remaining = p.steps.drop(stepIndex).sumOf { it.distanceMeters }
            if (remaining > 1000) {
                speak("About ${formatKm(remaining / 1000.0)} kilometers remain to ${p.destination}.")
                lastProgressAnnouncementAt = now
            }
        }
    }

    private fun formatKm(v: Double): String =
        if (v >= 10) v.toInt().toString() else String.format(java.util.Locale.US, "%.1f", v)
}
