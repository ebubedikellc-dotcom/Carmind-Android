package online.carmindai.app

import android.content.Context
import androidx.annotation.Keep

/** Runs only a fixed allow-list inside Shizuku's shell/root UserService process. */
class PrivilegedShellService : IPrivilegedShell.Stub {
    constructor()

    @Keep
    constructor(context: Context)

    override fun runAction(action: String?): Int {
        val command = when (action) {
            "wifi_on" -> "svc wifi enable"
            "wifi_off" -> "svc wifi disable"
            "bluetooth_on" -> "svc bluetooth enable"
            "bluetooth_off" -> "svc bluetooth disable"
            "data_on" -> "svc data enable"
            "data_off" -> "svc data disable"
            "media_play_pause" -> "input keyevent 85"
            "media_next" -> "input keyevent 87"
            "media_previous" -> "input keyevent 88"
            "screen_off" -> "input keyevent 26"
            else -> return 64
        }
        return try {
            ProcessBuilder("sh", "-c", command).redirectErrorStream(true).start().waitFor()
        } catch (_: Throwable) {
            70
        }
    }

    override fun destroy() {
        kotlin.system.exitProcess(0)
    }
}
