package online.carmindai.app

import android.app.Activity
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.provider.MediaStore
import android.provider.Settings
import java.util.Locale

class SystemCommandController(private val activity: Activity) {
    private val audio = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager

    fun handle(raw: String): String? {
        val q = raw.trim().lowercase(Locale.getDefault())
        when {
            q in setOf("increase volume to the highest","volume highest","maximum volume","max volume","increase volume to maximum") -> {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC,audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),AudioManager.FLAG_SHOW_UI)
                return "Volume is now at the highest level."
            }
            q in setOf("decrease volume to the lowest","volume lowest","minimum volume","min volume","decrease volume to minimum") -> {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC,0,AudioManager.FLAG_SHOW_UI)
                return "Volume is now at the lowest level."
            }
            q.startsWith("increase volume") || q=="volume up" -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI)
                return "Volume increased."
            }
            q.startsWith("decrease volume") || q=="volume down" -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI)
                return "Volume decreased."
            }
            q in setOf("mute","mute volume") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_MUTE,AudioManager.FLAG_SHOW_UI); return "Muted."
            }
            q in setOf("unmute","unmute volume") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_UNMUTE,AudioManager.FLAG_SHOW_UI); return "Unmuted."
            }
            q.contains("open settings") -> { activity.startActivity(Intent(Settings.ACTION_SETTINGS)); return "Opening settings." }
            q.contains("open wifi") || q.contains("wi-fi settings") -> { activity.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)); return "Opening Wi-Fi settings." }
            q.contains("open bluetooth") || q.contains("bluetooth settings") -> { activity.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Opening Bluetooth settings." }
            q in setOf("open camera","camera") -> { activity.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return "Opening camera." }
        }
        if (q.startsWith("open ")) {
            val wanted = q.removePrefix("open ").trim()
            val pm = activity.packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val launchables = pm.queryIntentActivities(launcherIntent, 0)
            val exact = launchables.firstOrNull {
                it.loadLabel(pm).toString().lowercase(Locale.getDefault()) == wanted
            }
            val match = exact ?: launchables.firstOrNull {
                it.loadLabel(pm).toString().lowercase(Locale.getDefault()).contains(wanted)
            }
            if (match != null) {
                val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
                if (launch != null) {
                    activity.startActivity(launch)
                    return "Opening ${match.loadLabel(pm)}."
                }
            }
        }
        return null
    }
}
