package online.carmindai.app

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Context
import android.content.Intent
import android.media.AudioManager
import android.hardware.camera2.CameraManager
import android.provider.MediaStore
import android.provider.Settings
import java.util.Locale

class SystemCommandController(private val activity: Activity) {
    private val audio = activity.getSystemService(Context.AUDIO_SERVICE) as AudioManager
    private val advanced = AdvancedAndroidController(activity)
    private val prefs = AppPrefs(activity)
    private fun useAdvanced(): Boolean = prefs.androidControlEngine.lowercase() == "shizuku"

    fun execute(intent: SmartIntentBrain.IntentResult): String? = when(intent.action) {
        "volume_max" -> { audio.setStreamVolume(AudioManager.STREAM_MUSIC,audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),AudioManager.FLAG_SHOW_UI); "Volume is now at the highest level." }
        "volume_min" -> { audio.setStreamVolume(AudioManager.STREAM_MUSIC,0,AudioManager.FLAG_SHOW_UI); "Volume is now at the lowest level." }
        "volume_up" -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI); "Volume increased." }
        "volume_down" -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI); "Volume decreased." }
        "mute" -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_MUTE,AudioManager.FLAG_SHOW_UI); "Muted." }
        "unmute" -> { audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_UNMUTE,AudioManager.FLAG_SHOW_UI); "Unmuted." }
        "flashlight_on" -> flashlight(true)
        "flashlight_off" -> flashlight(false)
        "wifi_on" -> if (useAdvanced() && advanced.wifi(true)) "Wi-Fi switched on." else { internetPanel(); "Opening Wi-Fi controls. Android may require one tap to switch Wi-Fi on." }
        "wifi_off" -> if (useAdvanced() && advanced.wifi(false)) "Wi-Fi switched off." else { internetPanel(); "Opening Wi-Fi controls. Android may require one tap to switch Wi-Fi off." }
        "bluetooth_on" -> if (useAdvanced() && advanced.bluetooth(true)) "Bluetooth switched on." else bluetoothPower(true)
        "bluetooth_off" -> if (useAdvanced() && advanced.bluetooth(false)) "Bluetooth switched off." else bluetoothPower(false)
        "mobile_data_on" -> if (useAdvanced() && advanced.mobileData(true)) "Mobile data switched on." else "Android needs Advanced Control permission to switch mobile data directly."
        "mobile_data_off" -> if (useAdvanced() && advanced.mobileData(false)) "Mobile data switched off." else "Android needs Advanced Control permission to switch mobile data directly."
        "media_play_pause" -> if (useAdvanced() && advanced.mediaPlayPause()) "Media play or pause command sent." else null
        "media_next" -> if (useAdvanced() && advanced.mediaNext()) "Skipping to the next track." else null
        "media_previous" -> if (useAdvanced() && advanced.mediaPrevious()) "Going back to the previous track." else null
        "open_app" -> openApp(intent.payload)
        else -> null
    }
    private fun flashlight(on:Boolean):String = runCatching {
        val cm=activity.getSystemService(Context.CAMERA_SERVICE) as CameraManager
        val id=cm.cameraIdList.firstOrNull{cid->cm.getCameraCharacteristics(cid).get(android.hardware.camera2.CameraCharacteristics.FLASH_INFO_AVAILABLE)==true} ?: return "This device has no controllable flashlight."
        cm.setTorchMode(id,on); if(on) "Flashlight turned on." else "Flashlight turned off."
    }.getOrElse{"I could not control the flashlight on this device."}
    private fun internetPanel(){ val a=if(android.os.Build.VERSION.SDK_INT>=29) Settings.Panel.ACTION_INTERNET_CONNECTIVITY else Settings.ACTION_WIFI_SETTINGS; activity.startActivity(Intent(a)) }
    private fun bluetoothPower(on:Boolean):String {
        val a=BluetoothAdapter.getDefaultAdapter() ?: return "Bluetooth is not available on this device."
        return if(android.os.Build.VERSION.SDK_INT>=33){ activity.startActivity(Intent(if(on) BluetoothAdapter.ACTION_REQUEST_ENABLE else Settings.ACTION_BLUETOOTH_SETTINGS)); if(on) "Opening Bluetooth so Android can switch it on." else "Opening Bluetooth controls. Android requires confirmation to switch it off." }
        else { @Suppress("DEPRECATION") runCatching{if(on)a.enable() else a.disable()}; if(on) "Bluetooth switched on." else "Bluetooth switched off." }
    }
    private fun openApp(raw:String):String {
        val wanted=raw.lowercase(Locale.getDefault()).trim(); val pm=activity.packageManager
        val intent=Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER); val apps=pm.queryIntentActivities(intent,0)
        val m=apps.firstOrNull{it.loadLabel(pm).toString().lowercase(Locale.getDefault())==wanted} ?: apps.firstOrNull{it.loadLabel(pm).toString().lowercase(Locale.getDefault()).contains(wanted)}
        if(m!=null){pm.getLaunchIntentForPackage(m.activityInfo.packageName)?.let{activity.startActivity(it);return "Opening ${m.loadLabel(pm)}."}}
        return "I could not find $wanted on this Android device."
    }

    fun handle(raw: String): String? {
        val q = raw.trim().lowercase(Locale.getDefault())
        when {
            q in setOf("increase volume to the highest","volume highest","maximum volume","max volume","increase volume to maximum") -> {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC,audio.getStreamMaxVolume(AudioManager.STREAM_MUSIC),AudioManager.FLAG_SHOW_UI)
                return "Volume is now at the highest level."
            }
            q in setOf("decrease volume to the lowest","volume lowest","minimum volume","min volume","decrease volume to minimum") -> {
                audio.setStreamVolume(AudioManager.STREAM_MUSIC,0,AudioManager.FLAG_SHOW_UI)
                return "Volume is now at the lowest level."
            }
            q.startsWith("increase volume") || q=="volume up" -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_RAISE,AudioManager.FLAG_SHOW_UI)
                return "Volume increased."
            }
            q.startsWith("decrease volume") || q=="volume down" -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_LOWER,AudioManager.FLAG_SHOW_UI)
                return "Volume decreased."
            }
            q in setOf("mute","mute volume") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_MUTE,AudioManager.FLAG_SHOW_UI); return "Muted."
            }
            q in setOf("unmute","unmute volume") -> {
                audio.adjustStreamVolume(AudioManager.STREAM_MUSIC,AudioManager.ADJUST_UNMUTE,AudioManager.FLAG_SHOW_UI); return "Unmuted."
            }
            q.contains("open settings") -> { activity.startActivity(Intent(Settings.ACTION_SETTINGS)); return "Opening settings." }
            q.contains("open wifi") || q.contains("wi-fi settings") -> { activity.startActivity(Intent(Settings.ACTION_WIFI_SETTINGS)); return "Opening Wi-Fi settings." }
            q.contains("open bluetooth") || q.contains("bluetooth settings") -> { activity.startActivity(Intent(Settings.ACTION_BLUETOOTH_SETTINGS)); return "Opening Bluetooth settings." }
            q in setOf("open camera","camera") -> { activity.startActivity(Intent(MediaStore.INTENT_ACTION_STILL_IMAGE_CAMERA)); return "Opening camera." }
        }
        if (q.startsWith("open ")) {
            val wanted = q.removePrefix("open ").trim()
            val pm = activity.packageManager
            val launcherIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val launchables = pm.queryIntentActivities(launcherIntent, 0)
            val exact = launchables.firstOrNull {
                it.loadLabel(pm).toString().lowercase(Locale.getDefault()) == wanted
            }
            val match = exact ?: launchables.firstOrNull {
                it.loadLabel(pm).toString().lowercase(Locale.getDefault()).contains(wanted)
            }
            if (match != null) {
                val launch = pm.getLaunchIntentForPackage(match.activityInfo.packageName)
                if (launch != null) {
                    activity.startActivity(launch)
                    return "Opening ${match.loadLabel(pm)}."
                }
            }
        }
        return null
    }
}
