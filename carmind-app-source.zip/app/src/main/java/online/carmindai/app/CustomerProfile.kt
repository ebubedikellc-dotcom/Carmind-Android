package online.carmindai.app

import java.util.Locale

object CustomerProfile {
    fun cleanName(raw: String): String =
        raw.trim().replace(Regex("\\s+"), " ").take(80)

    fun maybeUseName(prefs: AppPrefs, sentence: String): String {
        val name = prefs.customerDisplayName.trim()
        if (name.isBlank()) return sentence
        val next = prefs.personalizationCounter + 1
        prefs.personalizationCounter = next
        return if (next % 3 == 0) {
            val clean = sentence.trim()
            if (clean.isBlank()) name
            else "$name, ${clean.replaceFirstChar { it.lowercase(Locale.getDefault()) }}"
        } else sentence
    }

    fun wakeGreeting(prefs: AppPrefs): String {
        val name = prefs.customerDisplayName.trim()
        return if (name.isBlank()) "Hello, how can I help you today?"
        else "Hello $name, how can I help you today?"
    }
}
