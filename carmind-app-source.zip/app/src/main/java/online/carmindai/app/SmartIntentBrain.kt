package online.carmindai.app

import java.util.Locale

object SmartIntentBrain {
    data class IntentResult(val action:String,val payload:String="",val service:String="",val mediaType:String="")
    private fun n(s:String)=s.lowercase(Locale.getDefault()).replace(Regex("[^a-z0-9+' -]")," ").replace(Regex("\\s+")," ").trim()
    private fun any(q:String,vararg p:String)=p.any{q.contains(it)}
    fun understand(raw:String):IntentResult? {
        val q=n(raw); if(q.isBlank()) return null
        if(any(q,"maximum volume","highest volume","max volume","volume highest","full volume","increase volume to the highest","raise volume to the highest")) return IntentResult("volume_max")
        if(any(q,"minimum volume","lowest volume","min volume","volume lowest","reduce volume to the lowest","decrease volume to the lowest","hide the volume")) return IntentResult("volume_min")
        if(any(q,"volume up","increase volume","raise volume","make it louder","take the volume up","turn it up","put the volume up","add volume","increase the sound")) return IntentResult("volume_up")
        if(any(q,"volume down","decrease volume","reduce volume","lower volume","bring the volume down","make it lower","turn it down","put the volume down","reduce the sound","bring sound down")) return IntentResult("volume_down")
        if(any(q,"mute volume","mute sound","mute the sound")) return IntentResult("mute")
        if(any(q,"unmute volume","unmute sound")) return IntentResult("unmute")
        if(any(q,"turn on flashlight","switch on flashlight","flashlight on","turn on torch","switch on torch","torch on")) return IntentResult("flashlight_on")
        if(any(q,"turn off flashlight","switch off flashlight","flashlight off","turn off torch","switch off torch","torch off")) return IntentResult("flashlight_off")
        if(any(q,"turn on bluetooth","switch on bluetooth","bluetooth on","enable bluetooth","on bluetooth","put bluetooth on")) return IntentResult("bluetooth_on")
        if(any(q,"turn off bluetooth","switch off bluetooth","bluetooth off","disable bluetooth","off bluetooth","put bluetooth off")) return IntentResult("bluetooth_off")
        if(any(q,"turn on wifi","switch on wifi","wifi on","wi fi on","enable wifi","on wifi","put wifi on")) return IntentResult("wifi_on")
        if(any(q,"turn off wifi","switch off wifi","wifi off","wi fi off","disable wifi","off wifi","put wifi off")) return IntentResult("wifi_off")
        if(q.startsWith("connect ")) { val x=q.replace(Regex("^connect( me)?( to)?( bluetooth)?\\s*"),"").replace(Regex("\\s+bluetooth$"),"").trim(); if(x.isNotBlank()) return IntentResult("bluetooth_connect",x) }
        if(q.startsWith("disconnect ")) { val x=q.replace(Regex("^disconnect( me)?( from)?( bluetooth)?\\s*"),"").replace(Regex("\\s+bluetooth$"),"").trim(); if(x.isNotBlank()) return IntentResult("bluetooth_disconnect",x) }
        val pref=listOf("play me ","play ","put ","give me ","i want to hear ","i want to listen to ").firstOrNull{q.startsWith(it)}
        if(pref!=null){ var x=q.removePrefix(pref).trim(); var service=""; var type=""
            when { x.contains(" on spotify")||x.contains(" from spotify")->{service="spotify";x=x.replace(" on spotify","").replace(" from spotify","").trim()}
                   x.contains(" on youtube music")||x.contains(" from youtube music")->{service="youtube_music";x=x.replace(" on youtube music","").replace(" from youtube music","").trim()}
                   x.contains(" on youtube")||x.contains(" from youtube")->{service="youtube";x=x.replace(" on youtube","").replace(" from youtube","").trim()} }
            if(any(q,"video","music video")) type="video" else if(any(q,"audio","song","music")) type="audio"
            if(x.isNotBlank()) return IntentResult("media_play",x,service,type)
        }
        val nav=listOf("take me to ","navigate to ","drive to ","go to ","we are going to ","we're going to ","we are travelling to ","we are traveling to ","travel to ","route to ","directions to ").firstOrNull{q.startsWith(it)}
        if(nav!=null){val x=q.removePrefix(nav).trim(); if(x.isNotBlank()) return IntentResult("navigate",x)}
        if(any(q,"nearest petrol station","nearest gas station","nearest fuel station")) return IntentResult("navigate_nearest","petrol station")
        if(any(q,"nearest hospital","closest hospital")) return IntentResult("navigate_nearest","hospital")
        if(any(q,"nearest pharmacy","closest pharmacy")) return IntentResult("navigate_nearest","pharmacy")
        if(any(q,"nearest restaurant","closest restaurant")) return IntentResult("navigate_nearest","restaurant")
        if(any(q,"where are we","where am i","what road are we on","what road am i on")) return IntentResult("where_am_i")
        if(any(q,"distance remaining","how far remaining","how far to go","time remaining","how much longer")) return IntentResult("journey_progress")
        if(q.startsWith("open ")) return IntentResult("open_app",q.removePrefix("open ").trim())
        return null
    }
}
