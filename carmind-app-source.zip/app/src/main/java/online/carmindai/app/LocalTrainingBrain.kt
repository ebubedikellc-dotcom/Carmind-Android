package online.carmindai.app

import java.util.Locale

object LocalTrainingBrain {
    private fun normalize(s: String): String =
        s.lowercase(Locale.getDefault())
            .replace(Regex("[^a-z0-9 ]"), " ")
            .replace(Regex("\\s+"), " ")
            .trim()

    fun findAnswer(trainingBox: String, input: String): String? {
        val q = normalize(input)
        if (q.isBlank()) return null
        for (raw in trainingBox.lineSequence()) {
            val line = raw.trim()
            if (line.isBlank() || line.startsWith("#")) continue
            val sep = listOf("=>", "→", "|", "=").firstOrNull { line.contains(it) } ?: continue
            val parts = line.split(sep, limit = 2)
            if (parts.size != 2) continue
            val taughtQuestion = normalize(parts[0])
            val taughtAnswer = parts[1].trim()
            if (taughtQuestion == q && taughtAnswer.isNotBlank()) return taughtAnswer
        }
        return null
    }
}
