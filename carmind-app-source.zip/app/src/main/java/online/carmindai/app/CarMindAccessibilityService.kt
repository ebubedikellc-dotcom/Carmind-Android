package online.carmindai.app

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.AccessibilityServiceInfo
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo
import java.util.Locale

class CarMindAccessibilityService : AccessibilityService() {

    companion object {
        @Volatile var instance: CarMindAccessibilityService? = null
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        instance = this
        serviceInfo = serviceInfo.apply {
            flags = flags or
                AccessibilityServiceInfo.FLAG_REPORT_VIEW_IDS or
                AccessibilityServiceInfo.FLAG_RETRIEVE_INTERACTIVE_WINDOWS
        }
    }

    override fun onDestroy() {
        if (instance === this) instance = null
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}

    fun home(): Boolean = performGlobalAction(GLOBAL_ACTION_HOME)
    fun back(): Boolean = performGlobalAction(GLOBAL_ACTION_BACK)
    fun recents(): Boolean = performGlobalAction(GLOBAL_ACTION_RECENTS)
    fun notifications(): Boolean = performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS)
    fun quickSettings(): Boolean = performGlobalAction(GLOBAL_ACTION_QUICK_SETTINGS)

    fun scrollForward(): Boolean =
        rootInActiveWindow?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_FORWARD) == true

    fun scrollBackward(): Boolean =
        rootInActiveWindow?.performAction(AccessibilityNodeInfo.ACTION_SCROLL_BACKWARD) == true

    fun clickText(text: String): Boolean {
        val wanted = text.trim()
        if (wanted.isBlank()) return false
        val root = rootInActiveWindow ?: return false

        val direct = root.findAccessibilityNodeInfosByText(wanted)
            ?.firstOrNull { it.isVisibleToUser && it.isClickable }
        if (direct != null) return direct.performAction(AccessibilityNodeInfo.ACTION_CLICK)

        val all = root.findAccessibilityNodeInfosByText(wanted).orEmpty()
        for (node in all) {
            var p: AccessibilityNodeInfo? = node
            while (p != null) {
                if (p.isVisibleToUser && p.isClickable) {
                    return p.performAction(AccessibilityNodeInfo.ACTION_CLICK)
                }
                p = p.parent
            }
        }
        return false
    }

    fun typeText(text: String): Boolean {
        val root = rootInActiveWindow ?: return false
        val focus = root.findFocus(AccessibilityNodeInfo.FOCUS_INPUT) ?: return false
        val args = android.os.Bundle().apply {
            putCharSequence(
                AccessibilityNodeInfo.ACTION_ARGUMENT_SET_TEXT_CHARSEQUENCE,
                text
            )
        }
        return focus.performAction(AccessibilityNodeInfo.ACTION_SET_TEXT, args)
    }
}
