package online.carmindai.app

import android.webkit.JavascriptInterface
import org.json.JSONObject

class NativeBridge(private val activity: MainActivity) {
    @JavascriptInterface fun speak(text: String) = activity.runOnUiThread { activity.speak(text) }
    @JavascriptInterface fun listen() = activity.runOnUiThread { activity.startListeningOnce() }
    @JavascriptInterface fun setAssistantName(name: String) = activity.runOnUiThread { activity.setAssistantName(name) }
    @JavascriptInterface fun setCarName(name: String) = activity.runOnUiThread { activity.setCarName(name) }
    @JavascriptInterface fun setWakeName(name: String) = activity.runOnUiThread { activity.setWakeName(name) }
    @JavascriptInterface fun setPreferredMediaService(name: String) = activity.runOnUiThread { activity.setPreferredMediaService(name) }
    @JavascriptInterface fun getState(): String = activity.nativeStateJson()
    @JavascriptInterface fun setContinuousListening(enabled: Boolean) = activity.runOnUiThread { activity.setContinuousListening(enabled) }
    @JavascriptInterface fun setTrainingBox(text: String) = activity.runOnUiThread { activity.setTrainingBox(text) }
    @JavascriptInterface fun setOwnerProfile(text: String) = activity.runOnUiThread { activity.setOwnerProfile(text) }
    @JavascriptInterface fun setVoiceDirectionsEnabled(enabled: Boolean) = activity.runOnUiThread { activity.setVoiceDirectionsEnabled(enabled) }
    @JavascriptInterface fun setMaintenanceBox(text: String) = activity.runOnUiThread { activity.setMaintenanceBox(text) }
    @JavascriptInterface fun setDrivingGreetingEnabled(enabled: Boolean) = activity.runOnUiThread { activity.setDrivingGreetingEnabled(enabled) }
    @JavascriptInterface fun setDrivingModeEnabled(enabled: Boolean) = activity.runOnUiThread { activity.setDrivingModeEnabled(enabled) }
    @JavascriptInterface fun setFloatingMicEnabled(enabled: Boolean) = activity.runOnUiThread { activity.setFloatingMicEnabled(enabled) }
    @JavascriptInterface fun setFeatureFlags(json: String) = activity.runOnUiThread { activity.setFeatureFlags(json) }
    @JavascriptInterface fun setAutoParkingEnabled(enabled: Boolean) = activity.runOnUiThread { activity.setAutoParkingEnabled(enabled) }
    @JavascriptInterface fun setCustomerIdentity(name: String, email: String, phone: String) = activity.runOnUiThread { activity.setCustomerIdentity(name, email, phone) }
    @JavascriptInterface fun setCustomerDisplayName(name: String) = activity.runOnUiThread { activity.setCustomerDisplayName(name) }
    @JavascriptInterface fun openCustomerSetup() = activity.runOnUiThread { activity.openCustomerSetup() }
    @JavascriptInterface fun refreshEntitlement() = activity.refreshEntitlement()
    @JavascriptInterface fun openPayment() = activity.runOnUiThread { activity.openPayment() }
    @JavascriptInterface fun execute(json: String) = activity.runOnUiThread {
        runCatching {
            val obj = JSONObject(json)
            activity.executeAction(obj.optString("action"), obj.optJSONObject("payload") ?: JSONObject())
        }.onFailure { activity.showStatus("Bad native command") }
    }
}
