package online.carmindai.app

import android.webkit.JavascriptInterface
import org.json.JSONObject

class NativeBridge(private val activity: MainActivity) {
    @JavascriptInterface fun speak(text: String) = activity.runOnUiThread { activity.speak(text) }
    @JavascriptInterface fun listen() = activity.runOnUiThread { activity.startListeningOnce() }
    @JavascriptInterface fun setAssistantName(name: String) = activity.runOnUiThread { activity.setAssistantName(name) }
    @JavascriptInterface fun getState(): String = activity.nativeStateJson()
    @JavascriptInterface fun setContinuousListening(enabled: Boolean) = activity.runOnUiThread { activity.setContinuousListening(enabled) }
    @JavascriptInterface fun execute(json: String) = activity.runOnUiThread {
        runCatching {
            val obj = JSONObject(json)
            activity.executeAction(obj.optString("action"), obj.optJSONObject("payload") ?: JSONObject())
        }.onFailure { activity.showStatus("Bad native command") }
    }
}
