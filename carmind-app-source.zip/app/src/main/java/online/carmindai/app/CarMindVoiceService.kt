package online.carmindai.app

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.content.pm.ServiceInfo
import android.speech.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class CarMindVoiceService : Service() {
    private var recognizer: SpeechRecognizer? = null
    private lateinit var prefs: AppPrefs
    private var active = false
    private var restartScheduled = false
    private val handler by lazy { android.os.Handler(mainLooper) }
    private var wakeLock: PowerManager.WakeLock? = null

    override fun onCreate() {
        super.onCreate()
        prefs = AppPrefs(this)
        createChannel()
        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val n = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("CarMind AI is ready")
            .setContentText("Listening mode can stay active while CarMind is running")
            .setContentIntent(openIntent)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(4312, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(4312, n)
        }
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager).newWakeLock(
            PowerManager.PARTIAL_WAKE_LOCK, "CarMind:VoiceListening"
        ).apply { setReferenceCounted(false); acquire(6 * 60 * 60 * 1000L) }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val enable = intent?.getBooleanExtra("enable", prefs.continuousListening) ?: prefs.continuousListening
        prefs.continuousListening = enable
        if (enable) beginLoop() else stopLoop()
        return START_STICKY
    }

    private fun beginLoop() {
        if (active) return
        // Payment/trial/legacy/owner access is decided by the server and cached by MainActivity.
        // Never spin the recognizer while access is unknown or inactive.
        if (!prefs.commerceStatusKnown || !prefs.commerceAccessActive) {
            stopSelf()
            return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) return
        active = true
        startRecognition()
    }

    private fun startRecognition() {
        if (!active) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this)
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onResults(results: android.os.Bundle?) {
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank()) {
                    val i = Intent(ACTION_HEARD).setPackage(packageName).putExtra("text", text)
                    sendBroadcast(i)
                }
                restartSoon()
            }
            override fun onError(error: Int) {
                val delay = when (error) {
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                    SpeechRecognizer.ERROR_SERVER,
                    SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> 3500L
                    SpeechRecognizer.ERROR_NO_MATCH,
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> 1800L
                    else -> 2500L
                }
                restartSoon(delay)
            }
            override fun onReadyForSpeech(params: android.os.Bundle?) {}
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() {}
            override fun onPartialResults(partialResults: android.os.Bundle?) {}
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, Locale.getDefault())
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS, 900L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS, 600L)
        }
        runCatching { recognizer?.startListening(intent) }.onFailure { restartSoon() }
    }

    private fun restartSoon(delayMs: Long = 1200L) {
        if (!active || restartScheduled) return
        restartScheduled = true
        handler.postDelayed({
            restartScheduled = false
            if (active && prefs.commerceStatusKnown && prefs.commerceAccessActive) {
                startRecognition()
            } else if (!prefs.commerceAccessActive) {
                stopSelf()
            }
        }, delayMs)
    }

    private fun stopLoop() {
        active = false
        restartScheduled = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.cancel(); recognizer?.destroy(); recognizer = null
    }

    override fun onDestroy() {
        stopLoop()
        if (wakeLock?.isHeld == true) wakeLock?.release()
        wakeLock = null
        super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(NotificationChannel(CHANNEL, "CarMind listening", NotificationManager.IMPORTANCE_LOW))
        }
    }

    companion object {
        const val ACTION_HEARD = "online.carmindai.app.HEARD"
        private const val CHANNEL = "carmind_voice"
    }
}
