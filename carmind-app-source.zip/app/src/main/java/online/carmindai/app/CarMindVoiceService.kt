package online.carmindai.app

import android.Manifest
import android.app.*
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.media.AudioManager
import android.media.AudioRecordingConfiguration
import android.os.Build
import android.os.IBinder
import android.os.PowerManager
import android.speech.*
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import java.io.File
import java.util.Locale

class CarMindVoiceService : Service() {
    private lateinit var prefs: AppPrefs
    private lateinit var audioManager: AudioManager
    private lateinit var diagnostics: DiagnosticReporter
    private var recognizer: SpeechRecognizer? = null
    private var vosk: VoskVoiceEngine? = null
    private var active = false
    private var listening = false
    private var restartScheduled = false
    private var usingOnDevice = false
    private var usingVosk = false
    private var voskInitializing = false
    private var externalRecordingActive = false
    private var lastWakeAt = 0L
    private val handler by lazy { android.os.Handler(mainLooper) }
    private var wakeLock: PowerManager.WakeLock? = null

    private val recordingCallback = if (Build.VERSION.SDK_INT >= 24) object : AudioManager.AudioRecordingCallback() {
        override fun onRecordingConfigChanged(configs: MutableList<AudioRecordingConfiguration>?) {
            val otherRecordingLikely = configs.orEmpty().isNotEmpty() && !listening
            if (otherRecordingLikely) {
                externalRecordingActive = true
                prefs.externalRecordingPauseUntil = System.currentTimeMillis() + 15_000L
                pauseForExternalRecorder()
            } else if (externalRecordingActive && configs.orEmpty().isEmpty()) {
                externalRecordingActive = false
                prefs.externalRecordingPauseUntil = System.currentTimeMillis() + 2_500L
                restartSoon(2_500L)
            }
        }
    } else null

    override fun onCreate() {
        super.onCreate()
        prefs = AppPrefs(this)
        audioManager = getSystemService(AUDIO_SERVICE) as AudioManager
        diagnostics = DiagnosticReporter(this, prefs)
        createChannel()
        if (Build.VERSION.SDK_INT >= 24) recordingCallback?.let { audioManager.registerAudioRecordingCallback(it, handler) }
        val openIntent = PendingIntent.getActivity(this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE)
        val notification = NotificationCompat.Builder(this, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentTitle("CarMind is ready")
            .setContentText("Waiting quietly for ${prefs.wakeName}")
            .setContentIntent(openIntent).setOngoing(true).setSilent(true).setOnlyAlertOnce(true).build()
        if (Build.VERSION.SDK_INT >= 29) startForeground(4312, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        else startForeground(4312, notification)
        wakeLock = (getSystemService(POWER_SERVICE) as PowerManager)
            .newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "CarMind:WakeListener").apply {
                setReferenceCounted(false); acquire(6 * 60 * 60 * 1000L)
            }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val enable = intent?.getBooleanExtra("enable", prefs.continuousListening) ?: prefs.continuousListening
        prefs.continuousListening = enable
        if (enable) begin() else stopLoop()
        return START_STICKY
    }

    private fun begin() {
        if (active) return
        if (!prefs.commerceStatusKnown || !prefs.commerceAccessActive) { stopSelf(); return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) { stopSelf(); return }
        active = true
        when (prefs.voiceEngine.lowercase()) {
            "android" -> startAndroidFallback()
            else -> startVoskOrFallback()
        }
    }

    private fun startVoskOrFallback() {
        if (!active || voskInitializing || usingVosk) return
        voskInitializing = true
        diagnostics.report("wake", "vosk_model_prepare", "running", detail = "free offline speech model")
        VoskModelManager.ensureModelAsync(this, { modelDir ->
            handler.post {
                voskInitializing = false
                if (!active) return@post
                runCatching { startVosk(modelDir) }.onFailure {
                    diagnostics.report("wake", "vosk_start", "failed", detail = it.message.orEmpty())
                    startAndroidFallback()
                }
            }
        }, { error ->
            handler.post {
                voskInitializing = false
                diagnostics.report("wake", "vosk_model_prepare", "fallback", detail = error.message.orEmpty())
                startAndroidFallback()
            }
        })
    }

    private fun startVosk(modelDir: File) {
        stopAndroidRecognizer()
        val engine = VoskVoiceEngine()
        vosk = engine
        usingVosk = true
        listening = true
        diagnostics.report("wake", "vosk_start", "ok", detail = "offline continuous listener")
        engine.start(modelDir, object : VoskVoiceEngine.Listener {
            override fun onPartial(text: String) { handler.post { handleVoskText(text, true) } }
            override fun onResult(text: String) { handler.post { handleVoskText(text, false) } }
            override fun onError(error: Throwable) { handler.post {
                if (!active) return@post
                usingVosk = false; listening = false
                runCatching { vosk?.stop() }; vosk = null
                diagnostics.report("microphone", "vosk_error", "failed", detail = error.message.orEmpty())
                restartSoon(4_000L)
            } }
        })
    }

    private fun handleVoskText(text: String, partial: Boolean) {
        if (!active || text.isBlank()) return
        val now = System.currentTimeMillis()
        if (!waitingForCommand() && containsWake(text)) {
            if (now - lastWakeAt > 2_500L) {
                lastWakeAt = now
                broadcast(text, "wake")
            }
            return
        }
        if (!partial && waitingForCommand()) {
            // Do not accidentally treat the just-heard wake phrase as the next command.
            if (containsWake(text) && now - lastWakeAt < 2_500L) return
            prefs.awaitingCommandUntil = 0L
            broadcast(text, "command")
        }
    }

    private fun startAndroidFallback() {
        if (!active || usingVosk) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            diagnostics.report("microphone", "android_speech_fallback", "failed", detail = "No recognizer available")
            stopSelf(); return
        }
        ensureRecognizer(); startRecognition()
    }

    private fun ensureRecognizer() {
        if (recognizer != null) return
        recognizer = if (Build.VERSION.SDK_INT >= 31 && SpeechRecognizer.isOnDeviceRecognitionAvailable(this)) {
            usingOnDevice = true; SpeechRecognizer.createOnDeviceSpeechRecognizer(this)
        } else { usingOnDevice = false; SpeechRecognizer.createSpeechRecognizer(this) }
        recognizer?.setRecognitionListener(object : RecognitionListener {
            override fun onReadyForSpeech(params: android.os.Bundle?) { listening = true }
            override fun onBeginningOfSpeech() {}
            override fun onRmsChanged(rmsdB: Float) {}
            override fun onBufferReceived(buffer: ByteArray?) {}
            override fun onEndOfSpeech() { listening = false }
            override fun onPartialResults(partialResults: android.os.Bundle?) {
                val text = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                if (text.isNotBlank() && !waitingForCommand() && containsWake(text)) {
                    listening = false; recognizer?.stopListening(); lastWakeAt = System.currentTimeMillis(); broadcast(text, "wake")
                }
            }
            override fun onResults(results: android.os.Bundle?) {
                listening = false
                val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty()
                when {
                    text.isBlank() -> restartSoon(if (usingOnDevice) 6_000L else 12_000L)
                    waitingForCommand() -> { prefs.awaitingCommandUntil = 0L; broadcast(text, "command"); restartSoon(1_500L) }
                    containsWake(text) -> { lastWakeAt = System.currentTimeMillis(); broadcast(text, "wake"); restartSoon(1_500L) }
                    else -> restartSoon(if (usingOnDevice) 6_000L else 12_000L)
                }
            }
            override fun onError(error: Int) {
                listening = false
                diagnostics.report("microphone", "speech_recognizer_error", "failed", code = error.toString())
                val delay = when(error) {
                    SpeechRecognizer.ERROR_AUDIO -> { prefs.externalRecordingPauseUntil = System.currentTimeMillis()+15_000L; 15_000L }
                    SpeechRecognizer.ERROR_RECOGNIZER_BUSY -> 6_000L
                    SpeechRecognizer.ERROR_SERVER, SpeechRecognizer.ERROR_SERVER_DISCONNECTED -> 7_000L
                    SpeechRecognizer.ERROR_NO_MATCH, SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> if(usingOnDevice) 6_000L else 12_000L
                    else -> 4_000L
                }
                restartSoon(delay)
            }
            override fun onEvent(eventType: Int, params: android.os.Bundle?) {}
        })
    }

    private fun waitingForCommand() = prefs.awaitingCommandUntil > System.currentTimeMillis()
    private fun containsWake(text: String): Boolean {
        val low=text.lowercase(Locale.getDefault()).trim(); val wake=prefs.wakeName.lowercase(Locale.getDefault()).trim()
        return wake.isNotBlank() && (low==wake || low.contains("hey $wake") || low.contains("hello $wake") || low.contains("hi $wake"))
    }

    private fun startRecognition() {
        if (!active || usingVosk || listening || restartScheduled) return
        if (!prefs.commerceAccessActive) { stopSelf(); return }
        val pauseUntil=prefs.externalRecordingPauseUntil
        if (externalRecordingActive || pauseUntil>System.currentTimeMillis()) { restartSoon((pauseUntil-System.currentTimeMillis()).coerceAtLeast(2_500L)); return }
        ensureRecognizer()
        val intent=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true); putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,3)
            putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE,true); putExtra(RecognizerIntent.EXTRA_LANGUAGE,"en-NG")
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_COMPLETE_SILENCE_LENGTH_MILLIS,10_000L)
            putExtra(RecognizerIntent.EXTRA_SPEECH_INPUT_POSSIBLY_COMPLETE_SILENCE_LENGTH_MILLIS,7_000L)
        }
        runCatching { recognizer?.startListening(intent); listening=true }.onFailure { listening=false; restartSoon(6_000L) }
    }

    private fun pauseForExternalRecorder() {
        listening=false; restartScheduled=false; handler.removeCallbacksAndMessages(null)
        if (usingVosk) { runCatching { vosk?.stop() }; vosk=null; usingVosk=false }
        runCatching { recognizer?.cancel() }
    }

    private fun restartSoon(delayMs: Long) {
        if (!active || restartScheduled) return
        restartScheduled=true
        handler.postDelayed({
            restartScheduled=false
            if (active && prefs.commerceStatusKnown && prefs.commerceAccessActive) {
                if (usingVosk) return@postDelayed
                if (prefs.voiceEngine.lowercase() == "android") startAndroidFallback() else startVoskOrFallback()
            } else stopSelf()
        },delayMs)
    }

    private fun broadcast(text:String,mode:String) {
        sendBroadcast(Intent(ACTION_HEARD).setPackage(packageName).putExtra("text",text).putExtra("mode",mode))
    }

    private fun stopAndroidRecognizer() {
        runCatching { recognizer?.cancel() }; runCatching { recognizer?.destroy() }; recognizer=null
    }
    private fun stopLoop() {
        active=false; listening=false; restartScheduled=false; voskInitializing=false; handler.removeCallbacksAndMessages(null)
        runCatching { vosk?.stop() }; vosk=null; usingVosk=false; stopAndroidRecognizer()
    }
    override fun onDestroy() {
        if(Build.VERSION.SDK_INT>=24) recordingCallback?.let{runCatching{audioManager.unregisterAudioRecordingCallback(it)}}
        stopLoop(); if(wakeLock?.isHeld==true) wakeLock?.release(); super.onDestroy()
    }
    override fun onBind(intent: Intent?): IBinder? = null
    private fun createChannel() {
        if(Build.VERSION.SDK_INT>=26) getSystemService(NotificationManager::class.java).createNotificationChannel(
            NotificationChannel(CHANNEL,"CarMind wake listener",NotificationManager.IMPORTANCE_LOW).apply{setSound(null,null);enableVibration(false);setShowBadge(false)})
    }
    companion object { const val ACTION_HEARD="online.carmindai.app.ACTION_HEARD"; private const val CHANNEL="carmind_voice" }
}
