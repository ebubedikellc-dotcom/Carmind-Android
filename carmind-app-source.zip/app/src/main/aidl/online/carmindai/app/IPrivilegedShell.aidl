package online.carmindai.app;

interface IPrivilegedShell {
    int runAction(String action);
    void destroy();
}
