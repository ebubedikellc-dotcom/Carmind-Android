package online.carmindai.app

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNull
import org.junit.Test

class CommandParserTest {
    @Test fun navigation() = assertEquals(ParsedCommand("navigate", "Lagos Airport"), CommandParser.parse("Take me to Lagos Airport"))
    @Test fun music() = assertEquals(ParsedCommand("music", "Burna Boy"), CommandParser.parse("Play Burna Boy"))
    @Test fun video() = assertEquals(ParsedCommand("video", "Davido live"), CommandParser.parse("Play video Davido live"))
    @Test fun conversationFallsThrough() = assertNull(CommandParser.parse("How was your day?"))
}
