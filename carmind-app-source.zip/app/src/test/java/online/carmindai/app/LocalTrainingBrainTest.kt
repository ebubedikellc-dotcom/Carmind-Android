package online.carmindai.app

import org.junit.Assert.assertEquals
import org.junit.Test

class LocalTrainingBrainTest {
    @Test fun oneBoxTrainingWorks() {
        val box = """
            How are you? => I'm fine today. How are you?
            Are you there? | Yes, I'm here.
        """.trimIndent()
        assertEquals("I'm fine today. How are you?", LocalTrainingBrain.findAnswer(box, "How are you?"))
        assertEquals("Yes, I'm here.", LocalTrainingBrain.findAnswer(box, "Are you there"))
    }
}
