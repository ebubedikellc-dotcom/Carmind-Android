package online.carmindai.app

import org.junit.Assert.assertTrue
import org.junit.Test

class MaintenanceBrainTest {
    @Test fun maintenanceBoxParses() {
        val s = MaintenanceBrain.spoken("Oil change=at 10,000 km\nTyres=>check next month")
        assertTrue(s.contains("Oil change"))
        assertTrue(s.contains("Tyres"))
    }
}
