package online.carmindai.app

import org.junit.Assert.assertEquals
import org.junit.Test

class OwnerProfileTest {
    @Test fun relationshipsResolve() {
        val p = OwnerProfile.parse("name=David\nwife=Amaka\nhome=Lekki")
        assertEquals("Amaka", OwnerProfile.resolveRelationship("my wife", p))
        assertEquals("Your name is David.", OwnerProfile.localOwnerAnswer("What's my name", p))
    }
}
